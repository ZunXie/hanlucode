<template>
  <div>
    <h3>TEST组件</h3>
  </div>
</template>

<script>
import request from "@/utils/request.js";
export default {
  data() {
    return {
      msg: "haloMSG"
    };
  },
  mounted() {
    console.log(request);
    this.getToken();
  },
  activated(){
    console.log('活动');
  },
  deactivated(){
    console.log('退出');
  },
  methods: {
    ffff(){
      let a='sss'
      console.log('fffff',a);

    },
    getToken() {
      let url = "";
      // if(process.env.NODE_ENV == 'production'){
      //   url='https://marketouchplus-uat.brandmax.com.cn/rest/employee/user/pc/doLogin'
      // }else
      url = "rest/employee/user/pc/doLogin";
      request({
        method: "post",
        url: url,
        data: {
          loginAccount: "admin",
          password: "0CZTHM9i0ak="
        }
      })
        .then(res => {
          console.log("----:", res.data);
          // request.defaults.headers.common['token'] = res.data.data.token;
          // console.log('axios:',request.defaults.headers);
          // this.token=res.data.token
        })
        .catch(err => {
          console.log("错误：", err);
        });
    }
  }
};
</script>

<style lang="less" scoped>

</style>
