import Vue from "vue";
import VueRouter from "vue-router";

if (!window.VueRouter) {
  Vue.use(VueRouter);
}
//懒加载
const Home = () => import('../views/Home.vue');
const About = () => import('../views/About.vue');


const routes = [{
    path: "/",
    name: "Home",
    component: Home,
    meta: {
      keepAlive: true
    }
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: About,
    meta: {
      keepAlive: false
    }
  }
];

const router = new VueRouter({
  routes
});
router.beforeEach((to, from, next) => {
  // 清空无用的页面缓存
  let toDepth = to.path.split('/').length
  let fromDepth = from.path.split('/').length
  if (toDepth < fromDepth) {
    // console.log('back...')
    from.meta.keepAlive = false
    to.meta.keepAlive = true
  }
  next()
})
export default router;