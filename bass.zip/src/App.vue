<template>
    <div id="app">
      <router-view />
    </div>
</template>
<script>
// import Layout from "@/views/Layout.vue";

export default {
  // components: {
  //   Layout,
  // },
};
</script>
<style lang="scss">

// 阿里字体图标设置
.icon, .iconfont {
  font-family:"iconfont" !important;
  font-size:16px;
  font-style:normal;
  -webkit-font-smoothing: antialiased;
  -webkit-text-stroke-width: 0.2px;
  -moz-osx-font-smoothing: grayscale;
}

</style>
