import { getAction,postAction } from '@/api/manage'
// 静态资源域名

const getQuestionUserId=(params,config)=>getAction('wenda-user',params,config)
const answerQuestions=(params,config)=>postAction('feeds',params,config)
// wendas/assigned
export {
   getQuestionUserId,//获取问题下所有用户id
   answerQuestions,//回答问题
}