import service from '@/utils/request'
// import qs from 'qs'

const baseURL = '/api/v2/'


//post
export function postAction(url, parameter,config={}) {
    return service({
        url: `${baseURL}${url}`,
        method: 'post',
        data:parameter,
        ...config
    })
}

//post method= {post | put}
export function httpAction(url, parameter = {}, method) {
    return service({
        url: `${url}`,
        method,
        params: parameter
    })
}

//put
export function putAction(url, parameter) {
    return service({
        url: `${baseURL}${url}`,
        method: 'put',
        data: parameter
    })
}

//get
export function getAction(url, parameter,config) {
    return service({
        url: `${baseURL}${url}`,
        method: 'get',
        params: parameter,
        ...config
    })
}

//deleteAction
export function deleteAction(url, parameter) {
    return service({
        url: `${baseURL}${url}`,
        method: 'delete',
        params: parameter
    })
}

