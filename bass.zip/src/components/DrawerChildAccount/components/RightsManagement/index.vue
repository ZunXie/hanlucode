<template>
  <div class="RightsManagement">
    <a-descriptions :column="1">
      <a-descriptions-item label="备注名">
        {{ PermissionsValue.remark }}</a-descriptions-item
      >
      <a-descriptions-item label="地址">
        {{ PermissionsValue.address }}
      </a-descriptions-item>
    </a-descriptions>
    <p>权限</p>
    <div class="menuPermissions">
      <a-tree
        v-model="checkedKeys"
        checkable
        :expandedKeys.sync="expandedKeys"
        :auto-expand-parent="autoExpandParent"
        :selected-keys="selectedKeys"
        :tree-data="treeData"
        @expand="onExpand"
        @select="onSelect"
        @check="getcheck"
      />
    </div>
    <div
      :style="{
        position: 'absolute',
        bottom: 0,
        width: '100%',
        borderTop: '1px solid #e8e8e8',
        padding: '10px 16px',
        textAlign: 'right',
        left: 0,
        background: '#fff',
        borderRadius: '0 0 4px 4px',
      }"
    >
      <a-space>
        <a-button @click="childrenOnClose"> 取消 </a-button>
        <a-button type="primary" @click="childrenOnok">
          确定
        </a-button></a-space
      >
    </div>
  </div>
</template>

<script>
import {
  userGroupPermission_list,
  userGroupPermission_listByUserId,
  user_saveGroupPower,
} from "@/utils/home";
export default {
  components: {},
  props: ["PermissionsValue"],
  data() {
    return {
      // 树形列表
      treeData: [],
      expandedKeys: [],
      autoExpandParent: true,
      checkedKeys: [],
      selectedKeys: [],
      saveUserDTO: {},
      treeInfo: {},
      arrlist: [],
      ajax_rights_arr: [],
    };
  },
  watch: {
    //选中的所有值
    checkedKeys(val) {
      let res = {};
      val.map((i, v) => {
        res = this.filter_selt_keys(res, i);
      });
      this.ajax_rights_arr = filter_rights(res);
      function filter_rights(params) {
        let permissionList = [];
        for (let key in params) {
          permissionList.push({
            groupCode: key,
            userPermissionIdList: params[key].map((item) => item.id),
          });
        }
        return permissionList;
      }
      this.saveUserDTO.userId = this.PermissionsValue.id;
      this.saveUserDTO.permissionList = this.ajax_rights_arr;
    },
    getList() {
      this.getuserGroupPermission_list();
    },
  },
  methods: {
    async childrenOnok() {
      let res = await user_saveGroupPower(
        this._data.saveUserDTO,
        "application/json"
      );
      if (res.data.code == 200) {
        this.$message.success("更新成功");
        this.$store.commit("USER_CREATUSER", Math.random());
      } else {
        this.$message.warning(res.data.msg);
      }
    },
    childrenOnClose() {
      this.$store.commit("USER_CREATUSER", Math.random());
    },
    filter_selt_keys(res, key) {
      this.treeData.map((item, index) => {
        if (item.key === key) {
          res[item.key] = [...item.children] || [];
        } else {
          item.children.map((child_it) => {
            if (child_it.key === key) {
              if (res[item.key]) {
                if (!res[item.key].find((newarr_it) => newarr_it.key == key))
                  res[item.key].push(child_it);
              } else {
                res[item.key] = [child_it];
              }
            }
          });
        }
      });
      return res;
    },
    recursiveFilter(tree, keys) {
      let data = tree.filter((item) => item.key == keys);
      if (data.length != 0) {
        this.treeInfo = data[0];
      } else {
        let res = [];
        for (let i = 0; i < tree.length; i++) {
          let item = tree[i];
          if (item.children) {
            //递归循环
            res = this.recursiveFilter(item.children, keys);
            if (res.length) return res;
          }
        }
      }
      return data;
    },
    getcheck(checkedKeys, info) {
      checkedKeys.map((i, v) => {
        this.recursiveFilter(this.treeData, i);
      });
    },
    onExpand(expandedKeys) {
      // if not set autoExpandParent to false, if children expanded, parent can not collapse.
      // or, you can remove all expanded children keys.
      this.expandedKeys = expandedKeys;
      this.autoExpandParent = false;
    },
    onCheck(checkedKeys) {
      console.log(checkedKeys);
      this.checkedKeys = checkedKeys;
    },
    onSelect(selectedKeys, info) {
      console.log(selectedKeys, info, "selectedKeys, info");
      this.selectedKeys = selectedKeys;
    },
    // 获取所有列表
    async getuserGroupPermission_list() {
      let resall = await userGroupPermission_listByUserId({
        userId: this.PermissionsValue.id,
      });
      this.treeData = resall.data.data.data;
      this.expandedKeys = resall.data.data.selectedKeys;
      this.checkedKeys = resall.data.data.selectedKeys;
    },
  },
  mounted() {
    this.getuserGroupPermission_list();
    console.log(this.PermissionsValue, "=======");
  },
  computed: {
    getList() {
      return this.$store.state.changeIndent;
    },
  },
};
</script>
<style lang="scss" scoped>
p {
  display: inline-block;
  font-size: 16px;
  font-weight: 600;
  color: $Black-85;
  margin: 33px 0 12px 0;
}
p:before {
  content: "";
  border-left: 4px solid #007aff;
  margin-right: 16px;
}
.menuPermissions {
  padding: 10px;
  border: 1px solid $Black-15;
  min-height: 488px;
  margin-bottom: 58px;
}
::v-deep .ant-drawer-header {
  position: absolute;
  top: 0px;
  z-index: 1000;
  width: 100%;
}
</style>