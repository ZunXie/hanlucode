<template>
  <div class="Userlog">
    <div>
      <div class="searchFrom">
        <a-form-model layout="inline" :model="form">
          <div style="display: flex; justify-content: space-between">
            <div>
              <a-form-model-item label="用户手机">
                <el-input
                  size="small"
                  v-model="form.user"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="店铺名称">
                <el-input size="small" v-model="form.ip" placeholder="请输入" />
              </a-form-model-item>
              <a-form-model-item label="任务名称">
                <el-input size="small" v-model="form.ip" placeholder="请输入" />
              </a-form-model-item>
              <a-form-model-item label="运营商">
                <a-select
                  default-value="lucy"
                  style="width: 120px"
                  @change="handleChange"
                >
                  <a-select-option value="jack"> Jack </a-select-option>
                  <a-select-option value="lucy"> Lucy </a-select-option>
                </a-select>
              </a-form-model-item>
              <a-form-model-item label="注册微信">
                <el-input
                  size="small"
                  v-model="form.user"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="任务状态">
                <a-select
                  default-value="lucy"
                  style="width: 120px"
                  @change="handleChange"
                >
                  <a-select-option value="jack"> Jack </a-select-option>
                  <a-select-option value="lucy"> Lucy </a-select-option>
                </a-select>
              </a-form-model-item>
            </div>
            <div>
              <a-form-model-item>
                <a-space>
                  <a-button @click="getSearch" type="primary"> 查询 </a-button>
                  <a-button @click="getReseth" type="primary"> 重置 </a-button>
                  <a-button @click="showModal" type="primary">
                    批量审核
                  </a-button>
                </a-space>
              </a-form-model-item>
            </div>
          </div>
        </a-form-model>
      </div>

      <div class="content_table">
        <a-table
          bordered
          :columns="columns"
          :pagination="false"
          :data-source="data_list"
          :locale="locale"
          :rowKey="(record) => record.id"
        >
          <template slot="operation" slot-scope="text, record">
            <a @click="getDetail(record)">审核</a>
          </template>
        </a-table>
      </div>
      <Paginationcom
        :current="pagination.current"
        :total="pagination.totalCount"
        :page-size="pagination.pageSize"
        @onShowSizeChange="onShowSizeChange"
      />
    </div>

    <div>
      <a-modal v-model="visible" title="批量审核" @ok="handleOk">
        <div style="text-align: center">
          <p>
            当前全部待审核条目<span style="font-size: 20px; color: red">23</span
            >条，批量操作
          </p>
          <a-space>
            <a-radio-group v-model="value" @change="onChange">
              <a-radio :value="1"> 审核通过</a-radio>
              <a-radio :value="2"> 审核不通过 </a-radio>
            </a-radio-group>
          </a-space>
        </div>
        <template slot="footer">
          <a-button type="primary">提交</a-button>
        </template>
      </a-modal>
    </div>
  </div>
</template>
<script>
import { user_userlog_list } from "@/utils/Network";
export default {
  name: "Userlog",
  data() {
    return {
      locale: {
        emptyText: () => <Empty text="暂无操作日志" />,
      },
      value: 1,
      form: { groupCode: "" },
      visible: false,
      // 表格数据
      columns: [
        {
          title: "店铺名称",
          dataIndex: "operatorName",
          key: "operatorName",
          // align: 'center',// 设置文本居中
        },
        {
          title: "商户账号",
          dataIndex: "name",
          key: "name",
        },
        {
          title: "任务名称",
          dataIndex: "info",
          scopedSlots: { customRender: "info" },
          key: "info",
        },
        {
          title: "任务时间",
          key: "createTime",
          dataIndex: "createTime",
          scopedSlots: { customRender: "createTime" },
          // sorter: (a, b) => a.createTime - b.createTime,
        },
        {
          title: "任务数量",
          dataIndex: "mo",
          scopedSlots: { customRender: "mo" },
          key: "mo",
        },
        {
          title: "任务总金额",
          dataIndex: "iphone",
          scopedSlots: { customRender: "iphone" },
          key: "iphone",
        },
        {
          title: "任务状态",
          dataIndex: "state",
          scopedSlots: { customRender: "state" },
          key: "state",
        },
        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          align: "center",
        },
      ],
      data_list: [
        {
          id: 1,
          operatorName: "1",
          name: "胡彦斌",
          info: 32,
          state: "已完成",
          createTime: "2022-1.2",
          address: "西湖区湖底公园1号",
          mo: "1235",
          iphone: "111111",
        },
      ],
      page_key: this.$route.name,
      value1: [],
      pagination: {
        //分页数据
        current: 1,
        pageSize: 100,
        totalCount: 0,
      },
      route_key: "",
    };
  },
  methods: {
    onChange(e) {
      console.log("radio checked", e.target.value);
    },
    showModal() {
      this.visible = true;
    },
    handleOk(e) {
      console.log(e);
      this.visible = false;
    },
    handleChange() {},
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getuser_userlog_list();
    },
    getTime(e) {
      this.form.startTime = e[0];
      this.form.endTime = e[1];
    },
    getSearch() {
      this.getuser_userlog_list();
      this.pagination.current = 1;
    },
    // 重置
    getReseth() {
      this.form = {};
      this.value1 = [];
    },
    async getuser_userlog_list() {
      this.form.pageNum = this.pagination.current;
      this.form.pageSize = this.pagination.pageSize;
      let res = await user_userlog_list(this.form);
      this.data_list = res.data.data.rows;
      this.pagination.totalCount = res.data.data.total;
    },
    // 详情
    getDetail(item) {
      this.$router.push({
        name: "AuditManagementDetail",
      });
    },
    // 平台自发任务
    getTask() {
      this.$router.push({
        name: "TaskWork",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.Userlog {
  margin: 24px 24px 48px 24px;
  .searchFrom {
    padding: 16px 0 16px 16px;
    background: $color-primary;
  }
}
.content_table {
  margin-top: 16px;
  background: $color-primary;
  padding: 16px 16px 0 16px;
  min-height: 612px;
}
.pagination_pas {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 40px;
  background: #970909;
  width: 100%;
  z-index: 1000;
}
</style>
