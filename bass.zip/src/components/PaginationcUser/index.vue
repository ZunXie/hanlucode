<template>
  <div class="mz-antd-paginationuser" :style="{ width: width + 'px' }">
    <a-pagination
      v-model="pageNum"
      :page-size-options="pageSizeOptions"
      :total="total"
      show-size-changer
      :page-size="pageSize"
      @showSizeChange="onShowSizeChange"
      @change="change"
      :show-total="(total) => `共 ${total} 条,第${current}页`"
    >
      <template slot="buildOptionText" slot-scope="props">
        <span>{{ props.value }}条/页</span>
      </template>
    </a-pagination>
  </div>
</template>

<script>
export default {
  props: {
    total: {
      type: Number,
      default: 0,
    },
    pageSizeOptions: {
      type: Array,
      default() {
        return ['50', '100', '200', '300', '400']
      },
    },
    current: {
      type: Number,
      default: 1,
    },
    pageSize: {
      type: Number,
      default: 100,
    },
  },
  data() {
    return {
      pageNum: this.current,
      width: '',
      page_key: this.$route.name,
    }
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key + '_page_user')
  },
  mounted() {
    this.setitem_event.add({
      key: this.page_key + '_page_user',
      func: this.onShowSize,
    })
    this.width = document.body.clientWidth - 264
    window.onresize = () => {
      return (() => {
        this.width = document.body.clientWidth - 264
      })()
    }
  },
  methods: {
    change(current, pageSize) {
      this.$emit('onShowSizeChange', current, pageSize)
    },
    onShowSizeChange(current, pageSize) {
      this.$emit('onShowSizeChange', current, pageSize)
    },
  },
}
</script>

<style lang="scss">
.mz-antd-paginationuser {
  box-shadow: -7px -16px 41px -8px rgb(0 0 0 / 42%);
  position: fixed;
  bottom: 0px;
  right: 24px;
  z-index: 1000;
  background: #ffffff;
  height: 47px;
  margin-right: 16px;
  // width: 81%;
  .ant-pagination {
    text-align: right !important;
    margin: 8px 5px !important;
  }
  .ant-pagination-item {
    display: none !important;
  }
}
</style>
