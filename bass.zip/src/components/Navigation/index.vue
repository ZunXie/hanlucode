<template>
  <div class="Navigation">
    <div @click="getGoback" class="goback">
      <slot name="retlirn"></slot>
    </div>
    <div class="Nav-tit nav-value">
      <div>
        <span class="tit-vale">{{ title }}</span>
        <span class="ChainGroupAll" v-if="!typeshow">
          <a-select
            v-if="ChainGroupAlllist[0]"
            :default-value="defaultValue"
            :dropdownMatchSelectWidth="false"
            @change="handleChange"
          >
            <div slot="suffixIcon"><a-icon type="caret-down" /></div>
            <a-select-option
              v-for="(item, index) in ChainGroupAlllist"
              :key="index"
              :value="item.groupCode"
            >
              {{ item.groupName }}
            </a-select-option>
          </a-select>
        </span>
      </div>

      <slot name="search"></slot>
    </div>
  </div>
</template>

<script>
import { setSessionStorage, getSessionStorage } from "@/utils/util";

export default {
  components: {},
  props: ["title", "typeshow"],
  data() {
    return {
      ChainGroupAlllist: [],
      //默认值
      defaultValue: "",
    };
  },
  watch: {},
  computed: {},
  methods: {
    handleChange(value) {
      setSessionStorage("groupCodeAll", value);
      this.resetSetItem("groupCode", JSON.stringify(value));
    },
    async getChainGroupAll() {
      let res = getSessionStorage("groupCodeList");
      setSessionStorage("groupCodeAll", res[0].groupCode);
      this.ChainGroupAlllist = res;
      this.defaultValue = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : res[0].groupCode;
    },
    getGoback() {
      this.$router.go(-1);
    },
  },
  mounted() {
    this.getChainGroupAll();
  },
  watch: {
    getmodifyName() {
      this.getChainGroupAll();
    },
  },
  computed: {
    getmodifyName() {
      return this.$store.state.modifyName;
    },
  },
};
</script>
<style lang="scss" scoped>
.Navigation {
  background: $color-primary;
  padding: 12px 16px 16px 16px;
  .tit-vale {
    font-size: $size-inSmall;
    font-weight: 500;
    color: $color-tit;
  }
  .goback {
    margin-bottom: 10px;
  }
  .goback:hover {
    cursor: pointer;
  }
}
.nav-value {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ChainGroupAll{
  margin-left: 8px;
}
</style>