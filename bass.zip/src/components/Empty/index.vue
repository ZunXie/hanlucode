<template>
  <div
    :style="{ height: height + 'px', marginTop: marginTop + 'px',background:background }"
    class="empty"
  >
    <div style="width: 100px; text-align: center">
      <img
        :src="imgSrc || require('../../img/blank_illustration@2x.png')"
        alt=""
        :style="{ width: width + 'px' }"
      />
      <div :style="{ 'font-size': fontSize + 'px' }">{{ text }}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    //缺省文案
    text: {
      type: String,
      default: "",
    },
    //图片路径
    imgSrc: {
      type: String,
      default: "",
    },
    //图片宽
    width: {
      type: Number,
      default: 72,
    },
    marginTop: {
      type: Number,
      default: 0,
    },
    height: {
      type: Number,
      default: 125,
    },
    //字体大小
    fontSize: {
      type: Number,
      default: 14,
    },
    background:{
      type: String,
      default: "",
    }
  },

  mounted() {},
};
</script>
<style lang="scss" scoped>
.empty {
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
