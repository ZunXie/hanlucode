<template>
  <a-layout-sider
    v-if="show"
    :width="collapsed ? '200' : '50'"
    style="background: #fff"
  >
    <a-menu
      mode="inline"
      class="menu"
      :selectedKeys="selectedKeys"
      :default-selected-keys="defaultSelectedkeys"
      :open-keys.sync="openKeys"
      :style="{ height: '100%', borderRight: 1 }"
      @click="getmenu"
      :inlineCollapsed="collapsed"
    >
      <template v-for="item in nav_list">
        <a-menu-item
          v-if="!item.show  "
          :key="item.key"
          @click="load_route(item.key)"
        >
          <span class="anticon">
            <i v-if="item.type" class="iconfont icon-Api"></i>
            <a-icon v-else :type="item.icon" />
          </span>
          <span v-if="collapsed"> {{ item.name }}</span>
        </a-menu-item>
        <a-sub-menu v-else :key="item.key">
          <span slot="title">
            <a-icon :type="item.icon" />
            <span v-if="collapsed"> {{ item.name }}</span>
          </span>
          <a-menu-item
            v-for="child in item.children"
            :key="child.key"
            v-show="!child.hideen && collapsed"
            @click="load_route(child.key)"
          >
            <span>{{ child.name }}</span>
          </a-menu-item>
        </a-sub-menu>
      </template>
      <a-button class="togMenus" @click="toggleCollapsed">
        <a-icon
          style="width:16px;height:16px"
          :type="collapsed ? 'menu-unfold' : 'menu-fold'"
        />
      </a-button>
    </a-menu>
  </a-layout-sider>
</template>

<script>
import menus from '@/router/menu'
import { getSessionStorage } from '../../utils/util'
export default {
  name: 'Nav',
  data() {
    return {
      selectedKeys: [],
      nav_list: JSON.parse(JSON.stringify(menus)),
      collapsed: true,
      show: true,
      defaultSelectedkeys: [
        getSessionStorage('defaultSelectedkeys')
          ? getSessionStorage('defaultSelectedkeys')
          : 'home',
      ],
      openKeys: [],
      disabled: getSessionStorage('disabled'),
    }
  },

  methods: {
    toggleCollapsed() {
      this.collapsed = !this.collapsed
      if (this.collapsed) {
        this.nav_list = JSON.parse(JSON.stringify(menus))
      } else {
        this.nav_list.forEach((element) => {
          if (element.children) {
            delete element.children
          }
        })
      }
    },
    load_route(route) {
      this.$router.push(route)
    },
    // getmenu(e) {
    getmenu() {
      sessionStorage.removeItem('groupCode')
      // setSessionStorage("defaultSelectedkeys", e.key);
    },
    render_route(routename) {
      let parent = ''
      this.selectedKeys = []
      this.openKeys = []
      this.selectedKeys.push(routename)
      menus.map((item) => {
        if (item.children) {
          item.children.map((child) => {
            if (child.key == routename) parent = item.key
          })
        }
      })
      // console.log(parent)
      parent && this.openKeys.push(parent) && this.selectedKeys.push(parent)
    },
  },
  watch: {
    $route: {
      handler(val) {
        if (val.name == 'createContract') {
          this.show = false
        } else {
          this.show = true
        }
        this.render_route(val.name)
      },
      // 深度观察监听
      deep: true,
    },
    // openKeys(val) {
    // let res = setSessionStorage("defaultOpenkeys", val);
    // },
    getdisabled() {
      this.disabled = this.$store.state.disabled
    },
  },
  mounted() {
    if (this.$route.name == 'createContract') {
      this.show = false
    }
    this.render_route(this.$route.name)
    // console.log('menus', menus)
  },
  computed: {
    getdisabled() {
      return this.$store.state.disabled
    },
  },
}
</script>
<style lang="scss" scoped>
::v-deep .ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected {
  line-height: 48px;
  height: 48px;
  background: #edf5ff;
}
::v-deep .ant-menu-item-selected {
  line-height: 48px;
  height: 48px;
  background: #edf5ff;
}
::v-deep .ant-menu-inline .ant-menu-item {
  line-height: 48px;
  height: 48px;
  margin-bottom: 0px;
  margin-top: 0px;
}
::v-deep .ant-menu-item {
  i {
    margin-right: 10px;
    font-size: 14px;
  }
}
.menu {
  position: relative;
}
.togMenus {
  position: absolute;
  display: flex;
  align-items: center;
  height: 40px;
  width: 100%;
  bottom: 0;
  border: 0;
  border-top: 1px solid #f1f1f1;
  padding-left: 16px;
}
</style>
