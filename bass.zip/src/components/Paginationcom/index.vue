<template>
  <div class="mz-antd-pagination">
    <a-pagination
      v-model="current"
      :total="total"
      :page-size="pageSize"
      @showSizeChange="onShowSizeChange"
    >
      <!-- <template slot="buildOptionText" slot-scope="props">
        <span>{{ props.value }}条/页</span>
      </template> -->
    </a-pagination>
  </div>
</template>

<script>
export default {
  props: {
    total: {
      type: Number,
      default: 0,
    },
    pageSize: {
      type: Number,
      default: 10,
    },
    pageSizeOptions: {
      type: Array,
      default() {
        return ["10", "20", "30", "40", "50"];
      },
    },
  },
  data() {
    return {
      current: 1,
      page_key: this.$route.name,
    };
  },
  mounted() {
    this.setitem_event.add({ key: this.page_key + '_page', func: this.onShowSize });
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key + '_page');
  },
  methods: {
    onShowSize() {
      this.pageSize = 10;
      this.current = 1;
      this.$emit("onShowSizeChange", this.current, this.pageSize);
    },
    onShowSizeChange(current, pageSize) {
      this.pageSize = pageSize;
      this.current = current;
      this.$emit("onShowSizeChange", current, pageSize);
    },
  },
  watch: {
    current(val) {
      this.$emit("onShowSizeChange", val, this.pageSize);
    },
  },
};
</script>

<style lang="scss" scoped>
.mz-antd-pagination {
  background: #fff ;
  padding-right: 20px !important;
  .ant-pagination {
    text-align: right !important;
    padding: 14px 0 !important;
  }
}
</style>
