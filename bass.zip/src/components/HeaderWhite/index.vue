<template>
  <a-layout-header class="_header">
    <div class="logo">

      <div>
        <div
          style="
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 16px;
            font-weight: 500;
          "
          v-if="org.orgLogo"
        >
          <img
            style="width: 35px; margin-right: 20px; height: 35px"
            :src="baseUrl+org.orgLogo"
            alt=""
          />
          <span> {{ org.orgHome }}</span>
        </div>
        <div style="font-size: 16px; font-weight: 500" v-else>
          <img style="width: 122px" src="../../img/top_logo@2x.png" alt="" />
          <span> {{ org.orgHome }}</span>
        </div>
      </div>

      <div><SetUpThe /></div>
    </div>
  </a-layout-header>
</template>

<script>
import SetUpThe from "../SetUpThe";
import { goToBrowser } from "@/mixins/goToBrowser";
import { getSessionStorage } from "@/utils/util";
import { api_config_info } from "@/utils/home";
export default {
  components: { SetUpThe },
  mixins: [goToBrowser],
  data() {
    return {
      imgsrc: getSessionStorage("imageUrl")
        ? getSessionStorage("imageUrl")
        : "",
      org: "",
      baseUrl:"http://192.168.3.101:9987"
    };
  },
  methods: {
    async getapi_config_info() {
      let res = await api_config_info();
      this.org = res.data.data;
    },
  },
  mounted() {
    // this.getapi_config_info();
  },
  watch: {
    getName() {
      // this.getapi_config_info();
    },
  },
  computed: {
    getName() {
      return this.$store.state.name;
    },
  },
};
</script>
<style lang="scss" scoped>

@include b(_header) {
  background: #fff !important;
  height: 48px;
  padding: 0 16px 0 11px;
}
@include b(ant-layout-header) {
  line-height: 0px;
}
.logo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
}
</style>