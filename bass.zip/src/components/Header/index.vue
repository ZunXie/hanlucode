<template>
  <div class="wrapper">
    <HeaderBlack v-if="blacktype" />
    <HeaderWhite v-else />
  </div>
</template>

<script>
import HeaderWhite from "../HeaderWhite";
import HeaderBlack from "../HeaderBlack";

export default {
  components: { HeaderWhite, HeaderBlack },
  data() {
    return {
      blacktype: false,
    };
  },
  mounted() {},
  watch: {
    $route: {
      handler(newRouter) {
        if (newRouter.name == "createContract") {
          this.blacktype = true;
        } else {
          this.blacktype = false;
        }
      },
      immediate: true,
    },
  },
};
</script>
<style lang="scss" scoped>
.wrapper{
    box-shadow: 0px 1px 4px 0px rgba(0, 21, 41, 0.12);
    z-index: 10;
}
</style>