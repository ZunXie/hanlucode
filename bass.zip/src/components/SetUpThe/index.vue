<template>
  <div class="wrapper">
    <a-space size="large">
      <a-tooltip placement="bottom">
        <template slot="title">
          <a style="color: #fff" @click="goHelp">查看帮助</a>
        </template>
        <a-icon class="hearico" type="question-circle" />
      </a-tooltip>

      <!-- 设置 -->
      <div class="seet">
        <a-dropdown placement="bottomCenter">
          <a-icon class="hearico" type="setting" />
          <a-menu @click="getSetting" slot="overlay">
            <a-menu-item v-for="(item, index) in MenuSeetList" :key="index">
              <a href="javascript:;">{{ item.title }}</a>
            </a-menu-item>
          </a-menu>
        </a-dropdown>
      </div>
    </a-space>

    <a-divider type="vertical" />
    <!-- 超级管理员 -->
    <a-dropdown>
      <span @click="(e) => e.preventDefault()">
        {{ user.userName }}<a-icon type="down" />
      </span>
      <a-menu slot="overlay">
        <a-menu-item>
          <a @click="getuser_loginOut" href="javascript:;">退出登录</a>
        </a-menu-item>
      </a-menu>
    </a-dropdown>

    <!-- 更换私钥弹框 -->
    <!-- <div class="isSeetShow"> -->
    <a-modal
      wrapClassName="isSeetShowstyle"
      v-model="isSeetShow"
      :width="360"
      centered
      title="更新钱包私钥"
    >
      <a-textarea
        placeholder="请输入您的助记词以导入钱包私钥"
        v-model="form.mnemonic"
        :rows="4"
      />
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button
          key="submit"
          type="primary"
          :disabled="disabled"
          @click="getPrivateKey"
        >
          更新
        </a-button>
      </template>
    </a-modal>
    <!-- </div> -->

    <!-- 燃料账户 -->
    <DrawerFuelAccount v-if="isFuelShow" :isFuelShow.sync="isFuelShow" />
    <!-- 子账号管理 -->
    <DrawerChildAccount
      v-if="isChildAccount"
      :isChildAccount.sync="isChildAccount"
    />

    <!-- 修改企业信息弹框 -->
    <a-modal v-model="isUserShow" centered title="修改企业信息">
      <a-form-model
        ref="ruleFormUser"
        :rules="rules"
        :layout="form.layout"
        :model="form"
      >
        <a-form-model-item label="组织名称:" prop="orgHome">
          <el-input v-model="form.orgHome" placeholder="请输入" />
        </a-form-model-item>
        <a-form-model-item label="LOGO:" prop="orgLogo">
          <a-upload
            name="avatar"
            list-type="picture-card"
            class="avatar-uploader"
            :show-upload-list="false"
            :fileList="fileList"
            :before-upload="beforeUpload"
            @change="handleChange"
            :customRequest="customRequest"
          >
            <img
              v-if="form.orgLogo"
              :src="baseUrl+form.orgLogo"
              style="width: 88px; height: 88px"
              alt="avatar"
            />
            <div v-else>
              <a-icon :type="loading ? '上传中...' : 'plus'" />
              <div class="ant-upload-text">上传图片</div>
            </div>
          </a-upload>
        </a-form-model-item>
        <div>图片尺寸为80*80px，支持jpg/png格式</div>
      </a-form-model>
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button
          key="submit"
          type="primary"
          @click="getModifyEnterprise('ruleFormUser')"
        >
          确定
        </a-button>
      </template>
    </a-modal>

    <!-- 修改密码 -->
    <a-modal :width="360" v-model="isPasswordShow" centered title="修改密码">
      <a-descriptions>
        <a-descriptions-item label="当前密码">
          <el-input
            size="small"
            style="width: 220px"
            v-model="password_list.password"
            placeholder="请输入"
          />
        </a-descriptions-item>
      </a-descriptions>
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button
          key="submit"
          type="primary"
          :disabled="disabledPassword"
          @click="handleOk"
        >
          确定
        </a-button>
      </template>
    </a-modal>
    <a-modal :width="400" v-model="isPasswordShowtwo" centered title="修改密码">
      <a-form-model
        :model="password_list"
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
        labelAlign="left"
        ref="ruleForm"
        :rules="rules"
      >
        <a-form-model-item prop="newPassword" label="新密码">
          <el-input
            size="small"
            placeholder="请输入"
            v-model="password_list.newPassword"
          />
        </a-form-model-item>

        <a-form-model-item prop="new2Password" label="确认新密码">
          <el-input
            size="small"
            placeholder="请输入"
            v-model="password_list.new2Password"
          />
        </a-form-model-item>
      </a-form-model>
      <template slot="footer">
        <a-button key="back" @click="handleCancel"> 取消 </a-button>
        <a-button
          key="submit"
          type="primary"
          :disabled="disabledPassword"
          @click="getuser_savePassword('ruleForm')"
        >
          确定
        </a-button>
      </template>
    </a-modal>
  </div>
</template>

<script>
import DrawerFuelAccount from "../DrawerFuelAccount";
import DrawerChildAccount from "../DrawerChildAccount";
import { goToBrowser } from "@/mixins/goToBrowser";

import {
  api_config_info,
  user_saveOrg,
  chainAccount_updateMnemonic,
  user_verifyPassword,
  user_savePassword,
  user_loginOut,
  user_info,
  user_uploadLogo,
} from "@/utils/home";
function getBase64(img, callback) {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
}
export default {
  name: "Header",
  mixins: [goToBrowser],
  components: { DrawerFuelAccount, DrawerChildAccount },

  data() {
    let newPassword = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入"));
      } else {
        if (this.password_list.newPassword !== "") {
          this.$refs.ruleForm.validateField("checkPass");
        }
        callback();
      }
    };
    let new2Password = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入"));
      } else if (value !== this.password_list.newPassword) {
        callback(new Error("请输入两次相同的密码"));
      } else {
        callback();
      }
    };
    return {
      baseUrl:"http://192.168.3.101:9987",
      rules: {
        newPassword: [{ validator: newPassword, trigger: "change" }],
        new2Password: [{ validator: new2Password, trigger: "change" }],
        orgHome: [{ required: true, message: "请输入名称", trigger: "blur" }],
        orgLogo: [{ required: true, message: "请上传图片", trigger: "change" }],
      },
      MenuSeetList: [
        { title: "更换私钥" },
        { title: "燃料账户" },
        { title: "子账号管理" },
        { title: "修改账户信息" },
        { title: "修改密码" },
      ],
      isSeetShow: false,
      isFuelShow: false,
      isChildAccount: false,
      isUserShow: false,
      isPasswordShow: false,
      disabled: true,
      password: "",
      disabledPassword: true,
      changePasswordVal: "",
      isPasswordShowtwo: false,
      form: {},
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
      password_list: {},
      loading: false,
      imageUrl: "",
      user: {},
      fileList: [],
    };
  },
  mounted() {
    // this.getuser_info();
  },
  methods: {
    //获取用户详情
    async getuser_info() {
      let res = await user_info();
      this.user = res.data.data;
    },
    // 退出登录
    async getuser_loginOut() {
      let res = await user_loginOut({});
      if (res.data.code == 200) {
        // window.sessionStorage.clear();
        this.$message.success("退出成功");
        sessionStorage.removeItem("checked");
        sessionStorage.removeItem("token");
        sessionStorage.removeItem("defaultOpenkeys");
        sessionStorage.removeItem("disabled");
        sessionStorage.removeItem("defaultSelectedkeys");
        sessionStorage.removeItem("groupCodeList");
        sessionStorage.removeItem("groupCodeAll");
        this.$router.push("login");
      }
    },
    async getSetting(e) {
      this.form = {};
      if (e.key == 0) {
        this.isSeetShow = true;
      } else if (e.key == 1) {
        this.isFuelShow = !this.isFuelShow;
      } else if (e.key == 2) {
        // this.isPasswordShow = true;}
        this.isChildAccount = !this.isChildAccount;
      } else if (e.key == 3) {
        this.isUserShow = true;
        let res = await api_config_info();
        this.form = res.data.data;
      } else if (e.key == 4) {
        this.isPasswordShow = true;
      }
    },
    showModal() {
      this.isSeetShow = true;
    },
    // 关闭弹框
    handleCancel() {
      this.isUserShow = false;
      this.isSeetShow = false;
      this.password_list = {};
      this.form = {};
      this.isPasswordShowtwo = false;
      this.isPasswordShow = false;
    },
    //校验密码
    async handleOk(e) {
      let res = await user_verifyPassword({
        password: this.password_list.password,
      });
      if (!res.data.data) {
        this.$message.error("当前密码不正确");
      } else {
        this.isPasswordShowtwo = true;
      }
    },
    //更新密码
    getuser_savePassword(formName) {
      if (!this.password_list.new2Password && !this.password_list.newPassword) {
        this.$message.warning("密码不可为空");
        return;
      }
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          let res = await user_savePassword(this.password_list);
          console.log(res.data.code);
          if (res.data.code == 200) {
            this.$message.success("修改成功");
            this.isPasswordShow = false;
            this.isPasswordShowtwo = false;
            this.password_list = {};
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 修改账户信息
    async getModifyEnterprise(formName) {
      // if(!this.imageUrl){
      //   this.$message.warning('请上传照片')
      //   return
      // }
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          let res = await user_saveOrg(this.form);
          if (res.data.code == 200) {
            this.$message.success("上传成功");
            this.$store.commit("NAME", Math.random());
            this.isUserShow = false;
          } else {
            this.$message.warning(res.data.msg);
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    //更换私钥
    async getPrivateKey() {
      let res = await chainAccount_updateMnemonic(this.form);
      if (res.data.code == 200) {
        this.$message.success("更新成功");
        this.isSeetShow = false;
      } else if (res.data.code == 9015) {
        this.$message.warning(res.data.msg);
      } else {
        this.$message.warning(res.data.msg);
        this.isSeetShow = false;
      }
    },
    async customRequest(params) {
      let fd = new FormData();
      fd.append("orgLogo", params.file);
      let res = await user_uploadLogo(fd, "multipart/form-data");
      this.form.orgLogo = res.data.data;
    },
    // 上传图片
    handleChange(file) {
      // if (info.file.status === "uploading") {
      //   this.loading = true;
      //   return;
      // }
      // if (info.file.status === "done") {
      //   // Get this url from response in real world.
      //   getBase64(info.file.originFileObj, (imageUrl) => {
      //     this.imageUrl = imageUrl;
      //     console.log(this.imageUrl);
      //     this.loading = false;
      //   });
      // }
    },
    beforeUpload(file) {
      const isJpgOrPng =
        file.type === "image/jpeg" || file.type === "image/png";
      if (!isJpgOrPng) {
        this.$message.error("仅支持jpg/png格式");
      }
      const isLt2M = file.size / 1024 / 1024 < 2;
      if (!isLt2M) {
        this.$message.error("请不要超过2MB!");
      }
      const is80x80 = true;
      let reader = new FileReader();
      reader.onload = (theFile) => {
        const image = new Image();
        image.src = theFile.target.result;
        image.onload = () => {
          const { width, height } = image;
          if (width !== 80 || height !== 80) {
            this.$message.error("请上传 80*80 px 的图片！");
            is80x80 = false;
          }
        };
      };
      console.log(is80x80);
      return isJpgOrPng && isLt2M && is80x80;
    },
  },
  watch: {
    // 监听输入框的值 判断按钮状态
    "form.mnemonic"(val) {
      if (val) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    },
    "password_list.password"(val) {
      if (val) {
        this.disabledPassword = false;
      } else {
        this.disabledPassword = true;
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.hearico {
  &:hover {
    color: #007aff;
  }
}
// 设置的下拉距离顶部的位置
.ant-dropdown-menu {
  margin-top: 20px;
  min-width: 140px;
}
.avatar-uploader > .ant-upload {
  width: 128px;
  height: 128px;
}
.ant-upload-select-picture-card i {
  font-size: 32px;
  color: #999;
}

.ant-upload-select-picture-card .ant-upload-text {
  margin-top: 8px;
  color: #666;
}
.ant-form-item {
  margin-bottom: 9px;
}

.ant-divider,
.ant-divider-vertical {
  margin: 0 20px;
}
.ant-dropdown-menu-item > a,
.ant-dropdown-menu-submenu-title > a {
  padding: 5px 16px;
}
// 私钥弹出框
::v-deep .isSeetShowstyle .ant-modal-body {
  padding: 33px 16px;
}
::v-deep .isSeetShowstyle .ant-modal-header {
  padding: 11px 16px;
}
::v-deep .isSeetShowstyle .ant-modal-content {
  border-radius: 2px;
}
</style>