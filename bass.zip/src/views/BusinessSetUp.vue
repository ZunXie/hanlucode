<template>
  <div class="BusinessSetUp">
    <div class="BusinessSetUp__alls">
      <div class="BusinessSetUp__alls__lefts">
        <div>服务费</div>
        <a @click="showModal"> 修改</a>
      </div>
      <div class="BusinessSetUp__alls__rights">
        <a-table
          :columns="columns"
          :pagination="false"
          :data-source="data_list"
          bordered
          size="middle"
        />
      </div>
    </div>
    <div class="BusinessSetUp__alls">
      <div class="BusinessSetUp__alls__lefts">
        <div>服务费</div>
        <a @click="getbuttonedit"> 修改</a>
      </div>
      <div class="BusinessSetUp__alls__rights">
        <a-table
          :columns="columns_bottom"
          :pagination="false"
          :data-source="data_list"
          bordered
          size="middle"
        />
      </div>
    </div>
    <!-- 修改服务费 -->
    <div v-if="visible">
      <a-modal v-model="visible" title="服务费修改" @ok="handleOk">
        <a-form-model
          ref="ruleForm"
          :model="form"
          :rules="rules"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-form-model-item ref="name" label="外卖类-商户服务费" prop="name">
            <a-space>
              <a-input-number :max="100000" v-model="form.name" />元/单
            </a-space>
          </a-form-model-item>
          <a-form-model-item ref="name" label="外卖类-用户服务费" prop="name2">
            <a-space>
              <a-input-number :max="100000" v-model="form.name2" />元/单
            </a-space>
          </a-form-model-item>
          <a-form-model-item ref="name" label="提现手续费" prop="name3">
            <a-space>
              <a-input-number :max="100000" v-model="form.name3" />元/单
            </a-space>
          </a-form-model-item> </a-form-model
        ><template slot="footer">
          <a-button type="primary" @click="onSubmit"> 提交 </a-button>
          <a-button style="margin-left: 10px" @click="resetForm">
            关闭
          </a-button>
        </template>
      </a-modal>
    </div>
    <div v-if="visible2">
      <a-modal v-model="visible2" title="服务费修改" @ok="handleOk">
        <a-form-model
          ref="ruleForm"
          :model="form"
          :rules="rules"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-form-model-item ref="name" label="外卖点餐" prop="name">
            <a-space>
              <a-input-number :max="100000" v-model="form.name" />元/单
            </a-space>
          </a-form-model-item>
          <a-form-model-item ref="name" label="外卖点餐+好评" prop="name2">
            <a-space>
              <a-input-number :max="100000" v-model="form.name2" />元/单
            </a-space>
          </a-form-model-item>
          <a-form-model-item ref="name" label="推广佣金" prop="name3">
            <a-space>
              <a-input-number :max="100000" v-model="form.name3" />元/单
            </a-space>
          </a-form-model-item> </a-form-model
        ><template slot="footer">
          <a-button type="primary" @click="onSubmit"> 提交 </a-button>
          <a-button style="margin-left: 10px" @click="resetForm">
            关闭
          </a-button>
        </template>
      </a-modal>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      visible: false,
      visible2: false,
      labelCol: { span: 8 },
      wrapperCol: { span: 14 },
      rules: {
        name: [
          {
            required: true,
            message: "Please input Activity name",
            trigger: "blur",
          },
        ],
        name2: [
          {
            required: true,
            message: "Please input Activity name",
            trigger: "blur",
          },
        ],
        name3: [
          {
            required: true,
            message: "Please input Activity name",
            trigger: "blur",
          },
        ],
      },
      columns: [
        {
          title: "外卖类",
          dataIndex: "name",
          key: "name",
          align: "center",
          children: [
            {
              title: "商户服务费",
              key: "name",
              dataIndex: "name",
              align: "center",
            },
          ],
        },
        {
          title: "外卖类",
          dataIndex: "companyAddress",
          key: "companyAddress",
          align: "center",
          children: [
            {
              title: "用户服务费",
              key: "companyAddress",
              dataIndex: "companyAddress",
              align: "center",
            },
          ],
        },
        {
          title: "外卖类",
          align: "center",
          dataIndex: "gender",
          key: "gender",
          children: [
            {
              title: "用户服务费",
              key: "gender",
              dataIndex: "gender",
              align: "center",
            },
          ],
        },
      ],
      form: {
        name: "",
        region: undefined,
        date1: undefined,
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },
      columns_bottom: [
        {
          title: "外卖点餐",
          dataIndex: "name",
          key: "name",
          align: "center",
        },
        {
          title: "外卖点餐+好评",
          dataIndex: "companyAddress",
          key: "companyAddress",
          align: "center",
        },
        {
          title: "推广佣金",
          align: "center",
          dataIndex: "gender",
          key: "gender",
        },
      ],
      data_list: [
        {
          key: 1,
          name: "John Brown",
          street: "Lake Park",
          building: "C",
          number: 2035,
          companyAddress: "Lake Street 42",
          companyName: "SoftLake Co",
          gender: "M",
        },
      ],
    };
  },
  created() {},
  methods: {
    showModal() {
      this.visible = true;
    },
    handleOk(e) {
      this.visible = false;
    },
    getbuttonedit() {
      this.visible2 = true;
    },
    onSubmit() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          alert("submit!");
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    resetForm() {
      this.$refs.ruleForm.resetFields();
      this.visible = false;
    },
  },
};
</script>

<style lang='scss' scoped>
@include b(BusinessSetUp) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 24px;
  @include e(alls) {
    display: flex;
    margin-bottom: 80px;
    @include e(lefts) {
      width: 300px;
    }
    @include e(rights) {
      width: 100%;
    }
  }
}
</style>
