<!-- 审核管理 -->
<template>
  <router-view v-if="route_key != 'AuditManagement'"></router-view>

  <div v-else class="AuditManagement">
    <a-tabs type="card" v-model="key" @change="callback">
      <a-tab-pane :key="1" tab="商户开户审核"> <OpenAnAccount /></a-tab-pane>
      <a-tab-pane :key="2" tab="订单审核(2审)"> <RulesSurvival /> </a-tab-pane>
      <a-tab-pane :key="3" tab="提现审核"> <ReflectAudit /> </a-tab-pane>
      <a-tab-pane :key="4" tab="任务审核"> <TaskReview /> </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script>
export default {
  data() {
    return {
      key: 1,
      route_key:""
    };
  },
  created() {
    this.key = this.getSessionStorage("key")?this.getSessionStorage("key"):1;
  },
   watch: {
    $route: {
      immediate: true,
      deep: true,
      handler: function (val) {
        this.route_key = val.name;
      },
    },
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key);
  },
  methods: {
    callback(key) {
      this.setSessionStorage("key", key);
    },
  },
  beforeDestroy() {
    this.setSessionStorage("key", 1);
  },
};
</script>

<style lang='scss' scoped>
@include b(AuditManagement) {
  margin: 24px;
  background: #fff;
  min-height: 612px;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(model) {
    @include e(Tips) {
      color: #9b9999;
    }
  }
}
</style>
