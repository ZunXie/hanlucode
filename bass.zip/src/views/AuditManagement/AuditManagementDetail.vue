<!-- 商户开户详情 -->
<template>
  <div class="AuditManagementDetail">
    <div class="AuditManagementDetail__title">商户开户审核</div>
    <a-form-model :model="form">
      <a-space :size="50">
        <a-form-model-item label="商家账号"> 12321423 </a-form-model-item>
        <a-form-model-item label="联系微信"> 13899996666 </a-form-model-item>
      </a-space>
      <a-form-model-item label="申请时间"> 2021-12-25 13:27 </a-form-model-item>
      <a-space :size="50">
        <a-form-model-item label="开户状态"> 待审核 </a-form-model-item>
        <a-form-model-item label="联系微信"> 13899996666 </a-form-model-item>
      </a-space>
      <a-form-model-item label="所属城市运营商">
        衡阳XX信息科技有限公司
      </a-form-model-item>
      <a-form-model-item label="所属业务员"> 张三 </a-form-model-item>

      <a-form-model-item label="店铺地址"> 张三 </a-form-model-item>
      <a-form-model-item label="所属业务员">
        湖南省衡阳市开山区中山路168号2号楼一楼
      </a-form-model-item>
      <a-form-model-item label="店铺定位">
        湖南省衡阳市开山区中山路168号
      </a-form-model-item>
      <a-form-model-item label="Resources">
        <a-radio-group v-model="form.resource">
          <a-radio :value="1"> Sponsor </a-radio>
          <a-radio :value="2"> Venue </a-radio>
        </a-radio-group>
      </a-form-model-item>
      <a-form-model-item :wrapper-col="{ span: 22, offset: 2 }">
        <a-button type="primary" @click="onSubmit"> Create </a-button>
      </a-form-model-item>
    </a-form-model>
  </div>
</template>
<script>
export default {
  data() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 },
      form: {
        name: "",
        region: undefined,
        date1: undefined,
        delivery: false,
        type: [],
        resource: 1,
        desc: "",
      },
    };
  },
  methods: {
    onSubmit() {
      console.log("submit!", this.form);
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(AuditManagementDetail) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 24px;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 16px;
  }
}
</style>
