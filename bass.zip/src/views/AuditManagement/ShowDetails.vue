<!-- 商户详情 -->
<template>
  <div class="MerchantDetails">
     <a-descriptions  :column='2' title="出款审核详情" bordered size='default'>
    <a-descriptions-item label="会员类别">
      Cloud Database
    </a-descriptions-item>
    <a-descriptions-item label="会员账号">
      Prepaid
    </a-descriptions-item>
    <a-descriptions-item label="会员名称">
      YES
    </a-descriptions-item>
    <a-descriptions-item label="申请时间">
      2018-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="出款状态" :span="2">
      2019-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="提现金额" :span="3">
      <a-badge status="processing" text="Running" />
    </a-descriptions-item>
    <a-descriptions-item label="手续费">
      $80.00
    </a-descriptions-item>
    <a-descriptions-item label="目标账户">
      $20.00
    </a-descriptions-item>
    <a-descriptions-item label="出款审核">
      $60.00
    </a-descriptions-item>
       <a-descriptions-item label="出款时间">
      $60.00
    </a-descriptions-item>
  </a-descriptions>
  </div>
</template>

<script>
export default {
  data() {
    return {
      size: "default",
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang='scss' scoped>
::v-deep .ant-descriptions-title {
  text-align: center;
  font-size: 20px !important;
}
@include b(MerchantDetails) {
  // display: flex;
  // align-items: center;
  // justify-content: center;
  padding: 24px;
      background: #fff;
min-height: 642px;
}
</style>
