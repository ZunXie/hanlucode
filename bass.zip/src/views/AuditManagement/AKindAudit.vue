<template>
  <div class="ModifyInformation">
    <div class="ModifyInformation__title">出款审核</div>
    <div class="ModifyInformation__model">
      <a-form-model labelAlign="left" :model="form">
        <div class="ModifyInformation__model__flexs">
          <a-form-model-item
            class="ModifyInformation__model__flexs__rights"
            label="会员类别"
          >
            13452354
          </a-form-model-item>
          <a-form-model-item label="会员账号"> 13452354 </a-form-model-item>
        </div>
        <div class="ModifyInformation__model__flexs">
          <a-form-model-item
            class="ModifyInformation__model__flexs__rights"
            label="会员名称"
          >
            凯文轻食
          </a-form-model-item>
          <a-form-model-item label="申请时间">
            2021-12-25 13:27
          </a-form-model-item>
        </div>

        <a-form-model-item label="出款状态"> 待审核 </a-form-model-item>

        <a-form-model-item label="提现金额"> 80元 </a-form-model-item>
        <div class="ModifyInformation__model__flexs">
          <a-form-model-item
            class="ModifyInformation__model__flexs__rights"
            label="手续费"
          >
            0.8元 </a-form-model-item
          ><a-form-model-item label="目标账户"> 微信 </a-form-model-item>
        </div>

        <a-form-model-item label="审核意见">
          <a-radio-group v-model="value" @change="onChange">
            <a-radio :value="1"> 同意 </a-radio>
            <a-radio :value="2"> 拒绝</a-radio>
          </a-radio-group>
        </a-form-model-item>

        <a-form-model-item class="ModifyInformation__button">
          <a-button type="primary" @click="onSubmit"> 提交 </a-button>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      value: 1,
      form: {},
    };
  },
  methods: {
    onChange(value) {
      console.log(value);
    },
    onSubmit() {
      console.log("submit!", this.form);
    },
    handleChange(value) {
      console.log("value");
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(ModifyInformation) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  width: 100%;
  margin: 24px;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 30px;
  }
  @include e(model) {
    @include e(flexs) {
      display: flex;
      @include e(rights) {
        width: 500px;
      }
    }
  }
}
</style>
