<template>
  <a-layout id="components-layout-demo-top-side-2">
    <Header />
    <a-layout>
      <Nav />
      <a-layout
        :style="{
          margin: 0,
          height: content_height,
          background: color,
        }"
      >
        <a-spin
          :spinning="
            this.$store.state.loadding && !this.$store.state.loaddingShow
          "
          tip="加载中..."
        >
          <a-layout-content>
            <router-view />
          </a-layout-content>
        </a-spin>
      </a-layout>
    </a-layout>
  </a-layout>
</template>
<script>
export default {
  data() {
    return {
      collapsed: false,
      content_height: '',
      color: '',
    }
  },
  created() {
    this.content_height =
      Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight
      ) -
      49 +
      'px'
    if (this.$route.name == 'createContract') {
      this.color = '#282d3d'
    }
  },
  watch: {
    $route: {
      handler(val) {
        if (val.name == 'createContract') {
          this.color = '#282d3d'
        } else {
          this.color = ''
        }
      },
      // 深度观察监听
      deep: true,
    },
  },
  mounted() {},
}
</script>
<style lang="scss" scoped>
// .ant-layout-sider {
// min-width: 207px !important;
// }
::v-deep .ant-menu-inline .ant-menu-item {
  padding-left: 17px !important;
}
::v-deep .ant-menu-submenu-title {
  padding-left: 17px !important;
}
::v-deep .ant-menu-submenu > .ant-menu span {
  padding-left: 26px !important;
}
::v-deep .ant-layout {
  background: #f5f7f9;
}
</style>
