<template>
  <div>
    <div class="wrapper">
      <div class="log">
        <span class="Hello">Hello!</span>
        <p>欢迎您&nbsp; <a>登录</a>&nbsp; BaaS！</p>
        <a-form-model
          ref="ruleForm"
          :model="ruleForm"
          :rules="rules"
          layout="vertical"
        >
          <a-form-model-item label="管理员账号" prop="userName">
            <a-input
              size="large"
              placeholder="请输入"
              v-model="ruleForm.userName"
            />
          </a-form-model-item>
          <a-form-model-item label="密码" prop="password">
            <a-input-password
              size="large"
              v-model="ruleForm.password"
              placeholder="请输入"
            />
          </a-form-model-item>

          <a-form-model-item>
            <a-button
              style="margin-top: 45px"
              block
              type="primary"
              @click="submitForm('ruleForm')"
            >
              登录
            </a-button>
          </a-form-model-item>
          <a-button
            type="link"
            block
            v-if="count > 0"
            @click="gettourists_getTourists"
          >
            试用账号
          </a-button>
        </a-form-model>
      </div>
    </div>
    <div class="companyRegister">
      <p>Copyright © 广州超级共识科技有限公司</p>
    </div>
  </div>
</template>

<script>
import { loginPassword, tourists_getTourists } from "../../src/utils/home";
import { setSessionStorage } from "@/utils/util";
export default {
  components: {},
  props: {},
  data() {
    let userName = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("账号不可为空"));
      } else {
        callback();
      }
    };
    let password = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("密码不可为空"));
      } else {
        callback();
      }
    };
    return {
      count: 0,
      ruleForm: {
        userName: "",
        password: "",
      },
      rules: {
        userName: [{ validator: userName, trigger: "change" }],
        password: [{ validator: password, trigger: "change" }],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          let passss = this.$md5(this.ruleForm.password); //此处将用户注册密码加密，再发给后端
          let params = {
            userName: this.ruleForm.userName,
            password: this.$md5(passss),
          };
          let res = await loginPassword(params);
          setSessionStorage("token", res.data.data);
          if (res.data.code !== 200) {
            this.$message.destroy();
            this.$message.warning(res.data.msg);
          } else {
            this.$message.success("登录成功");
            this.$router.push("/home");
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    async gettourists_getTourists() {
      let res = await tourists_getTourists();
      if (res.data.code === 200) {
        this.count++;
        if (this.count >= 2) {
          this.ruleForm.userName = res.data.data.userName;
          this.ruleForm.password = res.data.data.password;
        }
        console.log(this.count);
      }
    },
  },
  mounted() {
    this.gettourists_getTourists();
  },
};
</script>
<style lang="scss" scoped>
.wrapper {
  background-image: url("../../src/img/register_background@2x.png");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  -moz-background-size: 100% 100%;
  display: flex;
  align-items: center;
  min-height: 936px;
  .log {
    width: 396px;
    border-radius: 4px;
    background: $color-primary;
    margin: 0 auto;
    box-shadow: 6px 2px 30px 0px rgba(151, 155, 162, 0.08),
      -6px 2px 30px 0px rgba(151, 155, 162, 0.16);
    padding: 64px 48px 100px 48px;
    .Hello {
      font-size: $size-Large;
      font-weight: 500;
      color: $Black-85;
    }
    p {
      font-size: $size-bodyThe;
      color: $Black-45;
      margin: 8px 0 30px 0;
    }
  }
}
.companyRegister {
  text-align: center;
  font-size: $size-bodyThe;
  margin-top: -34px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: $Black-45;
}
.ant-form-item {
  margin-bottom: 12px;
}
.ant-btn-primary {
  height: 40px;
  background: #007aff;
  border-radius: 2px;
}
::v-deep .ant-form-item label {
  font-size: 12px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: rgba(0, 0, 0, 0.45);
}

::v-deep .ant-input-lg {
  border-radius: 2px;
}
::v-deep .ant-input {
  &::placeholder {
    font-size: 14px;
    font-weight: 400;
    color: rgba(0, 0, 0, 0.25);
  }
}
::v-deep .ant-input-password-icon {
  font-size: 16px;
}
</style>