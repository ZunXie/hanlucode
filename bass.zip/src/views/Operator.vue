<template>
  <div class="Userlog">
    <router-view v-if="route_key != 'Operator'"></router-view>
    <div v-else>
      <div class="searchFrom">
        <a-form-model layout="inline" :model="form">
          <div style="display: flex; justify-content: space-between">
            <div>
              <a-form-model-item label="注册手机">
                <el-input
                  size="small"
                  v-model="form.phone"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="运营商名称">
                <el-input size="small" v-model="form.name" placeholder="请输入" />
              </a-form-model-item>
              <a-form-model-item label="微信">
                <el-input size="small" v-model="form.wechat" placeholder="请输入" />
              </a-form-model-item>

              <a-form-model-item label="状态">
                <a-select   placeholder="请选择" v-model="form.state" style="width: 120px" @change="handleChange">
                  <a-select-option :value="0"> 正常 </a-select-option>
                  <a-select-option :value="1"> 解约 </a-select-option>
                </a-select>
              </a-form-model-item>
            </div>
            <div>
              <a-form-model-item>
                <a-space>
                  <a-button @click="getSearch" type="primary"> 查询 </a-button>
                  <a-button @click="getReseth" type="primary"> 重置 </a-button>
                  <a-button
                    type="primary"
                    @click="getOpenAnAccount"
                    icon="plus"
                  >
                    商户开户
                  </a-button>
                </a-space>
              </a-form-model-item>
            </div>
          </div>
        </a-form-model>
      </div>

      <div class="content_table">
        <a-table
          bordered
          :columns="columns"
          :pagination="false"
          :data-source="data_list"
          :locale="locale"
          :rowKey="(record) => record.id"
        >
          <template slot="rate" slot-scope="text, record">
            <span>{{ record.rate }}%</span>
          </template>
          <template slot="district_name" slot-scope="text, record">
            <span>{{ record.city_name }}{{ record.provinces_name }}</span>
          </template>
          <template slot="operation" slot-scope="text, record">
            <a-space>
              <a @click="getDetail(record)">详情</a>
              <a @click="getFormation(record)">修改</a>
            </a-space>
          </template>
        </a-table>
      </div>
      <Paginationcom
        :current="pagination.current"
        :total="pagination.totalCount"
        :page-size="pagination.pageSize"
        @onShowSizeChange="onShowSizeChange"
      />
    </div>
  </div>
</template>
<script>
import { operator_Operator_getDataGrid } from "@/utils/home";
export default {
  data() {
    return {
      locale: {
        emptyText: () => <Empty text="暂无操作日志" />,
      },
      form: {},
      // 表格数据
      columns: [
        {
          title: "运营商名称",
          dataIndex: "city_name",
          key: "city_name",
          // align: 'center',// 设置文本居中
        },
        {
          title: "运营区域",
          dataIndex: "district_name",
          scopedSlots: { customRender: "district_name" },
          key: "district_name",
        },
        {
          title: "注册手机",
          dataIndex: "phone",
          scopedSlots: { customRender: "phone" },
          key: "phone",
        },
        {
          title: "联系微信",
          key: "wechat",
          dataIndex: "wechat",
          scopedSlots: { customRender: "wechat" },
          // sorter: (a, b) => a.createTime - b.createTime,
        },
        {
          title: "结算周期",
          dataIndex: "settlement_interval_cn",
          scopedSlots: { customRender: "settlement_interval_cn" },
          key: "settlement_interval_cn",
        },
        {
          title: "分成比例",
          dataIndex: "rate",
          scopedSlots: { customRender: "rate" },
          key: "rate",
        },
        ,
        {
          title: "运营状态",
          dataIndex: "state_cn",
          scopedSlots: { customRender: "state_cn" },
          key: "state_cn",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          align: "center",
        },
      ],
      data_list: [],
      pagination: {
        current: 1,
        pageSize: 10,
        totalCount: 0,
      },
      page_key: this.$route.name,
      value1: [],
      route_key: "",
    };
  },
  methods: {
    // 分页组件
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.operator_Operator_getDataGrid();
    },
    // 运营商选择器
    handleChange(value) {
      console.log(`selected ${value}`);
    },
    // 商户开户
    getOpenAnAccount() {
      this.$router.push({
        name: "OperatorsToOpenAnAccount",
      });
    },
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getuser_userlog_list();
    },
    getTime(e) {
      this.form.startTime = e[0];
      this.form.endTime = e[1];
    },
    getSearch() {
      this.operator_Operator_getDataGrid(this.form);
      this.pagination.current = 1;
    },
    // 重置
    getReseth() {
      this.form = {};
      this.value1 = [];
      this.operator_Operator_getDataGrid()
    },
    async operator_Operator_getDataGrid(params) {
      let res = await operator_Operator_getDataGrid(params);
      this.data_list = res.data.data.lists;
      this.pagination.totalCount = res.data.data.total;
    },
    // 详情
    getDetail(item) {
      this.$router.push({
        name: "OperatorDetail", query: { id: item.id },
      });
    },
    // 商户信息修改
    getFormation(item) {
      this.setSessionStorage("Operator_list", item);
      this.$router.push({
        path: "ModifyThe",
       
      });
    },
  },
  created() {
    this.operator_Operator_getDataGrid();
  },
  watch: {
    $route: {
      immediate: true,
      deep: true,
      handler: function (val) {
        this.route_key = val.name;
      },
    },
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key);
  },
};
</script>
<style lang="scss" scoped>
.Userlog {
  margin: 24px 24px 48px 24px;
  .searchFrom {
    padding: 16px 0 16px 16px;
    background: $color-primary;
  }
}
.content_table {
  margin-top: 16px;
  background: $color-primary;
  padding: 16px 16px 0 16px;
  min-height: 612px;
}
.pagination_pas {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 40px;
  background: #970909;
  width: 100%;
  z-index: 1000;
}
</style>
