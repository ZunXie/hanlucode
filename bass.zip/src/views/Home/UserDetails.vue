<!--用户详情  -->
<template>
  <div class="UserDetails">
    <div class="UserDetails__imgs">
      <img
        style="width: 120px; height: 120px"
        src="../../img/cochain_cochain.png"
        alt=""
      />
    </div>
    <div class="UserDetails__table">
      <a-descriptions bordered :column="2">
        <a-descriptions-item label="手机">1380000111</a-descriptions-item>
        <a-descriptions-item label="会员ID">1810000000</a-descriptions-item>
        <a-descriptions-item label="微信昵称"
          >Hangzhou, Zhejiang</a-descriptions-item
        >
        <a-descriptions-item label="注册时间">empty</a-descriptions-item>
        <a-descriptions-item label="实名姓名">empty</a-descriptions-item>
        <a-descriptions-item label="上级推广员">empty</a-descriptions-item>
        <a-descriptions-item label="当前账户余额">empty</a-descriptions-item>
      </a-descriptions>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  created() {},
  methods: {},
};
</script>

<style lang='scss' scoped>
@include b(UserDetails) {
padding:  60px;
  background: #fff;
  min-height: 300px;
  display: flex;
  @include e(imgs) {
    padding-right: 32px;
  }
  @include e(table) {
    width: 100%;
  }
}
</style>
