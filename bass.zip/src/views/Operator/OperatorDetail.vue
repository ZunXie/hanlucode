<!-- 商户详情 -->
<template>
  <div class="MerchantDetails">
    <a-descriptions :column="2" title="运营商详情" bordered size="default">
      <a-descriptions-item label="运营商账号">
        {{ list.city_name }}
      </a-descriptions-item>
      <a-descriptions-item label="联系微信">
        {{ list.wechat }}
      </a-descriptions-item>
      <a-descriptions-item label="运营商名称">
        {{ list.city_name }}
      </a-descriptions-item>
      <a-descriptions-item label="运营城市">
        {{ list.city_name }}
      </a-descriptions-item>
      <a-descriptions-item label="分佣占比">
        {{ list.rate }}%
      </a-descriptions-item>
      <a-descriptions-item label="结算周期">
        {{ list.settlement_interval_cn }}
      </a-descriptions-item>
      <a-descriptions-item label="运营状态">
        {{ list.state_cn }}
      </a-descriptions-item>
    </a-descriptions>
  </div>
</template>

<script>
import { operator_Operator_getDataById } from "@/utils/home";
export default {
  data() {
    return {
      size: "default",
      list: {},
    };
  },
  methods: {},
  async mounted() {
    let params = { id: this.$route.query.id };
    let res = await operator_Operator_getDataById(params);
    this.list = res.data.data;
  },
};
</script>

<style lang='scss' scoped>
::v-deep .ant-descriptions-title {
  text-align: center;
  font-size: 20px !important;
}
@include b(MerchantDetails) {
  // display: flex;
  // align-items: center;
  // justify-content: center;
  padding: 24px;
  background: #fff;
  min-height: 642px;
}
</style>
