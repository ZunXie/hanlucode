<template>
  <!-- 商户开户 -->
  <div class="ModifyThe">
    <div class="ModifyThe__title">运营商开户</div>
    <div class="ModifyThe__model">
      <a-form-model labelAlign="left" :model="form">
        <a-form-model-item label="运营商账号">
          <a-input
            :disabled="true"
            v-model="form.phone"
            placeholder="Basic usage"
          />
        </a-form-model-item>
        <a-form-model-item label="联系微信">
          <a-space>
            <a-input v-model="form.wechat" placeholder="Basic usage" />
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="运营商名称">
          <a-input :disabled="true" placeholder="Basic usage" />
        </a-form-model-item>
        <a-form-model-item label="运营城市">
          <span
            >{{ form.city_name }}{{ form.city_name
            }}{{ form.provinces_name }}</span
          >
        </a-form-model-item>
        <a-form-model-item label="分佣占比">
          <a-space>
            <span>百分之</span>
            <a-input
              style="width: 100px"
              v-model="form.rate"
              placeholder="正整数"
            />
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="结算周期">
          <a-space>
            <a-radio-group
              v-model="form.settlement_interval"
              @change="onChange"
            >
              <a-radio :value="0"> 月结 </a-radio>
              <a-radio :value="`2`">季度结</a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="运营状态">
          <a-space>
            <a-radio-group v-model="form.state" @change="onChange">
              <a-radio :value="0"> 正常 </a-radio>
              <a-radio :value="1">解约</a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item
          :wrapper-col="{ span: 14, offset: 2 }"
          class="ModifyInformation__button"
        >
          <a-space>
            <a-button type="link" @click="goback"> 返回 </a-button>
            <a-button type="primary" @click="onSubmit"> 提交保存 </a-button>
          </a-space>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
import { operator_Operator_edit } from "@/utils/home";
export default {
  data() {
    return {
      form: {
        settlement_interval: 0,
        state: 0,
      },
      value: 1,
    };
  },
  methods: {
    goback() {
      this.$router.go(-1);
    },
    onChange(e) {
      console.log("radio checked", e.target.value);
    },
    onChange(value) {
      console.log(value);
    },
    async onSubmit() {
      let res = await operator_Operator_edit(this.form);
      if(res.data.code==200){
        this.$message.success(res.data.msg)
        this.$router.push({ path: "/Operator",})
      }
    },
    onChangetel(e) {
      console.log(`checked = ${e.target.checked}`);
    },
  },
  created() {
    this.form = this.getSessionStorage("Operator_list");
    console.log(this.form);
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(ModifyThe) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 0 auto;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(model) {
    @include e(Tips) {
      color: #9b9999;
    }
  }
}
</style>
