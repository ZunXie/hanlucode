<template>
  <!-- 商户开户 -->
  <div class="OpenAnAccount">
    <div class="OpenAnAccount__title">运营商开户</div>
    <div class="OpenAnAccount__model">
      <a-form-model
        ref="ruleForm"
        :rules="rules"
        labelAlign="left"
        :model="form"
      >
        <a-form-model-item label="运营商账号" prop="phone">
          <a-space>
            <a-input v-model="form.phone" placeholder="Basic usage" /><span
              class="OpenAnAccount__model__Tips"
              >审核通过后，系统默认密码888888</span
            >
          </a-space>
        </a-form-model-item>
        <a-form-model-item prop="wechat" label="联系微信">
          <a-space>
            <a-input
              v-model="form.wechat"
              placeholder="Basic usage"
            /><a-checkbox @change="onChangetel"> 同手机账号 </a-checkbox>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="运营商名称" prop="name">
          <a-input v-model="form.city_name" placeholder="Basic usage" />
        </a-form-model-item>
        <a-form-model-item label="运营城市">
          <a-cascader
            style="width: 300px"
            matchInputWidth="true"
            :options="options"
            change-on-select
            @change="onChange"
          />
        </a-form-model-item>
        <a-form-model-item label="分佣占比" prop="rate">
          <a-space>
            <span>百分之</span>
            <a-input
              v-model="form.rate"
              style="width: 100px"
              placeholder="正整数"
            />
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="结算周期" prop="settlement_interval">
          <a-space>
            <a-radio-group
              v-model="form.settlement_interval"
              @change="onChangestate"
            >
              <a-radio :value="0"> 月结 </a-radio>
              <a-radio :value="1">季度结</a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item
          :wrapper-col="{ span: 2, offset: 2 }"
          class="ModifyInformation__button"
        >
          <a-button type="primary" @click="getOperator_Operator_add">
            提交保存
          </a-button>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
import { CommonApiGetRegionCity, operator_Operator_add } from "@/utils/home";

export default {
  data() {
    let phone = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('请输入手机号'));
      }else{
        if(!/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(value)){
         callback(new Error('手机号格式不正确'));
        }else{
          callback()
        }
      }
     
    };
    return {
      form: {
        // 结算周期
        settlement_interval: 0,
        is_phone:0
      },
      rules: {
        name: [
          {
            required: true,
            message: "请输入运营账号",
            trigger: "blur",
          },
        ],
        phone: {
          validator: phone,
          trigger: "blur",
        },
        wechat: {
          required: true,
          message: "请输入联系微信",
          trigger: "blur",
        },
        rate: {
          required: true,
          message: "请输入分佣占比",
          trigger: "blur",
        },
      },
      // 省级信息
      options: [],
    };
  },
  methods: {
    onChangestate(e) {
      this.form.settlement_interval = e.target.value;
    },
    onChange(value) {
      this.form.provinces= value[0] ? value[0] : "";
      this.form.city = value[1] ? value[1] : "";
      this.form.district = value[2] ? value[2] : null;
    },
    // 手机同步
    onChangetel(e) {
      console.log(`checked = ${e.target.checked}`);
      this.form.is_phone = e.target.checked ? 1 : 0;
    },
    // 获取运营城市
    async getCommonApiGetRegionCity() {
      let res = await CommonApiGetRegionCity({});
      this.options = res.data.data;
    },
    // 运营商kaihu
    getOperator_Operator_add() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          let res = await operator_Operator_add(this.form);
          console.log(res);
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
  created() {
    this.getCommonApiGetRegionCity();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(OpenAnAccount) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 0 auto;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(model) {
    @include e(Tips) {
      color: #9b9999;
    }
  }
}
</style>
