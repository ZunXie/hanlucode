<!-- 账号管理 -->
<!-- 菜单管理 -->
<template>
  <div class="Userlog">
    <div class="searchFrom">
      <a-form-model layout="inline" :model="form">
        <div style="display: flex; justify-content: space-between">
          <a-form-model-item label="账号">
            <el-input
              size="small"
              v-model="formSearch.name"
              placeholder="请输入"
            />
          </a-form-model-item>

          <div>
            <a-form-model-item>
              <a-space>
                <a-button @click="getSearch" type="primary"> 查询 </a-button>
                <a-button @click="getAdd" type="primary"> 新增 </a-button>
              </a-space>
            </a-form-model-item>
          </div>
        </div>
      </a-form-model>
    </div>

    <div class="content_table">
      <a-table
        bordered
        :columns="columns"
        :pagination="false"
        :data-source="data_list"
        :locale="locale"
        :rowKey="(record) => record.id"
      >
        <template slot="display" slot-scope="text, record">
          <span>{{ record.display | display }}</span> </template
        ><template slot="state" slot-scope="text, record">
          <span>{{ record.state | state }}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a @click="getEditor(record)">编辑</a>
        </template>
      </a-table>
    </div>
    <Paginationcom
      :current="pagination.current"
      :total="pagination.totalCount"
      :page-size="pagination.pageSize"
      @onShowSizeChange="onShowSizeChange"
    />

    <div v-if="visible">
      <a-modal
        @cancel="getcancel"
        v-model="visible"
        :title="title"
        @ok="handleOk"
        ><template slot="footer">
          <a-button type="primary" @click="getSystem_AdminMenu_add">
            提交
          </a-button>
          <a-button style="margin-left: 10px" @click="resetForm">
            关闭
          </a-button>
        </template>
        <a-form-model ref="ruleForm" :model="form" :rules="rules">
          <a-form-model-item label="角色名字" prop="name">
            <a-input v-model="form.name" />
          </a-form-model-item>

          <a-form-model-item label="状态" prop="states">
            <a-switch v-model="form.states" />
          </a-form-model-item>
        </a-form-model>
      </a-modal>
    </div>
  </div>
</template>
<script>
import {
  system_AdminRole_add,
  system_AdminRole_getDataGrid,
  system_AdminRole_edit,
} from "../../utils/Permissions";
export default {
  name: "Userlog",
  data() {
    let password = (rule, value, callback) => {
      if (value === "" && this.title == "新增账号") {
        callback(new Error("请输入密码"));
      } else {
        callback();
      }
    };
    let rpassword = (rule, value, callback) => {
      if (value === "" && this.title == "新增账号") {
        callback(new Error("请输入密码"));
      } else if (value !== this.form.password && this.title == "新增账号") {
        callback(new Error("两次密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      locale: {
        emptyText: () => <Empty text="暂无操作日志" />,
      },
      visible: false,
      other: "",
      form: {},
      formSearch: {
        name: "",
      },
      rules: {
        password: [
          {
            validator: password,
            trigger: "change",
          },
        ],
        rpassword: [
          {
            validator: rpassword,
            trigger: "change",
          },
        ],
        account: [{ required: true, message: "请输入账号", trigger: "change" }],
      },

      // 表格数据
      columns: [
        {
          title: "ID",
          dataIndex: "id",
          key: "id",
          // align: 'center',// 设置文本居中
        },

        {
          title: "状态",
          dataIndex: "state",
          scopedSlots: { customRender: "state" },
          key: "state",
        },
        {
          title: "角色名称",
          dataIndex: "name",
          scopedSlots: { customRender: "name" },
          key: "name",
        },
        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          align: "center",
        },
      ],
      data_list: [],
      value1: [],
      pagination: {
        //分页数据
        current: 1,
        pageSize: 10,
        totalCount: 0,
      },
      title: false,
    };
  },
  created() {
    this.getSystem_AdminRole_getDataGrid();
  },
  methods: {
    // 关闭弹框清楚校验
    getcancel() {
      this.form = {};
      this.$refs.ruleForm.resetFields();
    },
    resetForm() {
      this.visible = false;
    },
    // 菜单提交
    getSystem_AdminMenu_add() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          if (this.title == "新增账号") {
            let params = JSON.parse(JSON.stringify(this.form));
            params.state = params.states ? 1 : 0;
            let res = await system_AdminRole_add(params);
            if (res.data.code == 200) {
              this.$message.success(res.data.msg);
              this.getSystem_AdminRole_getDataGrid();
              // 清除数据
              this.resetForm();
            }
          } else {
            let params = JSON.parse(JSON.stringify(this.form));
            params.state = params.states ? 1 : 0;
            let res = await system_AdminRole_edit(params);
            if (res.data.code == 200) {
              this.$message.success(res.data.msg);
              this.getSystem_AdminRole_getDataGrid();
              // 清除数据
              this.resetForm();
            }
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    //新增
    getAdd() {
      this.visible = true;
      this.title = "新增角色";
    },
    // 编辑
    async getEditor(item) {
      this.title = "编辑角色";
      let params = JSON.parse(JSON.stringify(item));
      this.form = params;
      this.form.states = params.state == 1 ? true : false;
      this.form = JSON.parse(JSON.stringify(this.form));
      this.visible = true;
    },
    // 列表数据
    async getSystem_AdminRole_getDataGrid(menu_name) {
      let params = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        name: this.formSearch.name,
      };
      let res = await system_AdminRole_getDataGrid(params);
      this.data_list = res.data.data.lists;
      this.pagination.totalCount = res.data.data.total;
    },
    // 查询
    async getSearch() {
      await this.getSystem_AdminRole_getDataGrid();
      this.pagination.current = 1;
    },

    handleOk(e) {
      this.visible = false;
    },
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getSystem_AdminRole_getDataGrid();
    },
    getTime(e) {
      this.form.startTime = e[0];
      this.form.endTime = e[1];
    },

    // 重置
    getReseth() {
      this.form = {};
      this.value1 = [];
    },
    async getuser_userlog_list() {
      this.form.pageNum = this.pagination.current;
      this.form.pageSize = this.pagination.pageSize;
      let res = await user_userlog_list(this.form);
      this.data_list = res.data.data.rows;
      this.pagination.totalCount = res.data.data.total;
    },
    // 详情
    getDetail(item) {
      this.$router.push({
        name: "userDetails",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
.Userlog {
  margin: 24px 24px 48px 24px;
  .searchFrom {
    padding: 16px 0 16px 16px;
    background: $color-primary;
  }
}
.content_table {
  margin-top: 16px;
  background: $color-primary;
  padding: 16px 16px 0 16px;
  min-height: 612px;
}
.pagination_pas {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 40px;
  background: #970909;
  width: 100%;
  z-index: 1000;
}
</style>

