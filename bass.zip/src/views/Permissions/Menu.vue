<!-- 菜单管理 -->
<template>
  <div class="Userlog">
    <div class="searchFrom">
      <a-form-model layout="inline" :model="form">
        <div style="display: flex; justify-content: space-between">
          <div>
            <a-form-model-item label="菜单名称">
              <el-input size="small" v-model="menu_name" placeholder="请输入" />
            </a-form-model-item>
          </div>
          <div>
            <a-form-model-item>
              <a-space>
                <a-button @click="getSearch" type="primary"> 查询 </a-button>
                <a-button @click="getAdd" type="primary"> 新增 </a-button>
              </a-space>
            </a-form-model-item>
          </div>
        </div>
      </a-form-model>
    </div>

    <div class="content_table">
      <a-table
        bordered
        :columns="columns"
        :pagination="false"
        :data-source="data_list"
        :locale="locale"
        :rowKey="(record) => record.id"
      >
        <template slot="display" slot-scope="text, record">
          <span>{{ record.display | display }}</span> </template
        ><template slot="state" slot-scope="text, record">
          <span>{{ record.state | state }}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a @click="getEditor(record)">编辑</a>
        </template>
      </a-table>
    </div>
    <Paginationcom
      :current="pagination.current"
      :total="pagination.totalCount"
      :page-size="pagination.pageSize"
      @onShowSizeChange="onShowSizeChange"
    />

    <div>
      <a-modal
        @cancel="getcancel"
        v-model="visible"
        :title="title"
        @ok="handleOk"
        ><template slot="footer">
          <a-button type="primary" @click="getSystem_AdminMenu_add">
            提交
          </a-button>
          <a-button style="margin-left: 10px" @click="resetForm">
            关闭
          </a-button>
        </template>
        <a-form-model ref="ruleForm" :model="form" :rules="rules">
          <a-form-model-item label="菜单名称" prop="menu_name">
            <a-input v-model="form.menu_name" />
          </a-form-model-item>
          <a-form-model-item label="菜单地址" prop="menu_url">
            <a-input v-model="form.menu_url" />
          </a-form-model-item>
          <a-form-model-item label="菜单ICON" prop="menu_icon">
            <a-input v-model="form.menu_icon" />
          </a-form-model-item>
          <a-form-model-item label="是否显示" prop="display">
            <a-switch v-model="form.displays" />
          </a-form-model-item>
          <a-form-model-item label="菜单状态" prop="state">
            <a-switch v-model="form.states" />
          </a-form-model-item>
        </a-form-model>
      </a-modal>
    </div>
  </div>
</template>
<script>
import {
  system_AdminMenu_add,
  system_AdminMenu_getDataGridd,
  system_AdminMenu_edit,
} from "../../utils/Permissions";
export default {
  name: "Userlog",
  data() {
    return {
      locale: {
        emptyText: () => <Empty text="暂无操作日志" />,
      },
      visible: false,

      other: "",
      form: { display: false, state: true },
      menu_name: "",
      rules: {
        menu_name: [
          {
            required: true,
            message: "请输入菜单名称",
            trigger: "blur",
          },
        ],
        menu_url: [
          {
            required: true,
            message: "请输入菜单地址",
            trigger: "change",
          },
        ],
        p_mid: [
          { required: true, message: "请输入ICON(图标)", trigger: "change" },
        ],
        menu_icon: [{ required: true, message: "请选择", trigger: "change" }],
      },

      // 表格数据
      columns: [
        {
          title: "序号",
          dataIndex: "rank_order",
          key: "rank_order",
          // align: 'center',// 设置文本居中
        },
        {
          title: "菜单名称",
          dataIndex: "menu_name",
          key: "menu_name",
        },
        {
          title: "菜单URL",
          dataIndex: "menu_url",
          scopedSlots: { customRender: "menu_url" },
          key: "menu_url",
        },
        {
          title: "ID",
          key: "mid",
          dataIndex: "mid",
          scopedSlots: { customRender: "mid" },
          // sorter: (a, b) => a.createTime - b.createTime,
        },
        {
          title: "父级ID",
          dataIndex: "p_mid",
          scopedSlots: { customRender: "p_mid" },
          key: "p_mid",
        },
        {
          title: "显示",
          dataIndex: "display",
          scopedSlots: { customRender: "display" },
          key: "display",
        },
        {
          title: "状态",
          dataIndex: "state",
          scopedSlots: { customRender: "state" },
          key: "state",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          align: "center",
        },
      ],
      data_list: [],
      value1: [],
      pagination: {
        //分页数据
        current: 1,
        pageSize: 10,
        totalCount: 0,
      },
      title: "",
      abc: "",
    };
  },
  created() {
    this.getSystem_AdminMenu_getDataGridd();
  },
  methods: {
    // 关闭弹框清楚校验
    getcancel() {
    this.$refs.ruleForm.resetFields();
    },
    resetForm() {
      this.form={}
      this.visible = false;
    },
    // 菜单提交
    getSystem_AdminMenu_add() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          if (this.title == "新增菜单") {
            let params = JSON.parse(JSON.stringify(this.form));
            params.display = this.form.displays ? 1 : 0,
              params.state = this.form.states ? 1 : 0;
            let res = await system_AdminMenu_add(params);
            if (res.data.code == 200) {
              this.$message.success(res.data.msg);
              this.getSystem_AdminMenu_getDataGridd();
              // 清除数据
              this.resetForm();
            }
          } else {
            let params = this.form;
            (params.display = this.form.displays ? 1 : 0),
              (params.state = this.form.states ? 1 : 0);
            let res = await system_AdminMenu_edit(params);
            if (res.data.code == 200) {
              this.$message.success(res.data.msg);
              this.getSystem_AdminMenu_getDataGridd();
              // 清除数据
              this.resetForm();
            }
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 编辑
    async getEditor(item) {
      this.title = "编辑菜单";
      this.form = item;
      this.form.states = item.state == 0 ? false : true;
      this.form.displays = item.display == 0 ? false : true;
       this.form=JSON.parse(JSON.stringify( this.form))
      this.visible = true;
    },
    // 列表数据
    async getSystem_AdminMenu_getDataGridd(menu_name) {
      let params = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        menu_name: menu_name,
      };
      let res = await system_AdminMenu_getDataGridd(params);
      this.data_list = res.data.data.lists;
      this.pagination.totalCount = res.data.data.total;
    },
    // 查询
    async getSearch() {
      await this.getSystem_AdminMenu_getDataGridd(this.menu_name);
      this.pagination.current = 1;
    },
    getAdd() {
      this.resetForm();
      this.title = "新增菜单";
      this.visible = true;
    },
    handleOk(e) {
      this.visible = false;
    },
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getSystem_AdminMenu_getDataGridd();
    },
    getTime(e) {
      this.form.startTime = e[0];
      this.form.endTime = e[1];
    },

    // 重置
    getReseth() {
      this.form = {};
      this.value1 = [];
    },
    async getuser_userlog_list() {
      this.form.pageNum = this.pagination.current;
      this.form.pageSize = this.pagination.pageSize;
      let res = await user_userlog_list(this.form);
      this.data_list = res.data.data.rows;
      this.pagination.totalCount = res.data.data.total;
    },
    // 详情
    getDetail(item) {
      this.$router.push({
        name: "userDetails",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
.Userlog {
  margin: 24px 24px 48px 24px;
  .searchFrom {
    padding: 16px 0 16px 16px;
    background: $color-primary;
  }
}
.content_table {
  margin-top: 16px;
  background: $color-primary;
  padding: 16px 16px 0 16px;
  min-height: 612px;
}
.pagination_pas {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 40px;
  background: #970909;
  width: 100%;
  z-index: 1000;
}
</style>
