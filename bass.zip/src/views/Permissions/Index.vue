<template>
  <div class="Index">
    <router-view />
  </div>
</template>
<script>
export default {
  name: "Index",
  data() {
    return {
      title: "",
    };
  },
};
</script>