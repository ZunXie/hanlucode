<template>
  <div class="ModifyInformation">
    <div class="ModifyInformation__title">商户信息修改</div>
    <div class="ModifyInformation__model">
      <a-form-model labelAlign="left" :model="form">
        <a-form-model-item label="商家账号">
          <a-input
            style="width: 200px"
            v-model="form.name"
            placeholder="Basic usage"
          />
        </a-form-model-item>
        <a-form-model-item label="联系微信">
          <a-space>
            <a-input
              style="width: 200px"
              v-model="form.phone"
              placeholder="Basic usage"
            /><a-checkbox v-model="form.is_phones">
              同手机账号
            </a-checkbox></a-space
          >
        </a-form-model-item>
        <a-form-model-item label="城市运营商">
          <a-input
            style="width: 200px"
            v-model="form.city_operator"
            placeholder="Basic usage"
          />
        </a-form-model-item>
        <a-form-model-item label="所属业务员">
          <a-select
            default-value="lucy"
            style="width: 120px"
            v-model="form.salesmen"
            @change="handleChange"
          >
            <a-select-option value="jack"> Jack </a-select-option>
            <a-select-option value="lucy"> Lucy </a-select-option>
            <a-select-option value="disabled" disabled>
              Disabled
            </a-select-option>
            <a-select-option value="Yiminghe"> yiminghe </a-select-option>
          </a-select>
        </a-form-model-item>

        <a-form-model-item label="店铺地址">
          <span>
            <a-space>
              <a-cascader
                matchInputWidth="true"
                :options="options"
                change-on-select
                v-model="selectDep"
                placeholder="选择"
                @change="onChange"
              />
              <a-input-search
                placeholder="请输入"
                style="width: 300px"
                v-model="form.addr"
                enter-button
                @search="onSearch"
              />
            </a-space>
          </span>
        </a-form-model-item>
        <Map @getaddr="getaddrValue" :adddrsearchData="adddrsearch" />
        <a-form-model-item class="ModifyInformation__button">
          <a-button type="primary" @click="onSubmit"> 提交保存 </a-button>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
import { shop_Shop_edit, shop_Shop_add } from "../../utils/Merchant";
import { goToBrowser } from "@/mixins/goToBrowser";

export default {
  mixins: [goToBrowser],
  data() {
    return {
      selectDep: [], //默认选中数据，由id组成的数组
      isinputShow: false,
      adddrsearch: "",
      form: {
        addr: "",
        is_phones: false,
      },
      options: [],
      city: "",
      arr: [],
      selfKey: "NBGG0NtbzhSLZiLHWi79bNQbuTnbjtZ9",
    };
  },
  created() {
    this.options = this.getSessionStorage("Region");
  },

  methods: {
    onSearch(value) {
      this.adddrsearch = this.city + value;
    },
    getaddas(val, city) {
      let arr = [];
      val.map((item) => {
        if (city.provinces == item.label) {
          arr.push(item.value);
        }
        if (item.children) {
          item.children.map((item2) => {
            if (city.city == item2.label) {
              arr.push(item2.value);
            }
            if (item2.children) {
              item2.children.map((item3) => {
                if (city.district == item3.label) {
                  arr.push(item3.value);
                }
              });
            }
          });
          this.selectDep = arr;
        }
      });
    },
  
    getaddrValue(val) {
      this.getaddas(this.options, val);
      this.form.provinces = val.provinces;
      this.form.city = val.city;
      this.form.district = val.district;
      this.form.address = val.address;
      this.form.addr = val.address;
    },
    onChange(value, selectedOptions) {
      this.city = selectedOptions.map((o) => o.label).join("");
      if (selectedOptions.length == 3) {
        this.form.provinces = selectedOptions[0].label;
        this.form.city = selectedOptions[1].label;
        this.form.district = selectedOptions[2].label;
        this.form.address = this.form.addr;
      }
      this.adddrsearch = this.city;
    },

    async onSubmit() {
      // 根据地址转化经纬度
      let adds = await this.getaddrlau(this.form.addr);
      // console.log(adds);
      this.form.is_phone = this.form.is_phones ? 1 : 0;
      this.form.latitude = await adds.location.lat;
      this.form.longitude = await adds.location.lng;
      let res = await shop_Shop_add(this.form);
      // console.log(res);
      console.log("submit!", this.form);
    },
    handleChange(value) {
      console.log("value");
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(ModifyInformation) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  width: 100%;

  margin: 0 auto;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    margin: 30px 60px;
  }
}
</style>
