<!-- 商户详情 -->
<template>
  <div class="MerchantDetails">
     <a-descriptions  :column='2' title="商户详情" bordered size='default'>
    <a-descriptions-item label="商家账号">
      Cloud Database
    </a-descriptions-item>
    <a-descriptions-item label="联系微信">
      Prepaid
    </a-descriptions-item>
    <a-descriptions-item label="外卖店铺名">
      YES
    </a-descriptions-item>
    <a-descriptions-item label="开户时间">
      2018-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="开户状态" :span="2">
      2019-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="所属城市运营商" :span="3">
      <a-badge status="processing" text="Running" />
    </a-descriptions-item>
    <a-descriptions-item label="所属业务员">
      $80.00
    </a-descriptions-item>
    <a-descriptions-item label="店铺地址">
      $20.00
    </a-descriptions-item>
    <a-descriptions-item label="店铺定位">
      $60.00
    </a-descriptions-item>
   
  </a-descriptions>
  </div>
</template>

<script>
export default {
  data() {
    return {
      size: "default",
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang='scss' scoped>
::v-deep .ant-descriptions-title {
  text-align: center;
  font-size: 20px !important;
}
@include b(MerchantDetails) {
  // display: flex;
  // align-items: center;
  // justify-content: center;
  padding: 24px;
      background: #fff;
min-height: 642px;
}
</style>
