<!-- 账户变动明细 -->
<template>
  <div class="ChangesInDetail">
    <div class="ChangesInDetail__all">
      <div class="ChangesInDetail__title">
        <a-form-model layout="inline" :model="form">
          <div style="text-align: center">
            <a-space>
              <a-form-model-item label="会员账号"> 12323 </a-form-model-item>
              <a-form-model-item label="会员类型"> 超级vip </a-form-model-item>
              <a-form-model-item label="会员名称">
                超级
              </a-form-model-item></a-space
            >
          </div> </a-form-model
        ><a-divider />
      </div>
      <div class="ChangesInDetail__bottom">
        <div class="ChangesInDetail__detail">
          <div class="ChangesInDetail__detail__lefts">2021年12月</div>
          <div class="ChangesInDetail__detail__rights">
            <div style="font-size: 12px; color: #dfdfdf">
              收入120.5，支出100.5
            </div>
          </div>
        </div>
        <a-divider />
        <div class="ChangesInDetail__detail">
          <div class="ChangesInDetail__detail__lefts">
            <a-space direction="vertical"
              ><div style="font-size: 14px; color: #000">充值</div>
              <div style="font-size: 14px; color: #dfdfdf; font-weight: 600">
                08-17 13:16
              </div></a-space
            >
          </div>
          <div class="ChangesInDetail__detail__rights">
            <a-space direction="vertical"
              ><div>+1509px</div>
              <div style="font-size: 14px; color: #dfdfdf">
                08-17 13:16
              </div></a-space
            >
          </div>
        </div>
        <a-divider />
      </div>
    </div>
  </div>
</template>22

<script>
export default {
  data() {
    return {
      form: {},
    };
  },
  created() {},
  methods: {},
};
</script>

<style lang='scss' scoped>
::v-deep .ant-divider-horizontal {
  margin: 10px 0;
}
::v-deep .ant-space-item {
  margin-bottom: 0 !important;
}
@include b(ChangesInDetail) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 24px;
  @include e(all) {
    margin: 0 auto;
    // display: flex;
    // justify-content: center;
    width: 500px;
  }
  @include e(bottom) {
    width: 300px;
    margin: auto;
  }
  @include e(detail) {
    display: flex;
    justify-content: center;
    margin-top: 10px;
    // border-bottom: 2px solid red;
    @include e(lefts) {
      width: 180px;
      font-size: 16px;
      overflow: hidden;
      text-overflow: ellipsis;
      padding-right: 30px;
    }
    @include e(rights) {
      width: 180px;
;text-align: end;
      overflow: hidden;
      text-overflow: ellipsis;
      padding-right: 30px;
    }
  }
}
</style>
