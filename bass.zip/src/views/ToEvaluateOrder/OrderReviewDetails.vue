<!-- 商户开户详情 -->
<template>
  <div class="AuditManagementDetail">
    <div class="AuditManagementDetail__title">订单审核(2审)</div>
    <div class="AuditManagementDetail__forms">
      <div class="AuditManagementDetail__alls">
        <div class="AuditManagementDetail__alls__lefts">
          <a-form-model :model="form">
            <div v-for="item in listleft" :key="item.key">
              <a-form-model-item :label="item.label">
                <div v-if="item.type == 'img'">
                  <img :src="item.value" alt="" />
                </div>
                <div v-else>{{ item.value }}</div>
              </a-form-model-item>
            </div>
          </a-form-model>
        </div>
        <div class="AuditManagementDetail__alls__rights">
          <a-form-model :model="form">
            <div v-for="item in listright" :key="item.key">
              <a-form-model-item v-if="item.key !== '0'" :label="item.label">
                <div v-if="item.type == 'img'">
                  <img :src="item.value" alt="" />
                </div>
                <div v-else>{{ item.value }}</div>
              </a-form-model-item>
              <a-form-model-item v-else>
                <div style="height: 43px"></div>
              </a-form-model-item>
            </div>
          </a-form-model>
        </div>
      </div>
      <a-form-model :model="form">
        <a-form-model-item label="商家审核意见">
          <a-space direction="vertical">
            <div>不通过</div>
            <div>
              <img
                src="../../img/2021-12-31/deploy_big_correct@2x.png"
                alt=""
              />
              <img
                style="margin-left: 200px"
                src="../../img/2021-12-31/deploy_big_correct@2x.png"
                alt=""
              />
            </div>
          </a-space>
        </a-form-model-item>
      </a-form-model>
      <div >
        <a-form-model :model="form">
          <a-form-model-item label="平台审核意见">
            不通过
          </a-form-model-item>
        </a-form-model>
        
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      form: {},
      value: 1,

      listleft: [
        { label: "店铺名称：", value: "苏发生", key: "1" },
        { label: "任务名称：", value: "苏发生", key: "2" },
        { label: "任务类型：", value: "苏发生", key: "3" },
        { label: "任务单量", value: "苏发生", key: "4" },
        { label: "商家服务费", value: "苏发生", key: "5" },
        { label: "用户昵称", value: "苏发生", key: "6" },
        { label: "报名订单号：", value: "苏发生", key: "7" },
        {
          label: "订单截图",
          value: require("../../img/2021-12-31/deploy_big_correct@2x.png"),
          key: "8",
          type: "img",
        },
      ],
      listright: [
        { label: "所属运营商", value: "苏发生", key: "1" },
        { label: "任务时间", value: "苏发生", key: "0" },

        { label: "任务时间", value: "苏发生", key: "2" },
        { label: "测评酬金", value: "苏发生", key: "3" },
        { label: "测评总金额", value: "苏发生", key: "4" },
        { label: "手机尾号", value: "苏发生", key: "5" },
        { label: "订单状态", value: "苏发生", key: "6" },
        {
          label: "好评截图",
          value: require("../../img/2021-12-31/deploy_big_correct@2x.png"),
          key: "7",
          type: "img",
        },
      ],
    };
  },
  methods: {
    onChange(e) {
      console.log("radio checked", e.target.value);
    },
    onSubmit() {
      console.log("submit!", this.form);
    },
  },
  mounted() {
    console.log(this.$route.query.isShow);
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 8px;
}
@include b(AuditManagementDetail) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 24px;
  @include e(forms) {
    width: 634px;
  }
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 16px;
  }
  @include e(alls) {
    display: flex;
    align-items: center;
    // justify-content: space-around;
    @include e(lefts) {
      width: 360px;
    }
    @include e(rights) {
      // width: 50%;
    }
  }
}
</style>
