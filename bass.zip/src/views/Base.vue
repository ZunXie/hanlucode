<template>
    <div class="base">
        <Layout />
    </div>
</template>
<script>
import Layout from "@/views/Layout.vue";

export default {
    name: "Base",
    components: {
        Layout,
    },
};
</script>
