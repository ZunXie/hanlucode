<!-- 平台自发任务 -->
<template>
  <div class="TaskWork">
    <div class="TaskWork__title">运营商开户</div>
    <div class="TaskWork__model">
      <a-form-model labelAlign="left" :model="form">
        <a-form-model-item label="测评分类">
          <a-space>
            <a-radio-group v-model="value" @change="onChange">
              <a-radio :value="1"> 外卖 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="店铺所在平台">
          <a-space>
            <a-radio-group v-model="value" @change="onChange">
              <a-radio :value="1"> 美团 </a-radio>
              <a-radio :value="2"> 饿了么 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="店铺名称">
          <a-input placeholder="不填则默认不限" />
        </a-form-model-item>
        <a-form-model-item label="店铺链接地址">
          <a-input
            style="width: 300px"
            placeholder="不限店铺时，地址请复制外卖频道主页地址"
          />
        </a-form-model-item>
        <a-form-model-item label="任务类型">
          <a-space>
            <a-radio-group v-model="value" @change="onChange">
              <a-radio :value="1"> 外卖点餐+好评 </a-radio>
              <a-radio :value="2"> 外卖点餐 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-space :size="60">
          <a-form-model-item label="测评时间">
            <a-select
              default-value="lucy"
              :dropdownMatchSelectWidth="false"
              size="small"
              @change="handleChange"
            >
              <a-select-option value="jack"> Jack </a-select-option>
              <a-select-option value="lucy"> Lucy </a-select-option>
              <a-select-option value="disabled" disabled>
                Disabled
              </a-select-option>
              <a-select-option value="Yiminghe"> yiminghe </a-select-option>
            </a-select>
          </a-form-model-item>
          <a-form-model-item label="报名截止"> 13::13 </a-form-model-item>
        </a-space>

        <a-form-model-item label="每单测评酬金">
          <a-space><a-input size="small" style="width: 55px" />元</a-space>
        </a-form-model-item>
        <a-form-model-item label="任务单量">
          <a-space><a-input size="small" style="width: 55px" />元</a-space>
        </a-form-model-item>
        <a-form-model-item label="报名用户">
          <a-space>
            <a-radio-group v-model="value" @change="onChange">
              <a-radio :value="1"> 不限 </a-radio>
              <a-radio :value="2"> 首次报名 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-space :size="60">
          <a-form-model-item label="测评酬金">
            <span>_____元</span>
          </a-form-model-item>
          <a-form-model-item label="平台服务费：">
            <span>_____元(2元/单)</span></a-form-model-item
          >
        </a-space>
         <a-form-model-item label="任务费用总计">
          <span>_________元</span>
        </a-form-model-item>
         <a-form-model-item label="账户可用余额">
          <span>充足</span>
        </a-form-model-item>
        <a-form-model-item
          :wrapper-col="{ span: 2, offset: 2 }"
          class="ModifyInformation__button"
        >
          <a-button type="primary" @click="onSubmit"> 提交发布 </a-button>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
import { CommonApiGetRegionCity } from "@/utils/home";
export default {
  data() {
    return {
      form: {
        name: "",
        region: undefined,
        date1: undefined,
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },
      value: 1,
      options: [
        {
          value: "zhejiang",
          label: "Zhejiang",
          children: [
            {
              value: "hangzhou",
              label: "Hangzhou",
              children: [
                {
                  value: "xihu",
                  label: "West Lake",
                },
              ],
            },
          ],
        },
        {
          value: "jiangsu",
          label: "Jiangsu",
          children: [
            {
              value: "nanjing",
              label: "Nanjing",
              children: [
                {
                  value: "zhonghuamen",
                  label: "Zhong Hua Men",
                },
              ],
            },
          ],
        },
      ],
    };
  },
  methods: {
    onChange(e) {
      console.log("radio checked", e.target.value);
    },
    onChange(value) {
      console.log(value);
    },
    onSubmit() {
      console.log("submit!", this.form);
    },
    onChangetel(e) {
      console.log(`checked = ${e.target.checked}`);
    },
    handleChange(e) {},
    // 获取运营城市
    async getCommonApiGetRegionCity() {
      let res = await CommonApiGetRegionCity({});

      this.options = res.data.data;
    },
  },
  created() {
    this.getCommonApiGetRegionCity();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(TaskWork) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  margin: 0 auto;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(model) {
    @include e(Tips) {
      color: #9b9999;
    }
  }
}
</style>


