<template>
  <div class="ModifyInformation">
    <div class="ModifyInformation__title">消息详情</div>
    <div class="ModifyInformation__model">
      <a-form-model labelAlign="left" :model="form">
        <a-form-model-item label="标题">
          <a-input style="width: 200px" placeholder="Basic usage" />
        </a-form-model-item>
        <a-form-model-item label="消息类别">
          <a-space>
            <a-radio-group :disabled="this.$route.query.isShow?false:true"  v-model="value" @change="onChange">
              <a-radio :value="1"> 轮播图 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="展示端口：">
          <a-space>
            <a-radio-group :disabled="this.$route.query.isShow?false:true" v-model="value" @change="onChange">
              <a-radio :value="1"> 仅用户端 </a-radio>
              <a-radio :value="2"> 仅商户端 </a-radio>
              <a-radio :value="3"> 全部 </a-radio>
            </a-radio-group>
          </a-space>
        </a-form-model-item>
        <a-form-model-item label="图片上传">
          <a-upload
            name="file"
            :multiple="true"
            action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
            :headers="headers"
            @change="handleChange"
          >
            <a-button> <a-icon type="upload" /> 点击上传图片 </a-button>
          </a-upload>
        </a-form-model-item>
        <a-form-model-item label="链接地址">
          <a-input placeholder="无需链接可不填写" />
        </a-form-model-item>
        <a-form-model-item label="展示状态：">
          <a-space direction="vertical">
            <a-space>
              <a-radio-group :disabled="this.$route.query.isShow?false:true"  v-model="value" @change="onChange">
                <a-radio :value="1" > 正常 </a-radio>
                <a-radio :value="2"> 关闭 </a-radio>
              </a-radio-group>
            </a-space>
            <a-button v-if="this.$route.query.isShow"
             type="primary" @click="onSubmit"> 提交保存 </a-button>
          </a-space>
        </a-form-model-item>
      </a-form-model>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      value: 1,
      form: {},
      options: [],
      headers: {
        authorization: "authorization-text",
      },
    };
  },
  methods: {
    handleChange(info) {
      if (info.file.status !== "uploading") {
        console.log(info.file, info.fileList);
      }
      if (info.file.status === "done") {
        this.$message.success(`${info.file.name} file uploaded successfully`);
      } else if (info.file.status === "error") {
        this.$message.error(`${info.file.name} file upload failed.`);
      }
    },
    onChange(value) {
      console.log(value);
    },
    onSubmit() {
      console.log("submit!", this.form);
    },
    handleChange(value) {
      console.log("value");
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-form-item {
  display: flex;
  margin-bottom: 16px;
}
@include b(ModifyInformation) {
  background: #fff;
  padding: 60px;
  min-height: 612px;
  width: 100%;
  margin: 0 auto;
  @include e(title) {
    font-size: 20px;
    font-weight: 600;
    // text-align: center;
    margin-bottom: 30px;
  }
  @include e(button) {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 30px;
  }
}
</style>
