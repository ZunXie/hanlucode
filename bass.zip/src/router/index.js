import Vue from 'vue'
import VueRouter from 'vue-router'
import menus from './menu'
import { getSessionStorage } from '@/utils/util'

if (!window.VueRouter) {
  Vue.use(VueRouter)
}
//懒加载
let routes = [
  {
    path: '/',
    name: 'base',
    component: () => import('../views/Base.vue'),
    children: menus_to_route(menus),
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/Login.vue'),
    children: menus_to_route(menus),
  },
]
const router = new VueRouter({
  mode: 'history',
  routes,
})
const originalPush = VueRouter.prototype.push

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err)
}

router.beforeEach((to, from, next) => {
  //判断是不是在同一路由 不在就清空
  // if (
  //   from.name &&
  //   from.path !== '/home' &&
  //   from.path !== '/createContract' &&
  //   from.path !== '/contractTemplate' &&
  //   from.path !== '/browser' &&
  //   from.path !== '/blockDetails' &&
  //   from.path !== '/igentContract' &&
  //   from.path !== '/managements' &&
  //   to.path !== from.path
  // ) {
  //   sessionStorage.removeItem('groupCode')
  // }
  // 没有token 就到登录页面
  if (to.path === '/login') {
    next()
  } else {
    let token = getSessionStorage('token')
    if (!token) {
      next('/login')
    } else {
      next()
    }
  }
  // 清空无用的页面缓存
  let toDepth = to.path.split('/').length
  let fromDepth = from.path.split('/').length
  if (toDepth < fromDepth) {
    from.meta.keepAlive = false
    to.meta.keepAlive = true
  }
  next()
})
function menus_to_route(menus) {
  if (!menus || !menus.length) return
  let res = menus.map((item) => {
    let route = {
      path: item.path || '/' + item.key,
      name: item.key,
      component: item.component,
      meta: {
        keepAlive: true,
      },
      children: menus_to_route(item.children),
    }
    return route
  })
  return res
}
export default router
