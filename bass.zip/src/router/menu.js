let menus = [
{
  icon: 'home',
  name: '用户管理',
  path: '/home',
  key: 'home',
  component: () => import('../views/Home.vue'),
  children: [
    {
      icon: 'question',
      name: '用户详情',
      key: 'userDetails',
      show: false,
      hideen: true,
      component: () => import('../views/Home/UserDetails.vue'),
    },
  ],
},
{
  icon: 'deployment-unit',
  name: '商户管理',
  key: 'merchant',
  path: '/merchant',
  component: () => import('../views/Merchant.vue'),
  children: [
    {
      icon: 'question',
      name: '商户详情',
      key: 'MerchantDetails',
      show: false,
      hideen: true,
      component: () => import('../views/Merchant/MerchantDetails.vue'),
    },
    {
      icon: 'question',
      name: '商户详情',
      key: 'ModifyInformation',
      show: false,
      hideen: true,
      component: () => import('../views/Merchant/ModifyInformation.vue'),
    },
    {
      icon: 'question',
      name: '商户详情',
      key: 'OpenAnAccount',
      show: false,
      hideen: true,
      component: () => import('../views/Merchant/OpenAnAccount.vue'),
    },
  ],
},
{
  icon: 'deployment-unit',
  type: 'icon',
  name: '运营商管理',
  key: 'Operator',
  component: () => import('../views/Operator.vue'),
  children: [
    {
      icon: 'question',
      name: '区块详情',
      key: 'OperatorDetail',
      hideen: true,
      component: () => import('../views/Operator/OperatorDetail.vue'),
    },

    {
      icon: 'question',
      name: '区块详情',
      key: 'OperatorsToOpenAnAccount',
      hideen: true,
      component: () => import('../views/Operator/OperatorsToOpenAnAccount.vue'),
    },
    {
      icon: 'question',
      name: '区块详情',
      key: 'ModifyThe',
      hideen: true,
      component: () => import('../views/Operator/ModifyThe.vue'),
    },
  ],
},
{
  icon: 'home',
  name: '任务管理',
  path: '/TaskManagement',
  key: 'TaskManagement',
  component: () => import('../views/TaskManagement.vue'),
  children: [
    {
      icon: 'question',
      name: '平台自发任务',
      key: 'TaskWork',
      hideen: true,
      component: () => import('../views/TaskManagement/TaskWork.vue'),
    },


  ],
},
{
  icon: 'home',
  name: '审核管理',
  path: '/AuditManagement',
  key: 'AuditManagement',
  component: () => import('../views/AuditManagement.vue'),
  children: [
    {
      icon: 'question',
      name: '区块详情',
      key: 'AuditManagementDetail',
      hideen: true,
      component: () => import('../views/AuditManagement/AuditManagementDetail.vue'),
    },
    {
      icon: 'question',
      name: '区块详情',
      key: 'OrderSecondTrial',
      hideen: true,
      component: () => import('../views/AuditManagement/OrderSecondTrial.vue'),
    },
    {
      icon: 'question',
      name: '区块详情',
      key: 'AKindAudit',
      hideen: true,
      component: () => import('../views/AuditManagement/AKindAudit.vue'),
    },
    {
      icon: 'question',
      name: '区块详情',
      key: 'ShowDetails',
      hideen: true,
      component: () => import('../views/AuditManagement/ShowDetails.vue'),
    },
  ],
},
{
  icon: 'home',
  name: '消息管理',
  path: '/MessageManagement',
  key: 'MessageManagement',
  component: () => import('../views/MessageManagement.vue'),
  children: [
    {
      icon: 'question',
      name: '区块详情',
      key: 'NewDetail',
      hideen: true,
      component: () => import('../views/MessageManagement/NewDetail.vue'),
    }
  ],
},
{
  icon: 'home',
  name: '测评订单查询',
  path: '/ToEvaluateOrder',
  key: 'ToEvaluateOrder',
  component: () => import('../views/ToEvaluateOrder.vue'),
  children: [
    {
      icon: 'question',
      name: '区块详情',
      key: 'OrderReviewDetails',
      hideen: true,
      component: () => import('../views/ToEvaluateOrder/OrderReviewDetails.vue'),
    }
  ],
},
{
  icon: 'home',
  name: '业务设置',
  path: '/BusinessSetUp',
  key: 'BusinessSetUp',
  component: () => import('../views/BusinessSetUp.vue'),
},
{
  icon: 'home',
  name: '会员账户查询',
  path: '/MemberAccount',
  key: 'MemberAccount',
  component: () => import('../views/MemberAccount.vue'), children: [
    {
      icon: 'question',
      name: '账户变动明细',
      key: 'ChangesInDetail',
      hideen: true,
      component: () => import('../views/MemberAccount/ChangesInDetail.vue'),
    }]
  }, {
    icon: 'safety-certificate',
    name: '权限配置管理',
    key: 'Permissions',
    show: true,
    component: () => import('../views/Permissions/Index.vue'),
    children: [
      {
        icon: 'question',
        name: '菜单权限',
        key: 'Menu',
        component: () => import('../views/Permissions/Menu.vue'),
      },
      {
        icon: 'question',
        name: '账号权限',
        key: 'Account',
        component: () => import('../views/Permissions/Account.vue'),
      },
      {
        icon: 'question',
        name: '角色权限',
        key: 'RoleManagement',
        component: () => import('../views/Permissions/RoleManagement.vue'),
      }
    ],
  }, 
   {
    icon: 'safety-certificate',
    name: '权限配置管理',
     key: 'OperatorsWillCommission',
     component: () => import('../views/OperatorsWillCommission.vue'),
   
  },
]

export default menus
