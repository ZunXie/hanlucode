[TOC]

# 超级共识-矩链开放平台-BaaS系统-开发者文档

## 1. 发布路线

### 1.1 V1.0

### 1.2 V2.0

### 1.3 V2.1

## 2. 整体介绍

### 2.1 简介概述

区块链是一个典型的分布式协同系统，多方共同维护一个不断增长的分布式数据记录，这些数据通过密码学技术保护内容和时序，使得任何一方难以篡改、抵赖、造假。区块链根据不同需求和场景可分为公有链、联盟链和私有链。

超级共识矩链（MatrixChain）通过引入 P2P 网络、共识算法、虚拟机、智能合约、密码学、数据存储等技术特性，构建一个稳定、高效、安全的图灵完备智能合约执行环境，提供账户的基本操作以及面向智能合约的功能调用。基于矩链提供的能力和功能特性，应用开发者能够完成基本的账户创建、合约调用、结果查询、事件监听等。矩链以联盟链为目标，突破商业与金融应用场景，率先实现有自主权的工业级与金融级区块链系统，具有高可靠性、高可运维性、高安全性和适配全球部署等优势。

区块链 BaaS（Blockchain-as-a-Service）平台依托矩链开放平台，提供简单易用，一键部署，快速验证，灵活可定制的区块链服务，加速区块链业务应用开发、测试、上线，助力各行业区块链商业应用场景落地。提供高性能，稳定可靠，隐私安全，多种类型数据的区块链存证能力。

矩链BaaS 平台基于矩链提供基础技术能力，并输出定制化的区块链整体解决方案，应用于诸如数据存证与溯源、多方参与的业务协同、资产登记流转等场景。

### 2.2 核心优势

#### 2.2.1 超高性能

MatrixChain致力于打造最快的区块链底层技术。性能一直是区块链技术被广泛应用的最大障碍。MatrixChain基于大规模节点快速共识技术、AOT加速的WASM虚拟机技术等核心技术，保证了MatrixChain的超高性能。并高分通过全行业的功能、性能测评，单链性能达8.7W TPS。

#### 2.2.2 高可扩展

MatrixChain致力于打造最通用的区块链底层技术。不同的应用场景对于区块链的使用需求不同，为了适应更多的场景，底层技术需要能够可扩展。MatrixChain基于动态内核技术，实现无内核代码侵入的自由扩展内核核心组件和轻量级的扩展订制内核引擎，满足面向不同场景的区块链实现的需求。并且不同的模块有丰富的技术选型。

#### 2.2.3 高度易用

MatrixChain致力于打造最好用的区块链底层技术。MatrixChain具有丰富的生态工具、官方文档教程、7*24小时开源社区支持，大大降低开发者的使用门槛。能够帮助用户快速上手，构建自己的区块链应用。

#### 2.2.4 开箱即用

提供一站式区块链服务能力，支持一键快速部署区块链与智能合约，用户无需关注区块链底层的复杂逻辑，有效降低区块链使用门槛。

#### 2.2.5 开发友好

- 支持JavaSDK、JsDK、GoSDK等多语言的SDK，且提供丰富的API接口，充分满足用户对区块链操作的各种需求
- 基于典型业务场景，提供丰富的通用合约模板，提供最佳区块链应用实践路径，帮助企业专注于上层业务的探索与研发

#### 2.2.6 按需定制

平台提供1对1专属顾问及全面技术支持，第一时间响应并解决问题，且支持定制化解决方案、技术专家提供区块链研发培训等个性化功能。

#### 2.2.7 快速迭代

依托行业领先的技术研发团队，根据金融、政务、民生等领域客户的实际需求实现产品功能的快速更新迭代，支持平台用户抢鲜体验最新全量功能。

### 2.3 功能特性

#### 2.3.1 自动化部署

区块链节点软件采用自动化部署方式，根据用户申请需求快速自动建立区块链平台。对于区块链节点软件版本更新，可后台各节点逐步升级，同时不影响区块链功能。

#### 2.3.2 联盟链管理

- 用户填入创建联盟的相关信息后，平台将自动化创建联盟链，在联盟页可看到已创建的联盟
- 根据用户配置的联盟链信息在用户购买的云主机资源上部署对应的联盟链
- 支持对联盟链进行启用、停用、重启等操作，支持修改联盟链参数配置信息
- 支持对联盟链的节点进行新增、删除、启用、停用、重启等操作，支持修改节点参数配置信息

#### 2.3.3 合约管理

- 支持对联盟链的节点进行新增、删除、启用、停用、重启等操作，支持修改节点参数配置信息
- 支持对已经部署成功的合约实例执行调用、升级、冻结、解冻、下载编译结果、删除等操作
- 支持用户对合约模板执行创建、查看、编辑代码、修改信息、删除等操作，提升合约模板管理效率

#### 2.3.4 区块链浏览器

可通过区块链浏览器查询交易数目，节点信息、最近出块信息、块中包含的交易信息、区块信息查询、交易信息。

### 2.4 基本术语

| 术语 | 说明 |
| ------------------------------------------------ | ------------------------------------------------------------ |
| 区块链技术 (Blockchain Technology)               | 区块链技术是一种由多种密码学算法、共识算法、块链式存储结构和对等网络等技术共同组成的分布式技术集合。通过区块链技术，能够保障数据的强一致性、防篡改等特性，实现数据共享和价值传输。 |
| 链 (Chain)                                       | 由区块按照生成的顺序连接而成，是整个账本状态变化的日志记录，在区块链中又分为公有链和私有链以及联盟链，顾名思义，私有链就是私人节点，不是所有人都能参与的区块链，公有链是所有人都能参与的，并且会根据算力的不同而产生分支，而联盟链则是由经过授权的不同的角色一起参与，类似一种环形链，不会产生分支。 |
| 共识算法 (Consensus Algorithm)                   | 共识算法是用于保证分布式系统一致性的机制。这里的一致性可以是交易顺序的一致性、账本一致性、节点状态的一致性等。 |
| 节点 (Node)                                     | 在联盟链中，每个角色可以拥有一个或多个节点，区块链网络中的每一个节点，就相当于存储所有区块信息的每一台电脑或者服务器终端。所有新区块的产生，以及交易的验证与记账，并将其广播给全联盟同步，都由节点完成。 |
| 交易 (Transaction)                               | 交易是指每次对账本的操作导致账本状态的一次变化，就是一笔交易，交易内容包含源账户、目的账户、调用的方法信息、是否共识、合约类型等信息。 |
| 交易回执 (Transaction Receipt)                   | 交易的执行结果。区块链系统中，由于节点执行交易后需要完成共识过程，因此需在交易回执中查看该笔交易的最终执行结果。 |
| 默克尔树 (Merkle Tree)                           | 默克尔树是一 种二叉树，是树状的完整数据结构，在其叶顶点中有来自数据块的哈希值，而内部顶点包含通过在子顶点中添加值而得到的哈希值。 |
| 区块 (Block)                                     | 区块记录一段时间内发生的所有交易和状态结果等，是对当前账本状态的一次共识，比如默认500毫秒生成一个区块或者每500笔交易生成一个区块。区块内容包含区块编号、区块hash、父hash、写入时间、交易数等信息。 |
| 区块头 (Block Header)                            | 区块头应包含当前区块的属性信息和链接信息。属性信息包括时间戳、区块序号等。链接信息一般是用能唯一标识前序区块特征的哈希值代表。 |
| 区块体 (Block Body)                              | 区块记录一段时间内发生的所有交易和状态结果等，是对当前账本状态的一次共识，比如默认500毫秒生成一个区块或者每500笔交易生成一个区块。区块内容包含区块编号、区块hash、父hash、写入时间、交易数等信息。 |
| 区块哈希 (Block Hash)                            | 将区块内容通过哈希算法得到的指纹信息，唯一表示一个区块。     |
| 区块高度 (Block Height)                          | 当前区块链上出块（Block）的最大数目。                        |
| 公/私钥 (Public/Private Key)                     | 区块链中的密钥分为公钥和私钥两种，公钥与私钥是通过一种算法得到的一个密钥对(即一个公钥一个私钥)，公钥是密钥对中公开的部分，私钥则是非公开的部分。一般使用私钥对交易进行签名，使用公钥对签名进行验证（私钥可以生成公钥，而公钥无法倒推私钥）。 |
| 证书 (Certificate)                               | 证书是联盟链的准入机制，只有获取联盟链的证书才能成功接入联盟链，起到一个通行证的作用。 |
| 证书颁发机构 (Certificate Authority,CA)          | 数字证书颁发机构是受信任的第三方机构，颁发的数字证书是为最终用户数据加密的公共密钥。 |
| 数字签名 (Digital Signature)                     | 数据签名主要作为每笔交易的证明，由交易发起方生成(经私钥加密)，保证这个交易是由发起方发起并且证明交易信息在交易过程中没有被篡改。 |
| 验签 (Verify)                                    | 当交易方拿到发送方发送过来的数据后，使用公钥对数据进行验证签名，保证此数据来源正确和未被篡改。 |
| 国密算法 (National Secret Algorithm)             | 国家密码局认定的国产密码算法,主要有SM1，SM2，SM3，SM4。      |
| 可信执行环境 (Trusted Execution Environment,TEE) | 指可信的、隔离的、独立的执行环境,为隐私数据和敏感计算提供安全而机密的空间,其安全性通常通过硬件相关的机制来保障。 |
| 隐私交易 (Private Transaction)                   | 用户在发送交易时指定该笔交易的相关方，只有这一相关方可存储该交易明细，而隐私交易的哈希在全网共识后存储在公共账本，既保证了隐私数据的有效隔离，又可验证该隐私交易的真实性，实现交易的可验不可见。 |
| 分布式数字身份 (Decentralized Identity,DID)      | 分布式数字身份由DID、DID文档、可验证凭证三部分组成，DID为用户在数字世界的唯一标识，DID文档为DID在数字世界的身份单干，包含账户公钥、账户状态、授权管理账户等信息，可验证凭证是桥接用户数字世界身份与现实世界身份的桥梁，用于表述、证明DID账户持有人在现实世界的身份属性。 |
| 智能合约 (Smart Contract)                        | 智能合约是指在区块链网络中自动执行的程序，执行的规则由具体的业务应用抽象而来，必要时执行的规则可更新。 |
| 虚拟机 (Virtual machine,VM)                      | 执行智能合约的沙箱环境。                                     |
| 燃料 (Gas)                                       | 在区块链上发起交易时，需要消耗一定的计算和存储资源，由于这些资源是有限的，因此每笔交易需要消耗一定的燃料作为限制，可防止DDoS等恶意攻击造成的资源恶意消耗。 |
| 世界状态 (World State)                           | 每一笔交易的执行，即意味着账户状态的一次转移，也代表着区块链系统账本的一次状态转移。相对于创世状态，最新的区块链账本状态被称为世界状态。 |
| 数据归档 (Data Archiving)                        | 指为了满足监管合规性要求，将不再使用或者活跃度低于一定阈值的数据记录转移到独立的存储上。数据归档之后需要建立必要的索引，方便监管审计时查询使用。 |
| ContractSDK    | 智能合约SDK，提供给合约开发者的智能合约编程接口   |
| 合约账户       | 用于智能合约管理的单元                           |
| 系统合约       | 默认的系统智能合约，比如平行链管理、治理代币、账户权限管理等 |
| 热插拔共识机制 | 能够通过链上治理机制是实现升级的可插拔共识机制               |
| 拜占庭节点     | 网络中恶意节点，它们可以发起任意行动，不遵守协议规则         |
| 二层共识       | 采用二层共识协议，外层共识决定验证人集合，内层共识协同进行区块打包 |
| 候选人节点     | 当前选定的区块打包的候选人集合                   |
| 验证人集合     | 当前选定的区块打包的候选人集合                   |
| Chained-BFT    | 基于Hotstuff实现的链式BFT模块，具有拜占庭容错、高性能等特点 |
| XPoS共识       | DPoS+Chained-BFT组成的二层共识，更适用于公开网络场景 |
| XPoA共识       | PoA+Chained-BFT组成的二层共识，更适用于联盟网络场景 |
| 种子节点       | 网络中用于节点加入和发现的节点，网络中任何节点都可以作为种子节点 |
| NetURL         | 网络中节点的链接地址，新节点可以通过配置种子节点的NetURL加入网络 |
| BaaS平台 | 区块链即服务平台，提供区块链部署、区块链监控运维、合约研发等一系列服务，降低区块链研发技术门槛，加速区块链业务落地。 |
| UTXO | 未花费的交易输出，是底层交易生成及验证的核心概念 |

## 3. 快速入门

本文介绍如何快速上手使用矩链。整个使用过程主要分为以下几步：

1. 部署/绑定节点
2. 创建联盟链
3. 合约开发
4. 合约调用

### 3.1 部署/绑定节点

准备好主机，主机是为区块链节点提供计算、存储、通信的服务资源实体，平台支持用户购买云服务器用于部署节点，在主机的性能允许范围内一台云服务器上可配置多个节点。

平台支持联盟链节点维度的生命周期管理，您可以对目标节点执行启用、停用、重启、更新配置文件、下载配置文件等操作。

**部署新的节点**

输入主机/云服务器的IP地址/端口，远程账号，密码，点击开始部署，则服务会自动部署节点。

![部署新的节点](img\node-add.png)

**绑定已有节点**

输入主机/云服务器的IP地址/端口，节点助记词，点击开始部署，则服务会自动部署节点。

![绑定已有节点](img\node-bind.png)

![部署节点](img\node-deploy.png)

### 3.2 创建联盟链

输入联盟链基础信息，链名、联盟链名称、管理员节点，选择共识机制、出块时间、区块大小、交易模式等，然后点击创建即可部署联盟链。

![部署联盟链](img\chain-deploy.png)

创建完成：

![联盟链创建完成](img\consortium-chain.png)

### 3.3 合约开发

超级共识矩链BaaS平台提供了丰富的合约开发设施，包括合约编辑器IDE、合约模板、合约管理等服务。您可以在合约仓库内创建合约模板，合约模板可以选择或者自主上传，创建后可在IDE中完成编写与模拟调试，随后部署到联盟链上。

下面将介绍创建合约模板、编写与调试合约代码、部署与管理合约实例（查看、升级、调用、下载编译结果、冻结、解冻、删除）。

在【智能合约】中【合约模板】有丰富的合约案例提供，可选择进行智能合约的创建，或者自己编写

**编辑合约**

![合约模板](img\contract-template.png)

然后可以在合约编辑器中编写、修改合约

![修改合约](img\contract-edit.png)

**部署合约**

1. 在上一步保存合约代码成功后，可进入“区块链”下的“联盟链管理”，点击准备部署该合约的联盟链卡片。
2. 在该联盟链的二级页面内，点击“合约实例”，在该页面内点击“部署合约实例”。
3. 选择刚刚创建的合约模板，点击“下一步：填写部署配置“。

![部署合约](img\contract-deploy.png)

**管理合约**

1. 进入联盟链管理二级页面。
2. 您可以进入“合约实例”管理页，点击目标合约实例的操作列，执行”查看、升级、调用、下载编译结果、冻结、解冻、删除“等操作。

![管理合约](img\contract-management.png)

### 3.4 合约调用

已经部署完成的合约，可以在【智能合约】二级页面可以直接发起请求，进行调用。

![合约调用](img\contract-call.png)

上链成功后可以通过区块浏览器，查询交易详情

![交易详情](img\blockchain-explore-tx.png)

## 4. 开发指南

### 4.1 整体介绍

**什么是区块链应用**

区块链应用DApp（Decentralized Application）就是去中心化应用。DAPP就是基于P2P对等网络而运行在智能合约之上的分布式应用程序，区块链则为其提供可信的数据记录。

**与传统应用的区别**

传统的 Web 应用开发通常由客户端和后端服务组成。而基于超级共识矩链的区块链应用开发除了客户端和服务端开发，还需要开发区块链上运行的智能合约。

简单来说，区块链应用是通过调用智能合约将数据存储在区块链的传统分布式应用，或通过直接调用的方式将数据存储在区块链的传统分布式应用（没有使用合约的场景）。所以DApp和传统APP的区别从技术的角度看，区别在于DApp的数据是存储在区块链上的，确保难以篡改；而传统APP的数据是存储在传统数据库上，可以直接修改。

**上链流程**

1. 用户使用 SDK 或者 API 把合约的执行参数包装到一个预执行请求，接着发送到一个矩链的全节点。
2. 全节点收到请求之后进行合约预执行，如果执行成功则返回执行后的读写集给客户端。
3. 客户端拿到读写集之后，在本地组装交易，同时用本地私钥进行交易签名，完成之后把完整的交易发送到区块链网络中。
4. 任意节点收到来自客户端的提交交易请求后通过p2p网络把交易广播给整个网络，从而让矿工能发现新的交易。
5. 矿工在收到来自p2p的交易后，通过打包区块把交易组装到一个新的区块里面，同时加上自己的签名。
6. 矿工打包区块完毕之后，把新的区块通过p2p网络广播给其他节点。
7. 其他节点在接收到矿工的新区块之后，进行区块的合法性验证，比如签名、共识、交易等验证，验证都通过后就计入到本地账本。
8. 客户端通过订阅的方式了解到自己的交易被打包到新的区块，这个时候即可认为交易已经上链。

### 4.2 智能合约与DApp开发

超级共识矩链是一个支持多语言合约的区块链框架，有多种语言来供大家选择使用开发智能合约。目前可以使用solidity、c++、go以及 java语言来编写，solidity为EVM合约，c++和go 支持 wasm合约，go和java支持native合约。solidity合约应用最为广泛，完美兼容以太坊开源社区以及相关开发工具，c++合约合约性能会更好些，go合约在易用性上更好，java合约的开发者会更多些。大家可以根据需要选择自己喜欢的语言来编写智能合约，下面会通过一步步的指引来帮助大家使用solidity、c++、go或者java来编写智能合约。

#### 4.2.1 Solidity合约

Solidity是一门面向合约的，为实现智能合约而创建的高级编程语言。这门语言受到了C++，Python和Javascript语言的影响，设计的目的是能在以太坊虚拟机（EVM）上运行。Solidity是静态类型语言，支持继承、库和复杂的用户定义类型等特性。借助Solidity，开发人员可以编写实现相应业务逻辑的应用程序，从而在区块链上留下不可篡改的交易记录。

**solidity合约相关文档**

- [https://github.com/ethereum/solidity](https://github.com/ethereum/solidity)
- [https://docs.soliditylang.org/en/v0.4.24/index.html](https://docs.soliditylang.org/en/v0.4.24/index.html)
- [https://github.com/OpenZeppelin/openzeppelin-contracts](https://github.com/OpenZeppelin/openzeppelin-contracts)

**示例**

```js
pragma solidity >=0.0.0;

contract Counter {
    address owner;
    mapping (string => uint256) values;

    constructor() public{
        owner = msg.sender;
    }

    function increase(string memory key) public payable{
        values[key] = values[key] + 1;
    }

    function get(string memory key) view public returns (uint) {
        return values[key];
    }

    function getOwner() view public returns (address) {
        return owner;
    }

}
```

#### 4.2.2 C++合约

超级共识矩链智能合约平台基于[WebAssembly](https://webassembly.org/)开发，提供一套基于 C99/C++14 标准的 C++ 语言子集作为合约语言。合约开发者将合约代码编译成 wasm 字节码，由合约平台区块链节点对 wasm 字节码进行解释执行。

以counter合约为例来看如何编写一个C++合约。

```c++
#include "xchain/xchain.h"
struct Counter : public xchain::Contract {};
DEFINE_METHOD(Counter, initialize) {
    xchain::Context* ctx = self.context();
    const std::string& creator = ctx->arg("creator");
    if (creator.empty()) {
        ctx->error("missing creator");
        return;
    }
    ctx->put_object("creator", creator);
    ctx->ok("initialize succeed");
}
DEFINE_METHOD(Counter, increase) {
    xchain::Context* ctx = self.context();
    const std::string& key = ctx->arg("key");
    std::string value;
    ctx->get_object(key, &value);
    int cnt = 0;
    cnt = atoi(value.c_str());
    char buf[32];
    snprintf(buf, 32, "%d", cnt + 1);
    ctx->put_object(key, buf);
    ctx->ok(buf);
}
DEFINE_METHOD(Counter, get) {
    xchain::Context* ctx = self.context();
    const std::string& key = ctx->arg("key");
    std::string value;
    if (ctx->get_object(key, &value)) {
        ctx->ok(value);
    } else {
        ctx->error("key not found");
    }
}
```

**代码解析**

下面我们逐行解析合约代码：

- **#include ** 为必须的，里面包含了编写合约所需要的库。
- **struct Counter : public xchain::Contract {}**: 声明了我们的合约类，所有的合约类都要继承自 **xchain::Contract** 。
- **DEFINE_METHOD(Counter, initialize)** 我们通过 **DEFINE_METHOD** 来为合约类定义合约方法，在这个例子里面我们为 **Counter** 类定义了一个叫 **initialize** 的合约方法。
- **xchain::Context\* ctx = self.context()** :用来获取合约的上下文，每个合约都有一个对应的合约执行上下文，通过上下文我们可以获取合约参数，写入合约数据，context对象是我们经常要操作的一个对象。
- **const std::string& creator = ctx->arg(“creator”);** ，用于从合约上下文里面获取合约方法的参数，这里我们获取了名字叫 **creator** 的合约参数，合约的参数列表是一个map结构, key为合约参数的名字，value为参数对应的用户传递的值。
- **ctx->put_object(“creator”, creator);** 通过合约上下文的 **put_object** 方法，我们可以向链上写入数据。
- **ctx->ok(“initialize succeed”);** 用于返回合约的执行结果，如果合约执行失败则调用 **ctx->error** 。

通过上面的代码分析我们得到了如下知识

- 一个合约有多个方法组成，如counter合约的 **initialize** ， **increase** , **get** 方法。
- **initialize** 是每个合约必须实现的方法，这个合约方法会在部署合约的时候自动执行。
- 每个合约方法有一个 **Context** 对象，通过这个对象我们能获取到很多有用的方法，如获取用户参数等。
- 通过 **Context** 对象的 **ok** 或者 **error** 方法我们能给调用方反馈合约的执行情况:成功或者失败。

#### 4.2.3 Go合约

同样以示例做说明

```go
package main
import (
    "strconv"
    "github.com/xuperchain/xuperchain/core/contractsdk/go/code"
    "github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)
type counter struct{}
func (c *counter) Initialize(ctx code.Context) code.Response {
    creator, ok := ctx.Args()["creator"]
    if !ok {
        return code.Errors("missing creator")
    }
    err := ctx.PutObject([]byte("creator"), creator)
    if err != nil {
        return code.Error(err)
    }
    return code.OK(nil)
}
func (c *counter) Increase(ctx code.Context) code.Response {
    key, ok := ctx.Args()["key"]
    if !ok {
        return code.Errors("missing key")
    }
    value, err := ctx.GetObject(key)
    cnt := 0
    if err == nil {
        cnt, _ = strconv.Atoi(string(value))
    }
    cntstr := strconv.Itoa(cnt + 1)
    err = ctx.PutObject(key, []byte(cntstr))
    if err != nil {
        return code.Error(err)
    }
    return code.OK([]byte(cntstr))
}
func (c *counter) Get(ctx code.Context) code.Response {
    key, ok := ctx.Args()["key"]
    if !ok {
        return code.Errors("missing key")
    }
    value, err := ctx.GetObject(key)
    if err != nil {
        return code.Error(err)
    }
    return code.OK(value)
}
func main() {
    driver.Serve(new(counter))
}
```

go合约的整体框架结构跟c++合约一样，在表现形式上稍微有点不一样：

- c++合约使用 **DEFINE_METHOD** 来定义合约方法，go通过结构体方法来定义合约方法
- c++通过 **ctx->ok** 来返回合约数据，go通过返回 **code.Response** 对象来返回合约数据
- go合约需要在main函数里面调用 **driver.Serve** 来启动合约

### 4.3 合约模板

超级共识矩链智能合约平台提供了常用的合约模板。你可以基于合约模板开发自己的合约，也可以直接使用这些模板。下面举例常用的C++智能合约模板：

#### 4.3.1 文件Hash存证

```c++
#include "xchain/xchain.h"
#include <string>

const std::string UserBucket = "USER";
const std::string HashBucket = "HASH";

// 文件Hash存证API规范
// 参数由Context提供
class HashDepositBasic {
public:
    // 初始化，基本不做任何工作
    virtual void initialize() = 0;
    // 将用户参数{user_id,file_name,hash_id}存储到磁盘
    virtual void storeFileInfo() = 0;
    // 查询当前合约下所有用户
    virtual void queryUserList() = 0;
    // 查询某个User下所有信息
    virtual void queryFileInfoByUser() = 0;
    // 按照Hash查询文件信息,需要指定用户
    virtual void queryFileInfoByHash() = 0;
};

struct HashDeposit : public HashDepositBasic, public xchain::Contract {
public:
    void initialize() {
        xchain::Context* ctx = this->context();
        ctx->ok("initialize success");
    }
    void storeFileInfo() {
        xchain::Context* ctx = this->context();    
        std::string user_id = ctx->arg("user_id");
        std::string hash_id = ctx->arg("hash_id");
        std::string file_name = ctx->arg("file_name");
        const std::string userKey = UserBucket + "/" + user_id + "/" + hash_id;
        const std::string hashKey = HashBucket + "/" + hash_id;
        std::string value = user_id + "\t" + hash_id + "\t" + file_name;
        std::string tempVal;
        if (ctx->get_object(hashKey, &tempVal)) {
            ctx->error("storeFileInfo failed, such hash has existed already");
            return;
        }
        if (ctx->put_object(userKey, value) && ctx->put_object(hashKey, value)) {
            ctx->ok("storeFileInfo success");
            return;
        }
        ctx->error("storeFileInfo failed");
    }
    
    void queryUserList() {
        xchain::Context* ctx = this->context();
        const std::string key = UserBucket + "/";
        std::unique_ptr<xchain::Iterator> iter = ctx->new_iterator(key, key + "～");
        std::string result;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);    
            if (res.first.length() > UserBucket.length() + 1) {
                result += res.first.substr(UserBucket.length() + 1) + "\n";
            }
        }
        ctx->ok(result);
    }
    void queryFileInfoByUser() {
        xchain::Context* ctx = this->context();
        const std::string key = UserBucket + "/" + ctx->arg("user_id");
        std::unique_ptr<xchain::Iterator> iter = ctx->new_iterator(key, key + "～");
        std::string result;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            result += res.second + "\n";
        }
        ctx->ok(result);
    }
    void queryFileInfoByHash() {
        xchain::Context* ctx = this->context();
        
        const std::string key = HashBucket + "/" + ctx->arg("hash_id");
        std::string value;
        bool ret = ctx->get_object(key, &value);
        if (ret) {
            ctx->ok(value);
            return;
        }
        ctx->error("queryFileInfoByHash error");
    }
};

DEFINE_METHOD(HashDeposit, initialize) {
    self.initialize();
}

DEFINE_METHOD(HashDeposit, storeFileInfo) {
    self.storeFileInfo();
}

DEFINE_METHOD(HashDeposit, queryUserList) {
    self.queryUserList();
}

DEFINE_METHOD(HashDeposit, queryFileInfoByUser) {
    self.queryFileInfoByUser();
}

DEFINE_METHOD(HashDeposit, queryFileInfoByHash) {
    self.queryFileInfoByHash();
}
```

#### 4.3.2 计数器合约

```c++
#include "xchain/xchain.h"

struct Counter : public xchain::Contract {};

DEFINE_METHOD(Counter, initialize) {
    xchain::Context* ctx = self.context();
    const std::string& creator = ctx->arg("creator");
    if (creator.empty()) {
        ctx->error("missing creator");
        return;
    }
    ctx->put_object("creator", creator);
    ctx->ok("initialize succeed");
}

DEFINE_METHOD(Counter, increase) {
    xchain::Context* ctx = self.context();
    const std::string& key = ctx->arg("key");
    std::string value;
    ctx->get_object(key, &value);
    int cnt = 0;
    cnt = atoi(value.c_str());
    char buf[32];
    snprintf(buf, 32, "%d", cnt + 1);
    ctx->put_object(key, buf);
    ctx->ok(buf);
}

DEFINE_METHOD(Counter, get) {
    xchain::Context* ctx = self.context();
    const std::string& key = ctx->arg("key");
    std::string value;
    if (ctx->get_object(key, &value)) {
        ctx->ok(value);
    } else {
        ctx->error("key not found");
    }
}
```

#### 4.3.3 学生证书上链存证

```c++
#include "xchain/xchain.h"

// 学生成绩上链存证API规范
// 参数由Context提供
class ScoreRecord {
public:
    // 初始化写入权限
    // 参数: owner - 具有写入权限的address
    virtual void initialize() = 0;

    // 写入课程成绩
    // 参数: userid - 学生的主键id
    //      data - 学生的成绩信息(json格式string)
    virtual void addScore() = 0;

    // 按照学生id查询成绩
    // 参数: userid - 学生的主键id
    // 返回值: data - 学生的成绩信息(json格式string)
    virtual void queryScore() = 0;

    // 查询具有写权限的账户
    // 返回值: 具有写权限的address
    virtual void queryOwner() = 0;
};

struct ScoreRecordDemo : public ScoreRecord, public xchain::Contract {
private:
    // define the key prefix of buckets
    const std::string OWNER_KEY = "Owner";
    const std::string RECORD_KEY = "R_";

    // check if caller is the owner of this contract
    bool isOwner(xchain::Context* ctx, const std::string& caller) {
        std::string owner;
        if (!ctx->get_object(OWNER_KEY, &owner)) {
            return false;
        }
        return (owner == caller);
    }

public:
    void initialize() {
        // 获取合约上下文对象
        xchain::Context* ctx = this->context();
        // 从合约上下文中获取合约参数, 由合约部署者指定具有写入权限的address
        std::string owner = ctx->arg("owner");
        if (owner.empty()) {
            ctx->error("missing owner address");
            return;
        }
        // 将具有写入权限的owner地址记录在区块链账本中
        ctx->put_object(OWNER_KEY, owner);
        ctx->ok("success");
    }

    void addScore() {
        // 获取合约上下文对象
        xchain::Context* ctx = this->context();
        // 获取发起者身份
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }
        // 如果写操作发起者不是具有写权限的用户，则无权写入
        if (!isOwner(ctx, caller)) {
            ctx->error(
                "permission check failed, only the owner can add score record");
            return;
        }

        // 从参数中获取用户主键id，必填参数，没有则返回错误
        const std::string& userid = ctx->arg("userid");
        if (userid.empty()) {
            ctx->error("missing 'userid'");
            return;
        }
        // 从参数中获取成绩数据，必填参数，没有则返回错误
        const std::string& data = ctx->arg("data");
        if (data.empty()) {
            ctx->error("missing 'data'");
            return;
        }

        // 将具有写入权限的owner地址记录在区块链账本中
        std::string score_key = RECORD_KEY + userid;
        if (!ctx->put_object(score_key, data)) {
            ctx->error("failed to save score record");
            return;
        }

        // 执行成功，返回status code 200
        ctx->ok(userid);
    }

    void queryScore() {
        // 获取合约上下文对象
        xchain::Context* ctx = this->context();

        // 从参数中获取用户主键id，必填参数，没有则返回错误
        const std::string& userid = ctx->arg("userid");
        if (userid.empty()) {
            ctx->error("missing 'userid'");
            return;
        }

        // 从账本中读取学生的成绩数据
        std::string score_key = RECORD_KEY + userid;
        std::string data;
        if (!ctx->get_object(score_key, &data)) {
            // 没查到，说明之前没上链过，返回错误
            ctx->error("no score record found of " + userid);
            return;
        }

        // 执行成功，返回status code 200
        ctx->ok(data);
    }

    void queryOwner() {
        // 获取合约上下文对象
        xchain::Context* ctx = this->context();
        std::string owner;
        if (!ctx->get_object(OWNER_KEY, &owner)) {
            // 没查到owner信息，可能
            ctx->error("get owner failed");
            return;
        }
        // 执行成功，返回owner address
        ctx->ok(owner);
    }
};

DEFINE_METHOD(ScoreRecordDemo, initialize) { self.initialize(); }

DEFINE_METHOD(ScoreRecordDemo, addScore) { self.addScore(); }

DEFINE_METHOD(ScoreRecordDemo, queryScore) { self.queryScore(); }

DEFINE_METHOD(ScoreRecordDemo, queryOwner) { self.queryOwner(); }
```

#### 4.3.4 数字积分管理合约

```c++
#include "xchain/xchain.h"

const std::string BALANCEPRE = "balanceOf_";
const std::string ALLOWANCEPRE = "allowanceOf_";
const std::string MASTERPRE = "owner";

// 积分管理合约的基类
// 积分管理合约需要实现基类中指定的方法
// 参数由xchain::Contract中的context提供
class AwardBasic {
public:
    /*
     * func: 初始化积分管理账户以及总发行量
     * @param: initiator:交易发起者,也是初始化积分的owner
     * @param: totalSupply:发行总量,初始化时,积分全部归initiator
     */
    virtual void initialize() = 0;
    /*
     * func: 增发积分
     * @param: initiator:交易发起者,只有交易发起者等于积分owner时，才能增发
     * @param: amount:增发容量
     */
    virtual void addAward() = 0;
    /*
     * func: 获取积分总供应量
     */
    virtual void totalSupply() = 0;
    /*
     * func: 获取caller的积分余额
     * @param: caller: 合约调用者
     */
    virtual void balance() = 0;
    /*
     * func: 查询to用户能消费from用户的积分数量
     * @param: from: 被消费积分的一方
     * @param: to: 消费积分的一方
     */
    virtual void allowance() = 0;
    /*
     * func: from账户给to账户转token数量的积分
     * @param: from:转移积分的一方
     * @param: to:收积分的一方
     * @param: token:转移积分数量
     */
    virtual void transfer() = 0;
    /*
     * func: 从授权账户from转移数量为token的积分给to账户
      * @param: from:被转积分账户
      * @param: caller:合约调用者
      * @param: to:收积分账户
      * @param: token:转移的积分数量
      */
    virtual void transferFrom() = 0;
    /*
      * func: 允许to账户从from账户转移token数量的积分
     * @param: from:
     * @param: to:
     * @param: token
     */
    virtual void approve() = 0;
};

struct Award : public AwardBasic, public xchain::Contract {
public:
    void initialize() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing caller");
            return;
        }
        const std::string& totalSupply = ctx->arg("totalSupply");
        if (totalSupply.empty()) {
            ctx->error("missing totalSupply");
            return;
        }
        if (atoi(totalSupply.c_str()) <= 0) {
            ctx->error("totalSupply is overflow");
            return;
        }

        std::string key = BALANCEPRE + caller;
        ctx->put_object("totalSupply", totalSupply);
        ctx->put_object(key, totalSupply);

        std::string master = MASTERPRE;
        ctx->put_object(master, caller);
        ctx->ok("initialize success");
    }
    void addAward() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing caller");
            return;
        }

        std::string master;
        if (!ctx->get_object(MASTERPRE, &master)) {
            ctx->error("missing master");
            return;
        }
        if (master != caller) {
            ctx->error("only the person who created the contract can addAward");
            return;
        }

        const std::string& increaseSupply = ctx->arg("amount");
        if (increaseSupply.empty()) {
            ctx->error("missing amount");
            return;
        }
        if (atoi(increaseSupply.c_str()) <= 0) {
            ctx->error("amount is overflow");
            return;
        }

        std::string value;
        if (!ctx->get_object("totalSupply", &value)) {
            ctx->error("get totalSupply error");
            return;
        }
        int increaseSupplyint = atoi(increaseSupply.c_str());
        int valueint = atoi(value.c_str());
        int totalSupplyint = increaseSupplyint + valueint;
        if (totalSupplyint <= 0) {
            ctx->error("amount+totalSupply is overflow");
            return;
        }
        char buf[32];
        snprintf(buf, 32, "%d", totalSupplyint);
        ctx->put_object("totalSupply", buf); 

        std::string key = BALANCEPRE + caller;
        if (!ctx->get_object(key, &value)) {
            ctx->error("get caller balance error");
            return;
        }
        valueint = atoi(value.c_str());
        int callerint = increaseSupplyint + valueint;
        snprintf(buf, 32, "%d", callerint);
        ctx->put_object(key, buf); 
    
        ctx->ok(buf);
    }
    void totalSupply() {
        xchain::Context* ctx = this->context();
        std::string value;
        if (ctx->get_object("totalSupply", &value)) {
            ctx->ok(value);
        } else {
            ctx->error("key not found");
        }
    }
    void balance() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->arg("caller");
        if (caller.empty()) {
            ctx->error("missing caller");
            return;
        }

        std::string key = BALANCEPRE + caller;
        std::string value;
        if (ctx->get_object(key, &value)) {
            ctx->ok(value);
        } else {
            ctx->error("key not found");
        }
    }
    void allowance() {
        xchain::Context* ctx = this->context();
        const std::string& from = ctx->arg("from");
        if (from.empty()) {
            ctx->error("missing from");
            return;
        }

        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing to");
            return;
        }

        std::string key = ALLOWANCEPRE + from + "_" + to;
        std::string value;
        if (ctx->get_object(key, &value)) {
            ctx->ok(value);
        } else {
            ctx->error("key not found");
        }
    }
    void transfer() {
        xchain::Context* ctx = this->context();
        const std::string& from = ctx->arg("from");
        if (from.empty()) {
            ctx->error("missing from");
            return;
        }
   
        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing to");
            return;
        }

        if (to == from) {
            ctx->error("can't transfer to yourself");
            return;
        }

        const std::string& token_str = ctx->arg("token");
        if (token_str.empty()) {
            ctx->error("missing token");
            return;
        }
        int token = atoi(token_str.c_str());
        if (token <= 0) {
            ctx->error("token is overflow");
            return;
        }

        std::string from_key = BALANCEPRE + from;
        std::string value;
        int from_balance = 0;
        if (ctx->get_object(from_key, &value)) {
            from_balance = atoi(value.c_str()); 
            if (from_balance < token) {
                ctx->error("The balance of from not enough");
                return;
            }  
        } else {
            ctx->error("key not found");
            return;
        }

        std::string to_key = BALANCEPRE + to;
        int to_balance = 0;
        if (ctx->get_object(to_key, &value)) {
            to_balance = atoi(value.c_str());
        }
   
        from_balance = from_balance - token;
        to_balance = to_balance + token;
   
        char buf[32]; 
        snprintf(buf, 32, "%d", from_balance);
        ctx->put_object(from_key, buf);
        snprintf(buf, 32, "%d", to_balance);
        ctx->put_object(to_key, buf);

        ctx->ok("transfer success");
    }
    void transferFrom() {
        xchain::Context* ctx = this->context();
        const std::string& from = ctx->arg("from");
        if (from.empty()) {
            ctx->error("missing from");
            return;
        }
  
        const std::string& caller = ctx->arg("caller");
        if (caller.empty()) {
            ctx->error("missing caller");
            return;
        }

        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing to");
            return;
        }

        if (to == from) {
            ctx->error("can't transfer to yourself");
            return;
        }

        const std::string& token_str = ctx->arg("token");
        if (token_str.empty()) {
            ctx->error("missing token");
            return;
        }
        int token = atoi(token_str.c_str());
        if (token <= 0) {
            ctx->error("token is overflow");
            return;
        }

        std::string allowance_key = ALLOWANCEPRE + from + "_" + caller;
        std::string value;
        int allowance_balance = 0;
        if (ctx->get_object(allowance_key, &value)) {
            allowance_balance = atoi(value.c_str()); 
            if (allowance_balance < token) {
                ctx->error("The allowance of from_to not enough");
                return;
            }  
        } else {
            ctx->error("You need to add allowance from_to");
            return;
        }

        std::string from_key = BALANCEPRE + from;
        int from_balance = 0;
        if (ctx->get_object(from_key, &value)) {
            from_balance = atoi(value.c_str()); 
            if (from_balance < token) {
                ctx->error("The balance of from not enough");
                return;
            }  
        } else {
            ctx->error("From no balance");
            return;
        }

        std::string to_key = BALANCEPRE + to;
        int to_balance = 0;
        if (ctx->get_object(to_key, &value)) {
            to_balance = atoi(value.c_str());
        }
   
        from_balance = from_balance - token;
        to_balance = to_balance + token;
        allowance_balance = allowance_balance - token;

        char buf[32]; 
        snprintf(buf, 32, "%d", from_balance);
        ctx->put_object(from_key, buf);
        snprintf(buf, 32, "%d", to_balance);
        ctx->put_object(to_key, buf);
        snprintf(buf, 32, "%d", allowance_balance);
        ctx->put_object(allowance_key, buf);

        ctx->ok("transferFrom success");
    }
    void approve() {
        xchain::Context* ctx = this->context();
        const std::string& from = ctx->arg("from");
        if (from.empty()) {
            ctx->error("missing from");
            return;
        }
   
        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing to");
            return;
        }

        if (to == from) {
            ctx->error("can't transfer to yourself");
            return;
        }

        const std::string& token_str = ctx->arg("token");
        if (token_str.empty()) {
            ctx->error("missing token");
            return;
        }
        int token = atoi(token_str.c_str());
        if (token <= 0) {
            ctx->error("token is overflow");
            return;
        }

        std::string from_key = BALANCEPRE + from;
        std::string value;
        if (ctx->get_object(from_key, &value)) {
            int from_balance = atoi(value.c_str()); 
            if (from_balance < token) {
                ctx->error("The balance of from not enough");
                return;
            }  
        } else {
            ctx->error("From no balance");
            return;
        }

        std::string allowance_key = ALLOWANCEPRE + from + "_" + to;
        int allowance_balance = 0;
        if (ctx->get_object(allowance_key, &value)) {
            allowance_balance = atoi(value.c_str());
        }

        allowance_balance = allowance_balance + token;
   
        char buf[32]; 
        snprintf(buf, 32, "%d", allowance_balance);
        ctx->put_object(allowance_key, buf);

        ctx->ok("approve success");
    }
};


DEFINE_METHOD(Award, initialize) {
    self.initialize();
}

DEFINE_METHOD(Award, addAward) {
    self.addAward();
}

DEFINE_METHOD(Award, totalSupply) {
    self.totalSupply();
}

DEFINE_METHOD(Award, balance) {
    self.balance();
}

DEFINE_METHOD(Award, allowance) {
    self.allowance();
}

DEFINE_METHOD(Award, transfer) {
    self.transfer();
}

DEFINE_METHOD(Award, transferFrom) {
    self.transferFrom();
}

DEFINE_METHOD(Award, approve) {
    self.approve();
}
```

#### 4.3.5 抽奖小游戏

```c++
#include "xchain/xchain.h"

const std::string TICKETID = "Luckid_";
const std::string USERID = "Userid_";
const std::string ADMIN = "admin";
const std::string RESULT = "result";
const std::string TICKETS = "tickets";

// 抽奖小游戏模板
// 参数由xchain::Contract中的context提供
class LuckDraw {
public:
    /*
     * func: 初始化游戏
     * @param: admin: 哪个address具有管理员权限
     */
    virtual void initialize() = 0;
    /*
     * func: 获得一个抽奖券
     * @param: initiator: 玩家的address，获得一个抽奖券
     */
    virtual void getLuckid() = 0;
    /*
     * func: 开始抽奖
     * @param: seed:
     * 传入一个随机数种子，可以是预言机生成的，也可以是游戏约定的，例如某天A股收盘价
     */
    virtual void startLuckDraw() = 0;
    /*
     * func: 查询抽奖结果
     */
    virtual void getResult() = 0;
};

struct LuckDrawDemo : public LuckDraw, public xchain::Contract {
public:
    void initialize() {
        xchain::Context* ctx = this->context();
        const std::string& admin = ctx->arg(ADMIN);
        if (admin.empty()) {
            ctx->error("missing admin address");
            return;
        }

        std::string key = ADMIN;
        ctx->put_object(key, admin);
        ctx->put_object(TICKETS, "0");
        ctx->ok("initialize success");
    }

    bool isAdmin(xchain::Context* ctx, const std::string& caller) {
        std::string admin;
        if (!ctx->get_object(ADMIN, &admin)) {
            return false;
        }
        return (admin == caller);
    }

    void getLuckid() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        // 检查是否存在抽奖结果，如果存在则不再继续发放奖券
        std::string result;
        if (ctx->get_object(RESULT, &result)) {
            ctx->error("this luck draw is finished");
            return;
        }

        // 检查用户是否已经抽过奖券, 如果抽过直接返回上次抽的奖券号
        std::string userval;
        if (ctx->get_object(USERID + caller, &userval)) {
            ctx->ok(userval);
            return;
        }

        std::string lastidStr;
        if (!ctx->get_object(TICKETS, &lastidStr)) {
            ctx->error("get tickets count failed");
            return;
        }

        // 确定当前抽奖券编号，全局自增
        int lastid = std::atoi(lastidStr.c_str());
        if (lastid < 0) {
            ctx->error("tickets count is wrong");
            return;
        }
        lastid++;
        lastidStr = std::to_string(lastid);
        if (!ctx->put_object(USERID + caller, lastidStr) ||
            !ctx->put_object(TICKETID + lastidStr, caller) ||
            !ctx->put_object(TICKETS, lastidStr)) {
            ctx->error("save ticket failed");
            return;
        }
        ctx->ok(lastidStr);
    }

    void startLuckDraw() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can add new asset type");
            return;
        }

        const std::string& seedStr = ctx->arg("seed");
        if (seedStr.empty()) {
            ctx->error("missing seed");
            return;
        }
        int seed = std::atoi(seedStr.c_str());

        // 获取总奖券数
        std::string lastidStr;
        if (!ctx->get_object(TICKETS, &lastidStr)) {
            ctx->error("get tickets count failed");
            return;
        }
        int lastid = std::atoi(lastidStr.c_str());
        if (lastid == 0) {
            ctx->error("no luck draw tickets");
            return;
        }

        // 抽奖
        srand(seed);
        int lucknum = (rand() % lastid) + 1;
        std::string luckid = std::to_string(lucknum);

        std::string luckuser;
        if (!ctx->get_object(TICKETID + luckid, &luckuser)) {
            ctx->error("get luck ticket failed");
            return;
        }

        // 记录抽奖结果
        if (!ctx->put_object(RESULT, luckuser)) {
            ctx->error("save luck draw result failed");
            return;
        }
        ctx->ok(luckuser);
    }

    void getResult() {
        xchain::Context* ctx = this->context();
        // 获取总奖券数
        std::string luckuser;
        if (!ctx->get_object(RESULT, &luckuser)) {
            ctx->error("get luck draw result failed");
            return;
        }

        ctx->ok(luckuser);
    };
};

DEFINE_METHOD(LuckDrawDemo, initialize) { self.initialize(); }

DEFINE_METHOD(LuckDrawDemo, getLuckid) { self.getLuckid(); }

DEFINE_METHOD(LuckDrawDemo, startLuckDraw) { self.startLuckDraw(); }

DEFINE_METHOD(LuckDrawDemo, getResult) { self.getResult(); }
```

#### 4.3.6 慈善捐款存证

```c++
#include <iomanip>
#include <sstream>
#include "xchain/xchain.h"

// 慈善捐款公示模板
// 参数由xchain::Contract中的context提供
class Charity {
public:
    /*
     * func: 初始化慈善基金管理账户
     * @param: admin: 哪个address具有管理员权限
     */
    virtual void initialize() = 0;
    /*
     * func: 新增捐款
     * @param: donor:捐款人id（注意不能包含%字符）
     * @param: amount: 捐款金额
     * @param: timestamp: 捐款时间
     * @param: comments: 备注
     * @return: donateid: 捐款编号
     */
    virtual void donate() = 0;
    /*
     * func: 新增慈善花费
     * @param: to:善款受益人
     * @param: amount: 善款金额
     * @param: timestamp: 拨款时间
     * @param: comments: 备注，例如受益人接收证明(可以是收据链接)
     * @return: costid: 拨款编号
     */
    virtual void cost() = 0;
    /*
     * func: 获取善款综述
     * @return: totalDonates(总捐款金额),
     * totalCosts(总拨付善款),fundBalance(基金会善款余额)
     */
    virtual void statistics() = 0;
    /*
     * func: 查询某个用户的捐款记录
     * @param: donor:捐款人id
     */
    virtual void queryDonor() = 0;
    /*
     * func: 查询捐款记录
     * @param: startid: 起始记录id
     * @param: limit: 查询多少条(每次查询不超过100条)
     */
    virtual void queryDonates() = 0;
    /*
     * func: 查询拨款记录
     * @param: startid: 起始记录id
     * @param: limit: 查询多少条(每次查询不超过100条)
     */
    virtual void queryCosts() = 0;
};

struct CharityDemo : public Charity, public xchain::Contract {
private:
    const std::string USERDONATE = "UserDonate_";
    const std::string ALLDONATE = "AllDonate_";
    const std::string ALLCOST = "AllCost_";
    const std::string TOTALRECEIVED = "TotalDonates";
    const std::string TOTALCOSTS = "TotalCosts";
    const std::string BALANCE = "Balance";
    const std::string DONATECOUNT = "DonateCount";
    const std::string COSTCOUNT = "CostCount";
    const std::string ADMIN = "admin";
    const uint64_t MAX_LIMIT = 100;

    std::string getIDFromNum(uint64_t num) {
        std::ostringstream ss;
        ss << std::setw(20) << std::setfill('0') << num;
        return ss.str();
    }

    bool safe_stoull(const std::string in, uint64_t* out) {
        if (in.empty()) {
            return false;
        }
        for (int i = 0; i < in.size(); i++) {
            if (in[i] < '0' || in[i] > '9') {
                return false;
            }
        }
        std::string::size_type sz = 0;
        *out = std::stoull(in, &sz);
        if (sz != in.size()) {
            return false;
        }
        return true;
    }

    bool isAdmin(xchain::Context* ctx, const std::string& caller) {
        std::string admin;
        if (!ctx->get_object(ADMIN, &admin)) {
            return false;
        }
        return (admin == caller);
    }

public:
    void initialize() {
        xchain::Context* ctx = this->context();
        const std::string& admin = ctx->arg(ADMIN);
        if (admin.empty()) {
            ctx->error("missing admin address");
            return;
        }
        ctx->put_object(ADMIN, admin);
        ctx->put_object(TOTALRECEIVED, "0");
        ctx->put_object(TOTALCOSTS, "0");
        ctx->put_object(BALANCE, "0");
        ctx->put_object(DONATECOUNT, "0");
        ctx->put_object(COSTCOUNT, "0");
        ctx->ok("initialize success");
    }

    void donate() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can add donate record");
            return;
        }

        const std::string& donor = ctx->arg("donor");
        if (donor.empty()) {
            ctx->error("missing 'donor'");
            return;
        }

        const std::string& amountStr = ctx->arg("amount");
        if (amountStr.empty()) {
            ctx->error("missing 'amount'");
            return;
        }

        uint64_t amount;
        if (!safe_stoull(amountStr, &amount)) {
            ctx->error(
                "illegel 'amount', should be string of a positive number");
            return;
        }

        const std::string& timestamp = ctx->arg("timestamp");
        if (timestamp.empty()) {
            ctx->error("missing 'timestamp'");
            return;
        }

        const std::string& comments = ctx->arg("comments");
        if (comments.empty()) {
            ctx->error("missing 'comments'");
            return;
        }

        uint64_t totalRec, balance, donateCnt;
        std::string totalRecStr, balanceStr, donateCntStr;
        if (!ctx->get_object(DONATECOUNT, &donateCntStr) ||
            !ctx->get_object(TOTALRECEIVED, &totalRecStr) ||
            !ctx->get_object(BALANCE, &balanceStr)) {
            ctx->error("read history failed");
            return;
        }
        safe_stoull(totalRecStr, &totalRec);
        safe_stoull(balanceStr, &balance);
        safe_stoull(donateCntStr, &donateCnt);
        totalRec += amount;
        balance += amount;
        donateCnt++;

        totalRecStr = std::to_string(totalRec);
        balanceStr = std::to_string(balance);
        donateCntStr = std::to_string(donateCnt);

        std::string donateID = getIDFromNum(donateCnt);

        std::string userDonateKey = USERDONATE + donor + "%" + donateID;
        std::string allDonateKey = ALLDONATE + donateID;
        std::string donateDetail =
            "donor=" + donor + "," + "amount=" + amountStr + ", " +
            "timestamp=" + timestamp + ", " + "comments=" + comments;
        if (!ctx->put_object(userDonateKey, donateDetail) ||
            !ctx->put_object(allDonateKey, donateDetail) ||
            !ctx->put_object(DONATECOUNT, donateCntStr) ||
            !ctx->put_object(TOTALRECEIVED, totalRecStr) ||
            !ctx->put_object(BALANCE, balanceStr)) {
            ctx->error("failed to save donate record");
            return;
        }
        ctx->ok(donateID);
    }

    void cost() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can add cost record");
            return;
        }

        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing 'to'");
            return;
        }

        const std::string& amountStr = ctx->arg("amount");
        if (amountStr.empty()) {
            ctx->error("missing 'amount'");
            return;
        }

        uint64_t amount;
        if (!safe_stoull(amountStr, &amount)) {
            ctx->error(
                "illegel 'amount', should be string of a positive number");
            return;
        }

        const std::string& timestamp = ctx->arg("timestamp");
        if (timestamp.empty()) {
            ctx->error("missing 'timestamp'");
            return;
        }

        const std::string& comments = ctx->arg("comments");
        if (comments.empty()) {
            ctx->error("missing 'comments'");
            return;
        }

        uint64_t totalCost, balance, costCnt;
        std::string totalCostStr, balanceStr, costCntStr;
        if (!ctx->get_object(COSTCOUNT, &costCntStr) ||
            !ctx->get_object(TOTALCOSTS, &totalCostStr) ||
            !ctx->get_object(BALANCE, &balanceStr)) {
            ctx->error("read history failed");
            return;
        }
        safe_stoull(totalCostStr, &totalCost);
        safe_stoull(balanceStr, &balance);
        safe_stoull(costCntStr, &costCnt);
        if (balance < amount) {
            ctx->error("fund balance is not enough");
            return;
        }

        totalCost += amount;
        balance -= amount;
        costCnt++;

        totalCostStr = std::to_string(totalCost);
        balanceStr = std::to_string(balance);
        costCntStr = std::to_string(costCnt);

        std::string costID = getIDFromNum(costCnt);

        std::string allCostKey = ALLCOST + costID;
        std::string costDetail = "to=" + to + "," + "amount=" + amountStr +
                                 ", " + "timestamp=" + timestamp + ", " +
                                 "comments=" + comments;
        if (!ctx->put_object(allCostKey, costDetail) ||
            !ctx->put_object(COSTCOUNT, costCntStr) ||
            !ctx->put_object(TOTALCOSTS, totalCostStr) ||
            !ctx->put_object(BALANCE, balanceStr)) {
            ctx->error("failed to save cost record");
            return;
        }
        ctx->ok(costID);
    }

    void statistics() {
        xchain::Context* ctx = this->context();
        uint64_t totalCost, balance, totalRec;
        std::string totalCostStr, balanceStr, totalRecStr;
        if (!ctx->get_object(TOTALRECEIVED, &totalRecStr) ||
            !ctx->get_object(TOTALCOSTS, &totalCostStr) ||
            !ctx->get_object(BALANCE, &balanceStr)) {
            ctx->error("read history failed");
            return;
        }

        std::string result = "totalDonates=" + totalRecStr + ", " +
                             "totalCosts=" + totalCostStr + ", " +
                             "fundBalance=" + balanceStr + "\n";
        ctx->ok(result);
    }

    void queryDonor() {
        xchain::Context* ctx = this->context();
        // admin can get the asset data of other users
        const std::string& donor = ctx->arg("donor");
        if (donor.empty()) {
            ctx->error("missing 'donor' in request");
            return;
        }

        std::string userDonateKey = USERDONATE + donor + "%";
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(userDonateKey, userDonateKey + "~");
        std::string result;
        int donateCnt = 0;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > userDonateKey.length()) {
                donateCnt++;
                std::string donateID = res.first.substr(userDonateKey.length());
                std::string content = res.second;
                result += "id=" + donateID + ", " + content + "\n";
            }
        }
        result =
            "total donate count:" + std::to_string(donateCnt) + "\n" + result;
        ctx->ok(result);
    }

    void queryDonates() {
        xchain::Context* ctx = this->context();
        const std::string& startID = ctx->arg("startid");
        if (startID.empty()) {
            ctx->error("missing 'startid' in request");
            return;
        }

        const std::string& limitStr = ctx->arg("limit");
        if (limitStr.empty()) {
            ctx->error("missing 'limit' in request");
            return;
        }
        uint64_t limit;
        safe_stoull(limitStr, &limit);
        if (limit > MAX_LIMIT) {
            ctx->error("'limit' is too large");
            return;
        }

        std::string donateKey = ALLDONATE + startID;
        std::string result;
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(donateKey, ALLDONATE + "~");
        int selected = 0;
        while (iter->next() && selected < limit) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > ALLDONATE.length()) {
                selected++;
                std::string donateID = res.first.substr(ALLDONATE.length());
                std::string content = res.second;
                result += "id=" + donateID + ", " + content + '\n';
            }
        }
        ctx->ok(result);
    }

    void queryCosts() {
        xchain::Context* ctx = this->context();
        const std::string& startID = ctx->arg("startid");
        if (startID.empty()) {
            ctx->error("missing 'startid' in request");
            return;
        }

        const std::string& limitStr = ctx->arg("limit");
        if (limitStr.empty()) {
            ctx->error("missing 'limit' in request");
            return;
        }
        uint64_t limit;
        safe_stoull(limitStr, &limit);
        if (limit > MAX_LIMIT) {
            ctx->error("'limit' is too large");
            return;
        }

        std::string costKey = ALLCOST + startID;
        std::string result;
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(costKey, ALLCOST + "~");
        int selected = 0;
        while (iter->next() && selected < limit) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > ALLCOST.length()) {
                selected++;
                std::string costID = res.first.substr(ALLCOST.length());
                std::string content = res.second;
                result += "id=" + costID + ", " + content + '\n';
            }
        }
        ctx->ok(result);
    };
};

DEFINE_METHOD(CharityDemo, initialize) { self.initialize(); }

DEFINE_METHOD(CharityDemo, donate) { self.donate(); }

DEFINE_METHOD(CharityDemo, cost) { self.cost(); }

DEFINE_METHOD(CharityDemo, statistics) { self.statistics(); }

DEFINE_METHOD(CharityDemo, queryDonor) { self.queryDonor(); }

DEFINE_METHOD(CharityDemo, queryDonates) { self.queryDonates(); }

DEFINE_METHOD(CharityDemo, queryCosts) { self.queryCosts(); }
```

#### 4.3.7 游戏装备管理

```c++
#include "xchain/xchain.h"

// 游戏装备资产模板
// 参数由xchain::Contract中的context提供
class GameAssets {
public:
    /*
     * func: 初始化装备发行账户
     * @param: admin: 哪个address具有管理员权限
     */
    virtual void initialize() = 0;
    /*
     * func: 新增装备类型
     * @param: initiator:交易发起者,只有交易发起者等于admin账户才能执行成功
     * @param: typeid: 游戏状态的参数和属性描述
     * @param: typedesc: 游戏状态的参数和属性描述
     */
    virtual void addAssetType() = 0;
    /*
     * func: 获取所有的装备类型和参数信息
     */
    virtual void listAssetType() = 0;
    /*
     * func:
     * 按照用户查询装备资产，管理员可以查询任意用户，其他用户只能查询自己的资产
     * @param: userid: 管理员可以指定user进行查询
     */
    virtual void getAssetsByUser() = 0;
    /*
     * func: 系统新生成的新装备，发放给特定用户，只能由管理员调用
     * @param: typeid: 游戏装备类型id
     * @param: assetid:
     * 游戏装备唯一id(先从外部获取装备id,也可以实现成一个自增计数器)
     * @param: userid: 获得游戏装备的用户
     */
    virtual void newAssetToUser() = 0;
    /*
     * func: 玩家将自己的装备交易给其他用户, 默认装备持有者是交易发起者
     * @param: to: 装备接收者
     * @param: assetid: 装备id
     */
    virtual void tradeAsset() = 0;
};

struct GameDemo : public GameAssets, public xchain::Contract {
public:
    const std::string ASSETTYPE = "AssetType_";
    const std::string USERASSET = "UserAsset_";
    const std::string ASSET2USER = "Asset2User_";

    void initialize() {
        xchain::Context* ctx = this->context();
        const std::string& admin = ctx->arg("admin");
        if (admin.empty()) {
            ctx->error("missing admin address");
            return;
        }

        ctx->put_object("admin", admin);
        ctx->ok("initialize success");
    }

    bool isAdmin(xchain::Context* ctx, const std::string& caller) {
        std::string admin;
        if (!ctx->get_object("admin", &admin)) {
            return false;
        }
        return (admin == caller);
    }

    void addAssetType() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can add new asset type");
            return;
        }

        const std::string& typeId = ctx->arg("typeid");
        if (typeId.empty()) {
            ctx->error("missing 'typeid' as asset type identity");
            return;
        }

        const std::string& typeDesc = ctx->arg("typedesc");
        if (typeDesc.empty()) {
            ctx->error("missing 'typedesc' as type description");
            return;
        }

        std::string assetTypeKey = ASSETTYPE + typeId;
        std::string value;
        if (ctx->get_object(assetTypeKey, &value)) {
            ctx->error("the typeid is already exist, please check again");
            return;
        }
        ctx->put_object(assetTypeKey, typeDesc);
        ctx->ok(typeId);
    }

    void listAssetType() {
        xchain::Context* ctx = this->context();
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(ASSETTYPE, ASSETTYPE + "~");
        std::string result;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > ASSETTYPE.length()) {
                result += res.first.substr(ASSETTYPE.length()) + ":" +
                          res.second + '\n';
            }
        }
        ctx->ok(result);
    }

    void getAssetsByUser() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }
        std::string userId = caller;
        if (isAdmin(ctx, caller)) {
            // admin can get the asset data of other users
            const std::string& userId2 = ctx->arg("userid");
            if (!userId2.empty()) {
                userId = userId2;
            }
        }

        std::string userAssetKey = USERASSET + userId + "_";
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(userAssetKey, userAssetKey + "~");
        std::string result;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > userAssetKey.length()) {
                std::string assetId = res.first.substr(userAssetKey.length());
                std::string typeId = res.second;
                std::string assetTypeKey = ASSETTYPE + typeId;
                std::string assetDesc;
                if (!ctx->get_object(assetTypeKey, &assetDesc)) {
                    // asset type id not found ,skip this asset
                    continue;
                }
                result += "assetid=" + assetId + ",typeid=" + typeId +
                          ",assetDesc=" + assetDesc + '\n';
            }
        }
        ctx->ok(result);
    }

    void newAssetToUser() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can add new asset type");
            return;
        }

        const std::string& userId = ctx->arg("userid");
        if (userId.empty()) {
            ctx->error("missing userid");
            return;
        }

        const std::string& typeId = ctx->arg("typeid");
        if (typeId.empty()) {
            ctx->error("missing typeid");
            return;
        }

        const std::string& assetId = ctx->arg("assetid");
        if (assetId.empty()) {
            ctx->error("missing assetid");
            return;
        }

        std::string assetKey = ASSET2USER + assetId;
        std::string value;
        if (ctx->get_object(assetKey, &value)) {
            ctx->error("the asset id is already exist, please check again");
            return;
        }

        std::string userAssetKey = USERASSET + userId + "_" + assetId;
        if (!ctx->put_object(userAssetKey, typeId) ||
            !ctx->put_object(assetKey, userId)) {
            ctx->error("failed to generate asset to user");
        }
        ctx->ok(assetId);
    }

    void tradeAsset() {
        xchain::Context* ctx = this->context();
        const std::string& from = ctx->initiator();
        if (from.empty()) {
            ctx->error("missing initiator");
            return;
        }

        const std::string& to = ctx->arg("to");
        if (to.empty()) {
            ctx->error("missing to");
            return;
        }

        const std::string& assetId = ctx->arg("assetid");
        if (assetId.empty()) {
            ctx->error("missing assetid");
            return;
        }
        std::string userAssetKey = USERASSET + from + "_" + assetId;
        std::string assetType;
        if (!ctx->get_object(userAssetKey, &assetType)) {
            ctx->error("you don't have assetid:" + assetId);
            return;
        }

        if (!ctx->delete_object(userAssetKey)) {
            ctx->error("failed to delete assetid:" + assetId);
            return;
        }

        std::string assetKey = ASSET2USER + assetId;
        std::string newUserAssetKey = USERASSET + to + "_" + assetId;
        if (!ctx->put_object(newUserAssetKey, assetType) ||
            !ctx->put_object(assetKey, to)) {
            ctx->error("failed to save assetid:" + assetId);
            return;
        }
        ctx->ok(assetId);
    };
};

DEFINE_METHOD(GameDemo, initialize) { self.initialize(); }

DEFINE_METHOD(GameDemo, addAssetType) { self.addAssetType(); }

DEFINE_METHOD(GameDemo, listAssetType) { self.listAssetType(); }

DEFINE_METHOD(GameDemo, getAssetsByUser) { self.getAssetsByUser(); }

DEFINE_METHOD(GameDemo, newAssetToUser) { self.newAssetToUser(); }

DEFINE_METHOD(GameDemo, tradeAsset) { self.tradeAsset(); }
```

#### 4.3.8 短内容存证合约

```c++
#include "xchain/xchain.h"

const std::string UserBucket = "USER";
const int TOPIC_LENGTH_LIMIT = 36;
const int TITLE_LENGTH_LIMIT = 100;
const int CONTENT_LENGTH_LIMIT = 3000;

// 短内容存证API规范
// 参数由Context提供
class ShortContentDepositBasic {
public:
    // 初始化，基本不做任何工作
    virtual void initialize() = 0;
    // 将用户参数{user_id,title,topic}存储到磁盘
    virtual void storeShortContent() = 0;
    // 按照用户粒度查询内容
    virtual void queryByUser() = 0;
    // 按照标题粒度查询内容，用户名是必须的
    virtual void queryByTitle() = 0;
    // 按照主题粒度查询内容，用户名是必须的
    virtual void queryByTopic() = 0;
};

struct ShortContentDeposit : public ShortContentDepositBasic, public xchain::Contract {
public:
    void initialize() {
        xchain::Context* ctx = this->context();
        ctx->ok("initialize success");
    }
    void storeShortContent() {
        xchain::Context* ctx = this->context();
        std::string user_id = ctx->arg("user_id");
        std::string title = ctx->arg("title");
        std::string topic = ctx->arg("topic");
        std::string content = ctx->arg("content");
        const std::string userKey = UserBucket + "/" + user_id + "/" + topic + "/" + title;
        if (topic.length() > TOPIC_LENGTH_LIMIT || title.length() > TITLE_LENGTH_LIMIT ||
            content.length() > CONTENT_LENGTH_LIMIT) {
            ctx->error("The length of topic or title or content is more than limitation");
            return;
        }
        if (ctx->put_object(userKey, content)) {
            ctx->ok("storeShortContent success");
            return;
        }
        ctx->error("storeShortContent failed");
    }
    void queryByUser() {
        xchain::Context* ctx = this->context();
        std::string key = UserBucket + "/" + ctx->arg("user_id") + "/";
        std::unique_ptr<xchain::Iterator> iter = ctx->new_iterator(key, key + "～");
        std::string result;
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            result += res.first + "\n" + res.second + "\n";
        }
        ctx->ok(result);
    }
    void queryByTitle() {
        xchain::Context* ctx = this->context();
        std::string user_id = ctx->arg("user_id");
        std::string topic = ctx->arg("topic");
        std::string title = ctx->arg("title");
        std::string key = UserBucket + "/" + user_id + "/" + topic + "/" + title;
        std::string value;
        bool ret = ctx->get_object(key, &value);
        if (ret) {
            ctx->ok(value);
            return;
        }
        ctx->error("queryByTitle failed");
    }
    void queryByTopic() {
        xchain::Context* ctx = this->context();
        std::string user_id = ctx->arg("user_id");
        std::string topic = ctx->arg("topic");
        std::string key = UserBucket + "/" + user_id + "/" + topic + "/";
        std::string result;
        std::unique_ptr<xchain::Iterator> iter = ctx->new_iterator(key, key + "～");
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            result += res.first + "\n" + res.second + "\n";
        }
        ctx->ok(result);
    }
};

DEFINE_METHOD(ShortContentDeposit, initialize) {
    self.initialize();
}

DEFINE_METHOD(ShortContentDeposit, storeShortContent) {
    self.storeShortContent();
}

DEFINE_METHOD(ShortContentDeposit, queryByUser) {
    self.queryByUser();
}

DEFINE_METHOD(ShortContentDeposit, queryByTitle) {
    self.queryByTitle();
}

DEFINE_METHOD(ShortContentDeposit, queryByTopic) {
    self.queryByTopic();
}
```

#### 4.3.9 商品溯源样例

```c++
#include "xchain/xchain.h"


// 商品溯源合约模板
// 参数由xchain::Contract中的context提供
class SourceTrace {
public:
    /*
     * func: 初始化商品溯源合约
     * @param: admin: 哪个address具有商品管理员权限
     */
    virtual void initialize() = 0;
    /*
     * func: 创建一个新的商品
     * 说明: 仅有合约发起者为admin时才允许创建商品
     * @param: id: 商品id
     * @param: desc: 商品描述
     */
    virtual void createGoods() = 0;
    /*
     * func: 变更商品信息
     * 说明: 仅有合约发起者为admin时才允许变更商品
     * @param: id: 商品id
     * @param: reason: 变更原因
     */
    virtual void updateGoods() = 0;
    /*
     * func: 查询商品变更记录
     * @param: id: 商品id
     */
    virtual void queryRecords() = 0;

};

struct SourceTraceDemo : public SourceTrace, public xchain::Contract {
public:
    const std::string GOODS = "GOODS_";
    const std::string GOODSRECORD = "GOODSSRECORD_";
    const std::string GOODSRECORDTOP = "GOODSSRECORDTOP_";
    const std::string CREATE = "CREATE";

    void initialize() {
        xchain::Context* ctx = this->context();
        const std::string& admin = ctx->arg("admin");
        if (admin.empty()) {
            ctx->error("missing admin address");
            return;
        }

        ctx->put_object("admin", admin);
        ctx->ok("initialize success");
    }

    bool isAdmin(xchain::Context* ctx, const std::string& caller) {
        std::string admin;
        if (!ctx->get_object("admin", &admin)) {
            return false;
        }
        return (admin == caller);
    }

    void createGoods() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can create new goods");
            return;
        }

        const std::string& id = ctx->arg("id");
        if (id.empty()) {
            ctx->error("missing 'id' as goods identity");
            return;
        }

        const std::string& desc = ctx->arg("desc");
        if (desc.empty()) {
            ctx->error("missing 'desc' as goods desc");
            return;
        }

        std::string goodsKey =  GOODS + id;
        std::string value;
        if (ctx->get_object(goodsKey, &value)) {
            ctx->error("the id is already exist, please check again");
            return;
        }
        ctx->put_object(goodsKey, desc);

        std::string goodsRecordsKey =  GOODSRECORD + id + "_0";
        std::string goodsRecordsTopKey =  GOODSRECORDTOP + id;
        ctx->put_object(goodsRecordsKey, CREATE);
        ctx->put_object(goodsRecordsTopKey, 0);
        ctx->ok(id);
    }

    void updateGoods() {
        xchain::Context* ctx = this->context();
        const std::string& caller = ctx->initiator();
        if (caller.empty()) {
            ctx->error("missing initiator");
            return;
        }

        if (!isAdmin(ctx, caller)) {
            ctx->error("only the admin can create new goods");
            return;
        }

        const std::string& id = ctx->arg("id");
        if (id.empty()) {
            ctx->error("missing 'id' as goods identity");
            return;
        }

        const std::string& reason = ctx->arg("reason");
        if (reason.empty()) {
            ctx->error("missing 'reason' as update reason");
            return;
        }

        std::string goodsRecordsTopKey = GOODSRECORDTOP + id;
        std::string value;
        ctx->get_object(goodsRecordsTopKey, &value);
        int topRecord = 0;
        topRecord = atoi(value.c_str()) + 1;

        char topRecordVal[32];
        snprintf(topRecordVal, 32, "%d", topRecord);
        std::string goodsRecordsKey =  GOODSRECORD + id + "_" + topRecordVal;

        ctx->put_object(goodsRecordsKey, reason);
        ctx->put_object(goodsRecordsTopKey, topRecordVal);
        ctx->ok(topRecordVal);
    }

    void queryRecords() {
        xchain::Context* ctx = this->context();
        const std::string& id = ctx->arg("id");
        if (id.empty()) {
            ctx->error("missing 'id' as goods identity");
            return;
        }

        std::string goodsKey =  GOODS + id;
        std::string value;
        if (!ctx->get_object(goodsKey, &value)) {
            ctx->error("the id not exist, please check again");
            return;
        }

        std::string goodsRecordsKey = GOODSRECORD + id;
        std::unique_ptr<xchain::Iterator> iter =
            ctx->new_iterator(goodsRecordsKey, goodsRecordsKey + "~");

        std::string result = "\n";
        while (iter->next()) {
            std::pair<std::string, std::string> res;
            iter->get(&res);
            if (res.first.length() > goodsRecordsKey.length()) {
                std::string goodsRecord = res.first.substr(GOODSRECORD.length());
                std::string::size_type pos = goodsRecord.find("_");
                std::string goodsId = goodsRecord.substr(0, pos);
                std::string updateRecord = goodsRecord.substr(pos+1, goodsRecord.length());
                std::string reason = res.second;

                result += "goodsId=" + goodsId + ",updateRecord=" + updateRecord +
                          ",reason=" + reason + '\n';
            }
        }
        ctx->ok(result);
    }  
};

DEFINE_METHOD(SourceTraceDemo, initialize) {
    self.initialize();
}

DEFINE_METHOD(SourceTraceDemo, createGoods) {
    self.createGoods();
}

DEFINE_METHOD(SourceTraceDemo, updateGoods) {
    self.updateGoods();
}

DEFINE_METHOD(SourceTraceDemo, queryRecords) {
    self.queryRecords();
}
```

## 5. 多语言SDK文档

### 5.1 GO SDK

**环境**

GO 1.13 及以上版本，在终端运行 `go -version` 查看当前 Go 版本

**下载**

Go SDK 代码可以在github上下载 [Go SDK](https://github.com/xuperchain/xuper-sdk-go)，查看详细的 [文档](https://github.com/xuperchain/xuper-sdk-go/blob/master/README.md)

**安装**

> go get github.com/xuperchain/xuper-sdk-go/v2

**使用 Go SDK**

**建立连接**

使用Go SDK和链上数据进行交互，首先需要使用SDK创建一个Client，与节点建立连接。

```go
// 创建客户端
xclient, err := xuper.New("127.0.0.1:37101")
```

**账户**

向链上发起交易前需要建立自己的账户，可以使用SDK创建账户。创建账户时注意保存好助记词或者私钥文件。XuperChain账户助记词中文助记词以及英文助记词

```go
// 创建账户 CreateAccount(strength uint8, language int)
//- `strength`：1弱（12个助记词），2中（18个助记词），3强（24个助记词）。
//- `language`：1中文，2英文。
acc, err := account.CreateAccount(2, 1)

// 创建账户并存储到文件中
acc, err = account.CreateAndSaveAccountToFile("./keys", "123", 1, 1)
```

如果已有账户，恢复账户即可。

```go
// 通过助记词恢复账户。xuperChain支持中文助记词
acc, err = account.RetrieveAccount("玉 脸 驱 协 介 跨 尔 籍 杆 伏 愈 即", 1)

// 通过私钥文件恢复账户
acc, err = account.GetAccountFromFile("keys/", "123")
```

新创建的账户余额为0，可以使用其他有余额的账户向该账户转账。对于有了余额的账户，就可以进行转账操作

```go
// 普通转账，acc为有余额的账户
tx, err := xclient.Transfer(acc, to.Address, "10")

// 查询普通账户余额
xclient.QueryBalance(to.Address)
```

**合约操作**

当账户有了余额后，就可以进行转账。如果要进行合约部署、调用等操作，还需要合约账户。合约账号是XuperChain中用于智能合约管理的单元，有普通账户发起交易，在链上生成的一串16位数字的账户，并且由XC开头，以@xuper结尾。执行合约相关操作时，需要用到合约账户

```go
//创建合约账户
contractAccount := "XC1234567890123456@xuper"
tx, err := xchainClient.CreateContractAccount(account, contractAccount)

// 转账给合约账户
tx, err := xclient.Transfer(acc, contractAccount, "10")

// 查询合约账户余额
fmt.Println(xclient.QueryBalance(contractAccount)
```

当合约账户有了余额后，就可以进行合约相关操作。XuperChain支持 Wasm 合约，EVM 合约，Native 合约.合约编写，编译相关内容这里不再赘述，这里我们使用Go SDK来部署一个Wasm合约

```go
// 设置合约账户
err = account.SetContractAccount(contractAccount)

// 读取Wasm 合约文件
code, err := ioutil.ReadFile(wasmCodePath)

// 构造合约初始化参数
args := map[string]string{
            "creator": "test",
            "key":     "test",
    }

//部署Wasm 合约,contractName为合约名。链上的合约名不能重复
tx, err := xuperClient.DeployWasmContract(account, contractName, code, args)

// 调用Wasm 合约，“increase"为调用合约中的某个具体方法
tx, err = xuperClient.InvokeWasmContract(account, contractName, "increase", args)

// 查询Wasm，需要在合约中有查询接口。该方法不需要消耗手续费
tx, err = xuperClient.QueryWasmContract(account, contractName, "get", args)
```

如此，合约部署相关的工作就已经完成了。如果需要部署其他合约，请参考 [Go SDK example](https://github.com/xuperchain/xuper-sdk-go/blob/2.0.0/example/contract/contract.go)

**其他链上查询**

除了合约相关操作外，Go SDK还支持链上信息查询，比如区块查询，交易查询，链上状态查询等。

```go
// 查询链上状态
bcStatus, err := client.QueryBlockChainStatus("xuper")

// 根据高度查询区块
blockResult, _ := xclient.QueryBlockByHeight(8)
// 根据区块ID查询区块
blockID := "8edfaefd04fa986bfede5a04160b5c200fe63726a4bfed45367da9bf701c70e8"
blockResult, _ := xclient.QueryBlockByID(blockID)

// 根据交易ID查询交易
txID := "c3af3abde7f800dd8782ce8a7559e5bdd7fe712c9efd56d9aeb7f9d2be253730"
tx, err := client.QueryTxByID(txID)
```

以上为常用接口使用方法，如果还需要进行其他接口相关查询，请参考 [Go SDK](https://github.com/xuperchain/xuper-sdk-go/blob/2.0.0/xuper/xuperclient.go)

### 5.2 Java SDK

**环境**

- JDK 8 及以上版本，在终端运行 `java -version` 查看当前 Java 版本
- Maven 3.5.4 及以上版本，在终端运行 `mvn -v` 查看当前 Maven 版本

**下载**

JS SDK 代码可在github上下载： [Java SDK](https://github.com/xuperchain/xuper-java-sdk)，可以查看详细的 [文档](https://github.com/xuperchain/xuper-java-sdk/blob/master/README.md)

同时可以使用 maven：

```xml
<dependency>
    <groupId>com.baidu.xuper</groupId>
    <artifactId>xuper-java-sdk</artifactId>
    <version>0.2.0</version>
</dependency>
```

**使用**

创建客户端，假设你的节点地址为 `127.0.0.1:37101`：

```java
XuperClient client = new XuperClient("127.0.0.1:37101");
```

向链上发交易前需要创建自己的账户，创建账户后余额为0，你可以使用 xchain-cli 程序向此地址转账：

```java
Account account = Account.create(1, 2);
System.out.println(account.getAddress());
System.out.println(account.getMnemonic());
```

当账户有余额后，你可以进行部署合约、调用合约，在这之前你需要先创建合约账户：

```java
// 创建合约账户
client.createContractAccount(account, "1111111111111111");

// 转账给合约账户
client.transfer(account, "XC1111111111111111@xuper", BigInteger.valueOf(1000000), "1");

// 查询余额
BigInteger result = client.getBalance("XC1111111111111111@xuper");
```

创建合约账户之后，可以部署合约，本次以部署 wasm 合约为例：

```java
// 设置合约账户
account.setContractAccount("XC1111111111111111@xuper");

// 构造合约初始化参数
Map<String, byte[]> args = new HashMap<>();
args.put("creator", "icexin".getBytes());

// wasm 合约编译的文件
String codePath = "./counter.wasm";
byte[] code = Files.readAllBytes(Paths.get(codePath));

// C++ 编写的合约，runtime 参数使用 "c"，合约名字为 counter
client.deployWasmContract(account, code, "counter", "c", args);
```

部署合约后可以调用合约方法：

```java
Map<String, byte[]> args = new HashMap<>();
args.put("key", "icexin".getBytes());
Transaction tx = client.invokeContract(account, "wasm", "counter", "increase", args);
System.out.println("txid: " + tx.getTxid());
System.out.println("response: " + tx.getContractResponse().getBodyStr());
System.out.println("gas: " + tx.getGasUsed());
```

Java 合约还支持 evm 合约以及其他查询接口请参考 [Java SDK 接口](https://github.com/xuperchain/xuper-java-sdk/blob/master/src/main/java/com/baidu/xuper/api/XuperClient.java)

### 5.3 Js SDK

**下载**

JS SDK 代码可在github上下载：[JS SDK](https://github.com/xuperchain/xuper-sdk-js)，可以查看详细的 [接口文档](https://xuperchain.github.io/xuper-sdk-js/classes/xupersdk.html)

**安装**

>  npm install –save @xuperchain/xuper-sdk

**使用 SDK**

接下来你可以使用 JS SDK 进行合约的部署以及合约的调用等操作。首先你需要使用 SDK 与节点创建一个 client。

```js
import XuperSDK from '@xuperchain/xuper-sdk';
  const node = '127.0.0.1:37101'; // node
  // const node = '39.156.69.83:37100' // 开放网络地址 grpc
  const chain = 'xuper'; // chain
  const xsdk = XuperSDK.getInstance({
    node,
    chain
});
```

默认 JS sdk 会与节点之间使用 gRPC，你可以选择使用 http 方式：

```js
const xsdk = XuperSDK.getInstance({
  const node = '127.0.0.1:37101'; // node
  const chain = 'xuper'; // chain
  env: {
    node: {
        disableGRPC: true // disable gRPC
    }
  }
});
```

**账户**

你可以使用 SDK 创建一个账户，同时记录下对应的助记词，或者保存好私钥文件：

```js
const acc = xsdk.create();
console.log(acc.mnemonic);
console.log(acc.address);
```

默认创建的助记词长度为12，并且为中文，你可以修改参数来指定其他长度或者英文：

```js
const acc = xsdk.create(Language.English, Strength.Middle);
console.log(acc.mnemonic);
console.log(acc.address);
```

创建账户之后你同样可以通过助记词来恢复账户，恢复账户时助记词难度级别、语言需要和创建时保持一直：

```js
const acc = xsdk.retrieve('fork remind carry tennis flavor draw island decrease salute hamster cool parrot circle twist width humor genre mammal', Language.English);
console.log(acc.mnemonic);
console.log(acc.address);
```

如果你的账户私钥是从开放网络下载的，那么会有对应的密码，你可以将私钥文件内容读取出来，然后用密码加载账户：

```js
// 其中最后一个参数 true 代表缓存起来，之后 sdk 发送交易默认使用本次 import 的账户。
const acc = xsdk.import("你的密码", "你的私钥文件内容", true);
```

除此之外，SDK 还支持导出账户、检查地址和助记词以等，更多功能可以参考 [接口文档](https://xuperchain.github.io/xuper-sdk-js/classes/xupersdk.html#create)

**合约**

有了账户之后，便可以向链上发送交易（前提是账户有足够的余额），接下来便可以进行部署、调用合约的完整流程。

**合约账户**

部署合约之前，首先需要创建一个合约账户（形如：[XC8888888888888888@xuper](mailto:XC8888888888888888%40xuper)），同时转账给合约账户：

```js
var num = new Number(8888888888888888);
const demo = await xsdk.createContractAccount(num);
await xsdk.postTransaction(demo.transaction);

// 转账给合约账户
const tx = await xsdk.transfer({
        to: 'XC8888888888888888@xuper',
        amount: '1000000000',
        fee: '1000'
    });
await xsdk.postTransaction(tx);
```

**部署合约**

有了合约账户后便可以部署合约，合约的编写、编译等这里不再赘述。你可以使用 SDK 来部署你的合约：

```js
// evm 合约的 abi 以及 bin。这里只是示例，你可以编写自己的合约，然后编译出 abi 和 bin。
const abi = "[{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"constant":true,"inputs":[{"internalType":"string","name":"key","type":"string"}],"name":"get","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"internalType":"string","name":"key","type":"string"}],"name":"increase","outputs":[],"payable":true,"stateMutability":"payable","type":"function"},{"constant":false,"inputs":[{"internalType":"string","name":"a","type":"string"},{"internalType":"string","name":"b","type":"string"}],"name":"join","outputs":[{"internalType":"string","name":"c","type":"string"},{"internalType":"string","name":"d","type":"string"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]";
const bin = "6080604052348***10032";

const demo = await xsdk.deploySolidityContract(
    'XC8888888888888888@xuper', // 合约账户
    'counter',                  // 合约名字
    bin,                        // evm 合约 bin
    abi, "evm"                 // evm 合约 abi
    //{
    //    "creator": "bob"      // 如果合约有初始化参数可以写在这里
    //}
);
await xsdk.postTransaction(demo.transaction);
```

**调用合约**

合约部署成功后，你可以调用这个合约，调用合约时需要指定合约名字、方法以及参数：

```js
// evm 合约的 abi 以及 bin。这里只是示例，你可以编写自己的合约，然后编译出 abi 和 bin。
const demo = await xsdk.invokeSolidityContarct(
        "counter",         // 合约名字
        "increase",        // 合约方法
        "evm",             // 合约模块，本合约为 evm 合约
        {
            "key": "hello" // 参数
        }
        //"100"            // 调用合约同时转账给合约的金额，方法具有 payable 关键字才可使用
    );
await xsdk.postTransaction(demo.transaction);
```

**查询合约**

合约中同样有查询接口，你可以调用这些接口查询数据，同时不消耗手续费，执行合约后，只要不将 transaction 再 post 到链上即可：

```js
// 执行合约即可。
const demo = await xsdk.invokeSolidityContarct(
    "counter",         // 合约名字
    "get",             // 合约方法
    "evm",             // 合约模块，本合约为 evm 合约
    {
        "key": "hello" // 参数
    }
);
```

**转账**

除了合约相关操作，你还可以进行转账：

```js
const tx = await xsdk.transfer({
        to: 'dpzuVdosQrF2kmzumhVeFQZa1aYcdgFpN',
        amount: '100',
        fee: '100'
    });
await xsdk.postTransaction(tx);
```

转账后还可以查询某个地址的余额：

```js
// 查询自己的余额
const result = await xsdk.getBalance();
console.log(result);

// 查询指定地址的余额
const result = await xsdk.getBalance('dpzuVdosQrF2kmzumhVeFQZa1aYcdgFpN');
console.log(result);
```

**查询链上信息**

SDK 还支持链上的查询接口，例如查询区块，查询交易，链上的状态等：

```js
// 查询链上状态
const status = await xsdk.checkStatus();

// 根据高度查询区块
const result = await xsdk.getBlockByHeight('8');

// 根据交易 ID 查询交易
const result = await xsdk.queryTransaction('242de4ae4b09d25e2103a29725fb2f865538669780e5759be61d17e2c2e4afec');
```

上面为部署 EVM 合约、转账以及查询接口示例，wasm 以及 native 合约部署、升级、调用等其他接口接口请参考 [接口文档](https://xuperchain.github.io/xuper-sdk-js/classes/xupersdk.html)

### 5.4 RPC接口说明



## 6. 运维指南

**监控中心**

平台提供区块节点网络监控、网络状态监控、节点列表监控大屏，帮助运维人员直观洞悉区块链业务全局

![监控中心](img\monitor-center.png)

**日志中心**

平台提供了日志管理功能，通过联盟链、操作人、操作IP和操作时间四个维度进行筛选，查看用户的操作日志

![日志中心](img\monitor-center-log.png)

## 7. 常见问题

**什么是燃料？**
答：在区块链上发起存证、合约等类型的交易时，需要消耗一定的计算和存储资源，由于这些链上资源是有限的，因此每笔交易需要消耗一定的Gas（燃料）作为限制，可防止DDoS等恶意攻击造成的资源恶意消耗。因此，燃料可以理解为开放联盟链生态内所有上链操作的计费单位，每次上链都会消耗一定数量的燃料。

**链上数据查询时，为什么有一定的延时？**
答：链上的交易需要节点达成共识后不可逆，因此记录到平台内存在一定的异步延时，与传统的事务性数据库不同。

**用户是否需要自己开发智能合约？**
答：需要。您可以自行开发符合业务场景的智能合约，并部署在矩链服务平台上，智能合约开发可参见 [教程](https://baas.hyperchain.cn/document/detail?type=1&alias=contractandapp)。矩链也提供丰富的智能合约模板，可参见合约模板。

**平台支持使用哪些语言开发智能合约？**
答：目前支持C++、Solidy、Go、Java语言开发的智能合约。

**交易的实时性**
答：交易是异步上链，与传统事务性数据库不同。

**与关系型数据库同步**
答：订阅出块通知，按需从区块链拉取通知