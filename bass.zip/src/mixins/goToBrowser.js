export const goToBrowser = {
    data() {
        return {
            keyArr: [],
            keyArrapi: [],
            selfKey: "NBGG0NtbzhSLZiLHWi79bNQbuTnbjtZ9",

        }
    },
    methods: {

        goback() {
            this.$router.go(-1);
        },
        goHelp() {
            this.$router.push({
                path: "/developerApi"

            });
        },
        async getaddrlau(addr) {
            // 根据地址转化经纬度
            let res = await this.$jsonp("http://api.map.baidu.com/geocoding/v3/", {
                address: addr,
                output: "json",
                ak: this.selfKey,
            });
            return res.result;
        },
    }
}