import FileSaver from 'file-saver';
import XLSX from 'xlsx';
// 导出表格
export const exportExcelForm = {
    methods: {
        //     // 导出表格执行的方法
        //     exportExcelData(name) {
        //         /* generate workbook object from table */
        //       var wb = XLSX.utils.table_to_book(this.exportDom)
        //       /* get binary string as output */
        //       var wbout = XLSX.write(wb, { bookType: 'xlsx', bookSST: true, type: 'array' })
        //       try {
        //           FileSaver.saveAs(new Blob([wbout], { type: 'application/octet-stream' }), name + '.xlsx')
        //       } catch (e) { 
        //           if (typeof console !== 'undefined') console.log(e, wbout) 
        //           }
        //       return wbout
        //   },
        downloadUrl(res, name) {
            const blob = new Blob([res], { type: "application/vnd.ms-excel" }); // 构造一个blob对象来处理数据
            const fileName = name + ".txt"; // 导出文件名
            const elink = document.createElement("a"); // 创建a标签
            elink.download = fileName; // a标签添加属性
            elink.style.display = "none";
            elink.href = URL.createObjectURL(blob);
            document.body.appendChild(elink);
            elink.click(); // 执行下载
            URL.revokeObjectURL(elink.href); // 释放URL 对象
            document.body.removeChild(elink); // 释放标签
        },
    }

}