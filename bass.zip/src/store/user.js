
import Vue from "vue";
import Vuex from "vuex";
if (!window.VueRouter) {
  Vue.use(Vuex);
}
export const user = {
  state: {
    mapState: Object,
    mapActions: Object
  },

  mutations: {},
  getters: {
    mapState: (state) => {
      return state.mapState
    }, mapActions: (state) => {
      return state.mapActions
    }
  },
  actions: {}
};
