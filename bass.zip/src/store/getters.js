const getters = {
  // name: state => state.user.name,
};
export default getters;
