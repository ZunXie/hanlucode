// 显示
export function display(status) {
  const text = status ==0 ? "隐藏" : status == 1 ? "显示" :''
  return text
}
//状态
export function state(status) {
  const text = status == 0 ? "关闭" : status == 1 ? "启动" : ''
  return text
}
//截取字符串中间用省略号显示
export function getSubStr(str) {
  
  if (!str) return ''; 
  if (str.length > 10) {
    var subStr1 = str.substr(0, 5);
    var subStr2 = str.substr(str.length - 5, 5);
    var subStr = subStr1 + "..." + subStr2;
  } else {
    var subStr = str
  }
  return subStr;
}
// 智能合约状态
export function ContractStatus(status) {
  const text = status == 'Y' ? "已发布" : status == ' N' ? "失败" : status == 'W' ? "处理" : status == 'C' ? "未发布" : ""
  return text
}
// 时间戳
export function format(date) {
  //shijianchuo是整数，否则要parseInt转换
  var time = new Date(parseInt(date / 1000000));
  var y = time.getFullYear();
  var m = time.getMonth() + 1;
  var d = time.getDate();
  var h = time.getHours();
  var mm = time.getMinutes();
  var s = time.getSeconds();
  return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
  function add0(m) { return m < 10 ? '0' + m : m }
}
// 节点类型
export function IsAdminStatus(status) {
  const text = status == true ? '管理员节点' : status == false ? "普通节点" : ''
  return text
}