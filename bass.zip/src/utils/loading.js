// import axios from 'axios'
// import store from "../store/index"
// axios.interceptors.request.use(function (config) {
//     store.state.loadding = true; //在请求发出之前进行一些操作
//     return config
// }, function (error) {
//     return Promise.reject(error)
// });
// axios.interceptors.response.use(function (response) {
//     store.state.loadding = true;//在这里对返回的数据进行处理
//     return response
// }, function (error) {
//     return Promise.reject(error)
// })
// export default axios