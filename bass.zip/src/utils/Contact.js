import { postAction, getAction, deleteAction, putAction } from './request';
//获取已保持合约主列表
export async function ct_mains(param) {
    return getAction('/ct/mains', param, false);
}
//获取主合约基本信息
export async function ct_get(param) {
    return getAction('/ct/get', param, false);
}
//获取合约最新版本
export async function ct_lastCt(param) {
    return getAction('/ct/lastCt', param, false);
}
//获取合约详情列表
export async function ct_details(param) {
    return getAction('/ct/details', param, false);
}
//获取合约内容
export async function ct_info(param) {
    return getAction('/ct/info', param, false);
}
//根据[合约ID]获取[模板示例]
export async function ctm_getByCtMainId(param) {
    return getAction('/ctm/getByCtMainId', param, false);
}
//查询合约函数
export async function contractFunc_listFunc(param) {
    return getAction('/contractFunc/listFunc', param, false);
}
//创建合约函数
export async function contractFunc_createContractFunc(param, header) {
    return postAction('/contractFunc/createContractFunc', param, header,undefined,false);
}
// /执行合约
export async function ct_invokeContract(param, header) {
    return postAction('/ct/invokeContract', param, header,false);
}
// /删除合约函数
export async function contractFunc_removeContractFunc(param, header) {
    return postAction('/contractFunc/removeContractFunc', param, header,undefined,false);
}
//获取模板合约列表
export async function ctm_list(param) {
    return getAction('/ctm/list', param,true);
}
//获取合约内容详情
export async function ctm_info(param) {
    return getAction('/ctm/info', param,true);
}
//根据[模板ID]获取[模板示例]
export async function ctm_getByCtTemplateId(param) {
    return getAction('/ctm/getByCtTemplateId', param,true
    );
}