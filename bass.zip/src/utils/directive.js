import Vue from 'vue';
import {  openAppFn,detectVersion} from "./util";
// 打开app指令
const openApp = Vue.directive('openApp', {
   bind: function (el, binding) {
      el.binding = binding
      el.addEventListener('click', function () {
         let binding = this.binding
         openAppFn(binding.value)
         // window.location.href = "http://www.baidu.com"
      })
   },
   update: function (el, binding) {
      el.binding = binding
   }
});
const downLink = Vue.directive('downLink', {
   bind: function (el, binding) {
      el.binding = binding
      el.addEventListener('click', function () {
         let sysInfo=detectVersion();
         if(sysInfo.isIOS){
            window.location.href="https://apps.apple.com/cn/app/id134199459"
          }else{
            window.location.href="https://www.pgyer.com/sfMI"
          }
      })
   },
   update: function (el, binding) {
      el.binding = binding
   }
});
// ?code=wPDL9rU20a7ku9X1GBLOUqdlBwf2DzbwgTXOX2gmang&state=wework#/QuestionDetails?id=333
export  {openApp,downLink}