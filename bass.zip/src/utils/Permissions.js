import { postAction, getAction, deleteAction, putAction } from './request';
//修改菜单权限
export async function system_AdminMenu_add(param) {
    return postAction('/system/AdminMenu/add', param);
}

// 菜单列表
export async function system_AdminMenu_getDataGridd(param) {
    return postAction('/system/AdminMenu/getDataGrid', param);
}
// 编辑菜单
export async function system_AdminMenu_edit(param) {
    return postAction('/system/AdminMenu/edit', param);
}

// 账号列表
export async function system_AdminUser_getDataGrid(param) {
    return postAction('/system/AdminUser/getDataGrid', param);
}
//新增账号
export async function system_AdminUser_add(param) {
    return postAction('/system/AdminUser/add', param);
}
//编辑账号
export async function system_AdminUser_editd(param) {
    return postAction('/system/AdminUser/edit', param);
}
//角色列表
export async function system_AdminRole_getDataGrid(param) {
    return postAction('/system/AdminRole/getDataGrid', param);
} 
//角色编辑
export async function system_AdminRole_edit(param) {
    return postAction('/system/AdminRole/edit', param);
}
//角色新增
export async function system_AdminRole_add(param) {
    return postAction('/system/AdminRole/add', param);
}