import { postAction, getAction, deleteAction, putAction } from './request';
// import { setSessionStorage } from "@/utils/util";
// import store from "@/store/index";

// 登录
export async function loginPassword(param) {
    return postAction('/Login/password', param, undefined, true);
}
// 获取运营城市
export async function CommonApiGetRegionCity(param) {
    return postAction('/CommonApi/getRegionCity', param, undefined, true)
}
// 商户开户
export async function operator_Operator_add(param) {
    return postAction('/operator/Operator/add', param, undefined, true)
}
// 运营商管理列表
export async function operator_Operator_getDataGrid(param) {
    return postAction('/operator/Operator/getDataGrid', param, undefined, true)
}
// 运营商获取详情
export async function operator_Operator_getDataById(param) {
    return postAction('/operator/Operator/getDataById', param, undefined, true)
}
 
export async function operator_Operator_edit(param) {
    return postAction('/operator/Operator/edit', param, undefined, true)
}