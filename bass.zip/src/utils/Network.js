
// 200 成功
// 500 报错
// 201 重新登录

// 登录接口
// Login / password
// userName
// password(两次md5)

// {
//     "code": 200,
//         "msg": "登录成功",
//             "data": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQ"
// }

// {
//     "code": 500,
//         "msg": "",
//             "data": ""
// }

// 运营商管理
// 'phone' 手机
// 'city' 城市
// 'name' 运营商名称
// 'rate' 占比
// 'settlement_interval' 计算周期 0月结 1季度结
// 'is_phone' 同步手机号 1勾选2不勾选
// 'wechat' 微信
// 'provinces' 省份
// 'district' 地区
// 'state' 状态 0 - 解约 1 - 正常'

// operator / Operator / add
// operator / Operator / edit
// operator / Operator / getDataGrid
// operator / Operator / getDataById

// 菜单权限
// 'mid' id
// 'menu_name' 菜单名称
// 'menu_url' 菜单url
// 'p_mid' 上级菜单id
// 'menu_icon' 菜单图标
// 'rank_order' 排序
// 'display' 是否显示 0 - 隐藏 1 - 显示
// 'state' 菜单状态 0 - 关闭 1 - 启用

// system / AdminMenu / getDataGrid
// ['pageNum', 'pageSize', 'menu_name']

// system / AdminMenu / add
// 必填['menu_name', 'menu_url']
// 选填['p_mid', 'menu_icon', 'rank_order', 'display', 'state']

// system / AdminMenu / edit
// 必填['mid', menu_name', 'menu_url']
// 选填['p_mid', 'menu_icon', 'rank_order', 'display', 'state']

// 角色
// id id
// name 角色名称
// state 状态0 - 禁用 1 - 可以

// system / AdminRole / getDataGrid
// ['pageNum', 'pageSize', 'name']

// system / AdminRole / add
// 必填['name']
// 选填['state']

// system / AdminRole / edit
// 必填['id', 'name']
// 选填['state']

// 账号
// account 账号
// password 密码
// rpassword 重复密码
// state 状态0 - 禁用 1 - 可以

// system / AdminUser / add //新增
// 必填['account', 'password', 'rpassword']
// 选填['state']
// system / AdminUser / edit  //修改
// 必填['id', 'account']
// 选填['password', 'rpassword', 'state']
// system / AdminUser / getDataGrid   //列表
// ['pageNum', 'pageSize', 'account']

