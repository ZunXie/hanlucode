import { postAction, getAction, deleteAction, putAction } from './request';
//商户管理列表
export async function shop_Shop_getDataGrid(param) {
    return postAction('/shop/Shop/getDataGrid', param);
}
// 商户开户
export async function shop_Shop_add(param) {
    return postAction('/shop/Shop/add', param);
}

//商户信息修改
export async function shop_Shop_edit(param) {
    return postAction('/shop/Shop/edit', param);
}
