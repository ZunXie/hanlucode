<template>
  <div class="Navigation">
    <div @click="getGoback" class="goback">
      <slot name="retlirn"></slot>
    </div>
    <div class="Nav-tit nav-value">
      <div>
        <span class="tit-vale">{{ title }}</span>
         <span  >
           <a-select
                       :dropdownMatchSelectWidth="false"

            v-if="ChainGroupAlllist[0]"
            :default-value="defaultValue"
            @change="handleChange"
          >
            <div slot="suffixIcon"><a-icon type="caret-down" /></div>
            <a-select-option
              v-for="(item, index) in ChainGroupAlllist"
              :key="index"
              :value="item.groupCode"
            >
              {{ item.groupName }}
            </a-select-option>
          </a-select>
        </span>
         
      </div>

      <div class="searchslot" slot="search">
        <a-input-search
          placeholder="请输入哈希值或区块高度"
          style="width: 424px; height: 28px"
          v-model="height"
          @search="onSearch"
        >
          <a-button slot="enterButton"> <a-icon type="search" /> </a-button>
        </a-input-search>
        <!-- <a-icon
          style="
            width: 28px;
            height: 28px;
            border: 1px solid #ebedf0;
            margin: 0 auto;
            margin-left: 16px;
            padding-top: 6px;
          "
          type="ie"
        /> -->
      </div>
    </div>
  </div>
</template>

<script>
import { setSessionStorage, getSessionStorage } from "@/utils/util";

export default {
    components: {},
    props: ["title","typeshow"],
    data() {
        return {
            ChainGroupAlllist: [],
            defaultValue: "",
            height: "",
        };
    },
    watch: {},
    computed: {},
    methods: {
        onSearch() {
            this.$emit("search", this.height);
        },
        handleChange(value) {
            setSessionStorage("groupCodeAll", value);

            this.resetSetItem("groupCode", JSON.stringify(value));
        },
        async getChainGroupAll() {
            let res = getSessionStorage("groupCodeList");
            setSessionStorage("groupCodeAll", res[0].groupCode);
            await this.$store.commit("GROUP_CODE", res[0].groupCode);
            this.ChainGroupAlllist = res;
            this.defaultValue = getSessionStorage("groupCode")
                ? getSessionStorage("groupCode")
                :  res[0].groupCode;
        },
        getGoback() {
            this.$router.go(-1);
        },
    },
    mounted() {
        this.getChainGroupAll();
    },
};
</script>
<style lang="scss" scoped>
.Navigation {
  background: $color-primary;
  padding: 16px;
  .tit-vale {
    font-size: $size-inSmall;
    font-weight: 500;
    color: $color-tit;
  }
  .goback:hover {
    cursor: pointer;
  }
}
.nav-value {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>