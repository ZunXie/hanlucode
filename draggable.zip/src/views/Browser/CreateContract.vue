<template>
  <!-- <a-spin :spinning="spinning"> -->
  <div class="CreateContract">
    <div class="formall" v-if="!$route.query.type">
      <a-form-model
        :rules="rules"
        ref="ruleForm"
        layout="vertical"
        :model="form"
      >
        <a-form-model-item label="合约工程名" prop="ctCode">
          <el-input v-model="form.ctCode" size="small" placeholder="请输入" />
        </a-form-model-item>
        <a-form-model-item label="版本号" prop="versionCode">
          <el-input
            v-model="form.versionCode"
            size="small"
            placeholder="请输入"
          />
        </a-form-model-item>

        <a-form-model-item label="编辑语言" prop="ctType">
          <a-select
            v-model="form.ctType"
            :notFoundContent="locale.ctType"
            placeholder="请选择"
            dropdownClassName="dropdown-style"
          >
            <a-select-option
              v-for="(item, index) in CtTypeSetList"
              :key="index"
              :value="item"
            >
              {{ item }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
        <a-form-model-item label="联盟链" prop="groupCode">
          <a-select
            v-model="form.groupCode"
            placeholder="请选择"
            :notFoundContent="locale.groupCode"
            @change="handleChange"
            dropdownClassName="dropdown-style"
          >
            <a-select-option
              v-for="(item, index) in LeagueChainList"
              :key="index"
              :value="item.groupCode"
            >
              {{ item.groupName }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
        <a-form-model-item label="初始化参数">
          <a-textarea
            style="overflow: hidden"
            v-model="form.ctArgs"
            placeholder="请输入"
            :rows="5"
          />
        </a-form-model-item>
        <a-form-model-item prop="ctIntro" label="合约简介">
          <a-textarea
            style="overflow: hidden"
            v-model="form.ctIntro"
            placeholder="请输入"
            :rows="5"
          />
        </a-form-model-item>
      </a-form-model>
      <div style="display: flex; margin-top: 48px">
        <a-button ghost block @click="getSave" style="margin-right: 8px"
          >保存</a-button
        >
        <a-button type="primary" @click="getct_creatAndSendCt" block
          >发布</a-button
        >
      </div>
    </div>
    <div class="formall" v-else-if="$route.query.type && isShow">
      <a-descriptions class="descri_ptions">
        <a-descriptions-item :span="3" label="工程名">
          <!-- {{ formdevelop.ctCode }} -->
        </a-descriptions-item>
        <a-descriptions-item :span="3" label="所属联盟链">
          {{ formdevelop.groupName }}
        </a-descriptions-item>
        <a-descriptions-item :span="3" label="合约简介">
          {{ formdevelop.ctIntro }}
        </a-descriptions-item>
      </a-descriptions>
      <a-form-model
        :rules="rules"
        ref="ruleForm"
        layout="vertical"
        :model="formdevelop"
      >
        <a-form-model-item label="版本号" prop="versionCode">
          <el-input
            size="small"
            v-model="formdevelop.versionCode"
            placeholder="请输入"
          />
        </a-form-model-item>
        <a-form-model-item prop="ctType" label="编辑语言">
          <a-select
            dropdownClassName="dropdown-style"
            v-model="formdevelop.ctType"
            placeholder="请选择"
          >
            <a-select-option
              v-for="(item, index) in CtTypeSetList"
              :key="index"
              :value="item"
              class="sele"
            >
              {{ item }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
      </a-form-model>
      <div style="position: absolute; bottom: 16px; width: 80%">
        <a-button type="primary" block @click="getct_creatCtVersions"
          >保存</a-button
        >
      </div>
    </div>
    <div class="mirror">
      <CodemirrorComp
        :ctInfo="formdevelop.ctInfo"
        @ctInfo="ctInfo"
        theme="dracula"
      ></CodemirrorComp>
    </div>
  </div>
  <!-- </a-spin> -->
</template>

<script>
import {
  ct_creatCt,
  ct_getCtTypeSet,
  ct_creatCtVersions,
  ct_creatAndSendCt,
} from '@/utils/Browser'

import { ctm_info, ct_lastCt } from '@/utils/Contact'
import { getSessionStorage, setSessionStorage } from '../../utils/util'
import CodemirrorComp from '@/components/CodemirrorComp'

export default {
  components: { CodemirrorComp },
  data() {
    const ctCode = (rule, value, callback) => {
      console.log(value)
      if (value && !/^(?=.*\d)[a-z\d]{5,20}$/i.test(value)) {
        callback(new Error('输入5-20位字母和数字，第一位为字母'))
      } else if (!value) {
        callback(new Error('请输入必填项'))
      }
      callback()
    }
    return {
      locale: {
        groupCode: () => <Empty text="暂无联盟链" />,
        ctType: () => <Empty text="暂无编辑语言" />,
      },
      form: {
        versionCode: '',
        ctInfo: '',
      },
      formdevelop: {},
      CtTypeSetList: [],
      rules: {
        ctCode: [{ validator: ctCode, tirgger: 'change', required: true }],
        versionCode: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        ctType: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        groupCode: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        ctIntro: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
      },
      spinning: false,
      LeagueChainList: [],
      // 不显示数据
      isShow: false,
      cmOption: {
        tabSize: 2, // tab
        styleActiveLine: true, // 高亮选中行
        lineNumbers: true, // 显示行号
        styleSelectedText: true,
        line: true,
        foldGutter: true, // 块槽
        scrollbarStyle: null,
        gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        highlightSelectionMatches: { showToken: /\w/, annotateScrollbar: true }, // 可以启用该选项来突出显示当前选中的内容的所有实例
        mode: {
          // 模式, 可查看 codemirror/mode 中的所有模式
          name: 'javascript',
          json: true,
        },
        // hint.js options
        hintOptions: {
          // 当匹配只有一项的时候是否自动补全
          completeSingle: false,
        },
        // 快捷键 可提供三种模式 sublime、emacs、vim
        keyMap: 'sublime',
        matchBrackets: true,
        showCursorWhenSelecting: true,
        theme: 'dracula', // 主题
        extraKeys: { Ctrl: 'autocomplete' }, // 可以用于为编辑器指定额外的键绑定，以及keyMap定义的键绑定
      },
    }
  },
  methods: {
    ctInfo(value) {
      this.form.ctInfo = value
    },
    handleChange(value) {
      setSessionStorage('groupCode', value)
      setSessionStorage('groupCodeAll', value)
    },
    //保存
    async getSave() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          this.form.ctTemplateId = this.$route.query.id
          let res = await ct_creatCt(this.form)
          if (res.data.code == 200) {
            this.$message.success('保存成功')
            this.$router.push('/igentContract')
          } else {
            this.$message.warning(res.data.msg)
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // 发布合约
    getct_creatAndSendCt() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          this.form.ctTemplateId = this.$route.query.id
          // let res1 = await ct_creatCt(this.form);
          // this.spinning = true;
          // let ctId = { ctId: res1.data.data };
          // if (res1.data.code == 200) {
          let res = await ct_creatAndSendCt(this.form)
          if (res.data.code == 200) {
            this.$message.success('发布成功')
            this.spinning = false
            this.$router.push('/igentContract')
          } else {
            this.spinning = false
            this.$message.warning(res.data.msg)
          }
          // }
          // else {
          //   this.spinning = false;
          //   this.$message.warning(res1.data.msg);
          // }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    //获取合约语言类型集合
    async getct_getCtTypeSet() {
      let res = await ct_getCtTypeSet()
      this.CtTypeSetList = res.data.data
    },
    //开发版本的提交
    async getct_creatCtVersions() {
      this.formdevelop.ctArgs = {}
      let res = await ct_creatCtVersions(this.formdevelop)
      if (res.data.code == 200) {
        this.$router.go(-1)
        this.$message.success('保存成功')
      } else {
        this.$message.warning(res.data.msg)
      }
    },
  },
  async mounted() {
    this.LeagueChainList = getSessionStorage('groupCodeList') || []
    this.getct_getCtTypeSet()
    if (this.$route.query.id) {
      if (this.$route.query.type) {
        let res = await ct_lastCt({ ctMainId: this.$route.query.id })
        this.isShow = true
        this.formdevelop = res.data.data
      } else {
        ctm_info({ ctId: this.$route.query.id }).then((res) => {
          this.form = res.data.data
          this.formdevelop = res.data.data
        })
      }
    } else {
      this.form = {}
      this.formdevelop = {}
    }
  },
}
</script>
<style lang="scss">
.spin-content {
  border: 1px solid #91d5ff;
  background-color: #e6f7ff;
}
.ant-spin-nested-loading > div > .ant-spin {
  max-height: 500px !important;
  min-height: 300px !important;
}
// .sele {
//   background: #202536 !important;
//   color: $Black-2 !important;
// }
// .ant-select-dropdown-menu::-webkit-scrollbar {
//   display: none;
// }
// .sele:hover {
//   background: #193956 !important;
//   color: $Black-2;
// }
// .ant-select-dropdown-menu {
//   padding: 0 !important;
// }
// 修改下拉框的样式
.dropdown-style {
  .ant-select-dropdown-menu {
    background: #202536 !important;
    border: solid 1px #32323a;
  }
  .ant-select-dropdown-menu-item {
    color: #fff !important;
  }
  .ant-select-dropdown-menu-item:hover {
    background: #193956 !important;
  }
  .ant-select-dropdown-menu-item-selected {
    background: #202536 !important;
  }
  .ant-select-dropdown-menu-item-active {
    background: #193956 !important;
  }
}

.CreateContract {
  display: flex;
  .mirror {
    width: 100%;
  }
  .formall {
    width: 240px;
    padding: 24px 16px 0 24px;
    position: relative;
    .ant-descriptions-item > span {
      color: $color-primary;
    }
  }
}
.formall .ant-mentions,
.formall textarea.ant-input ::-webkit-scrollbar {
  display: none;
}
.code-mirror {
  font-size: 13px;
  line-height: 150%;
  text-align: left;
}

.cm-s-dracula.CodeMirror,
.cm-s-dracula .CodeMirror-gutters {
  height: calc(93vh) !important;
}
</style>
