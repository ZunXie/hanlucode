<template>
  <div class="BlockDetails">
    <Navigation
      :typeshow="true"
      :title="type == 'block' ? '区块详情' : '交易详情'"
    >
      <div slot="retlirn"><a-icon type="left" /> 返回</div>
      <div slot="select"></div>
    </Navigation>
    <div v-if="!Emptyshow">
      <div>
        <div class="detailValue">
          <a-table
            bordered
            :columns="columns_list"
            :pagination="false"
            :data-source="data_list"
            :rowKey="(record) => record.timestamp"
            :locale="locale"
          >
            <!-- 标题 -->
            <span slot="blockHeight"
              >区块高度
              <a-tooltip>
                <template slot="title"> 区块链上的块数 </template>
                <a-icon type="exclamation-circle" />
              </a-tooltip>
            </span>
            <span slot="blockTxCount"
              >交易数
              <a-tooltip>
                <template slot="title"> 当前区块内的交易数量 </template>
                <a-icon type="exclamation-circle" />
              </a-tooltip>
            </span>

            <!-- 内容 -->
            <template slot="blockId" slot-scope="text, record">
              <span>
                {{ record.blockId }}
              </span>
            </template>
            <template slot="proposer" slot-scope="text, record">
              <span>
                {{ record.proposer }}
              </span>
            </template>
            <template slot="timestamp" slot-scope="text, record">
              <span>
                {{ record.timestamp | format }}
              </span>
            </template>
          </a-table>
        </div>
        <div class="content_table">
          <div v-if="type == 'block'">
            <!-- <div class="table-title">
              <span class="fontSize14">交易记录</span>
              <a-space
                ><a-icon type="reload" /><a-icon type="fullscreen"
              /></a-space>
            </div> -->
            <a-table
              bordered
              :columns="columns"
              :pagination="false"
              :data-source="data_details"
              :locale="localedetails"
              :rowKey="(record) => record.timestamp"
            >
              <!-- 内容 -->
              <template slot="txId" slot-scope="text, record">
                <span @click="getTradDetails(record)" class="formUnderline">
                  {{ record.txId }}
                </span>
              </template>
              <template slot="inputAddress" slot-scope="text, record">
                <span>
                  {{
                    record.inputAddress ? record.inputAddress : "-----"
                  }}</span
                >
              </template>
              <template slot="outputAddress" slot-scope="text, record">
                <span>
                  {{
                    record.outputAddress ? record.outputAddress : "-----"
                  }}</span
                >
              </template>
            </a-table>
          </div>

          <div v-else>
            <BlockDetails :detailvalue="data_details" />
          </div>
        </div>
      </div>
      <DrawerTrad
        :isTrawShow.sync="isTrawShow"
        :child_detailvalues="detailvalue_prop"
      />
    </div>
    <Empty v-else :height="emptyHeigth" text="暂无数据" />
  </div>
</template>

<script>
import DrawerTrad from "../../components/DrawerTrad";
import { chainGroup_browQuery } from "@/utils/Browser";
import { getSessionStorage } from "@/utils/util";
import BlockDetails from "../../components/BlockDetails";
export default {
  components: { DrawerTrad, BlockDetails },
  props: {},
  data() {
    return {
      locale: {
        emptyText: () => <Empty text="暂无数据" />,
      },
      localedetails: {
        emptyText: () => <Empty text="暂无交易" />,
      },
      // 详情抽屉
      isTrawShow: false,
      columns_list: [
        {
          dataIndex: "blockHeight",
          key: "blockHeight",
          slots: { title: "blockHeight" },
          width: "120px",
          className: "column-right",
        },
        {
          dataIndex: "blockTxCount",
          slots: { title: "blockTxCount" },
          className: "column-right",
          key: "blockTxCount",
          width: "100px",
        },
        {
          title: "区块哈希",
          dataIndex: "blockId",
          scopedSlots: { customRender: "blockId" },
          key: "blockId",
          width: "40%",
        },
        {
          title: "验证人",
          key: "proposer",
          scopedSlots: { customRender: "proposer" },
          width: "24%",
        },
        {
          title: "提交时间",
          key: "timestamp",
          scopedSlots: { customRender: "timestamp" },
        },
      ],
      data_list: [],
      // 表格数据
      columns: [
        {
          title: "转入方",
          dataIndex: "inputAddress",
          key: " inputAddress",
          scopedSlots: { customRender: "inputAddress" },
          width: "9%",
        },
        {
          title: "交易额",
          dataIndex: "transferAmount",
          key: "transferAmount",
          scopedSlots: { customRender: "transferAmount" },
          width: "9%",
        },
        {
          title: "交易哈希",
          dataIndex: "txId",
          scopedSlots: { customRender: "txId" },
          key: "txId",
          width: "40%",
        },
        {
          title: "转出方",
          key: "outputAddress",
          dataIndex: "outputAddress",
          scopedSlots: { customRender: "outputAddress" },
          width: "24%",
        },
      ],
      data_details: [],
      detailvalue_prop: "",
      Emptyshow: true,
      emptyHeigth: 0,
      type: "",
    };
  },

  methods: {
    getTradDetails(value) {
      this.detailvalue_prop = value;
      this.isTrawShow = true;
    },
    async getchainGroup_browQuery() {
      let groupCode = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : getSessionStorage("groupCodeAll");
      let res = await chainGroup_browQuery({
        chainCode: groupCode,
        str: this.$route.query.str,
      });
      this.type = res.data.data.type;
      if (res.data.code == 200 && res.data.data.type == "block") {
        this.Emptyshow = false;
        this.data_list = [res.data.data.data];
        res.data.data.data.txList.map((i, v) => {});
        this.data_details = res.data.data.data.txList;
      } else if (res.data.code == 200 && res.data.data.type == "tx") {
        this.Emptyshow = false;
        console.log(res.data.data.data);
        this.data_list = [res.data.data.data];
        this.data_details = [res.data.data.data];
      } else if (res.data.code !== 200) {
        this.$message.error(res.data.msg);
      }
    },
  },

  mounted() {
    this.emptyHeigth = document.body.clientHeight - 150;
    this.getchainGroup_browQuery();
  },
};
</script>
<style lang="scss" scoped>
.detailValue {
  margin: 16px 24px;
  background: $color-primary;
  padding: 16px;
}
.content_table {
  background: $color-primary;
  margin: 24px 24px 0 24px;
  padding: 16px;
  .table-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 11px;
  }
}
.formUnderline {
  border-bottom: 1px solid $Black-65;
  &:hover {
    color: $color-Blue-6;
    cursor: pointer;
    border-bottom: 1px solid $color-Blue-6;
  }
}
</style>