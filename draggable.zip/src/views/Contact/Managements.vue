<template>
  <!-- <a-spin :spinning="spinning"> -->
  <div class="Managements">
    <div class="managements-tit">
      <a @click="goback" style="color: #646566"><a-icon type="left" />返回</a>
      <p>
        {{ ct_get.ctCode
        }}<a-tag style="margin-left: 12px" color="blue">
          {{ ct_get.groupName }}
        </a-tag>
      </p>
      <span>合约简介：{{ ct_get.ctIntro }}</span>
    </div>
    <div class="mainBody">
      <div class="mainBody-top">
        <p>已发布版本</p>
        <a-table
          size="middle"
          :locale="localeNode"
          bordered
          :columns="columnsNode"
          :data-source="dataNode"
          :pagination="false"
          :rowKey="(record) => record.versionCode"
        >
          <template slot="operation" slot-scope="text, record">
            {{ record.operation
            }}<span> <a @click="getToView(true, record)">查看</a></span>
          </template>
          <template slot="type" slot-scope="type">
            {{ type }}
          </template>
        </a-table>
      </div>
      <div class="mainBody-top">
        <div class="node-tit">
          <p>开发版本</p>
          <a-button size="default" @click="getsubmitDevelopment">
            提交开发版本
          </a-button>
        </div>
        <a-table
          size="middle"
          bordered
          :pagination="false"
          :locale="localeVersionCode"
          :columns="columns"
          :data-source="data_list"
          :rowKey="(record) => record.versionCode"
        >
          <template slot="operator" slot-scope="operator">
            {{ operator }}
          </template>
          <template slot="operation" slot-scope="text, record">
            {{ record.operation }}
            <a-space :size="16">
              <a @click="getToView(false, record)">查看</a>
              <a-popconfirm
                :title="`确认发布` + record.versionCode + `版本吗？`"
                ok-text="确定"
                cancel-text="取消"
                @confirm="confirm(record, true)"
                @cancel="cancel"
              >
                <a>发布</a>
              </a-popconfirm>
              <a-popconfirm
                placement="topRight"
                :title="`确认删除` + record.versionCode + `版本吗？`"
                ok-text="确定"
                cancel-text="取消"
                okType="danger"
                @confirm="confirm(record, false)"
                @cancel="cancel"
              >
                <a>删除</a>
              </a-popconfirm>
            </a-space>
          </template>
          <template slot="type" slot-scope="type">
            {{ type }}
          </template>
        </a-table>
        <div style="display: inline-block">
          <PaginationcUser
            v-if="dataNode.length > 10"
            v-model="pagination.current"
            :total="pagination.totalCount"
            show-size-changer
            :page-size="pagination.pageSize"
            @onShowSizeChange="onShowSizeChange"
          />
        </div>
      </div>
    </div>
    <!-- 查看的抽屉 -->
    <DrawerToView
      v-if="isToView"
      :isToView.sync="isToView"
      :show="show"
      :itemValue="itemValue"
    />
  </div>
  <!-- </a-spin> -->
</template>

<script>
import DrawerToView from "../../components/DrawerToView";
import { ct_get, ct_details, ct_lastCt } from "@/utils/Contact";
import { ct_sendCt, ct_delect } from "@/utils/Browser";
import { setSessionStorage, getSessionStorage } from "@/utils/util";

export default {
  components: { DrawerToView },
  data() {
    return {
      spinning: false,
      localeNode: {
        emptyText: () => <Empty text="暂无已发布版本" />,
      },
      localeVersionCode: {
        emptyText: () => <Empty text="暂无开发版本" />,
      },
      columnsNode: [
        {
          title: "版本号",
          dataIndex: "versionCode",
          key: "versionCode",
          width: "18%",
        },
        {
          title: "版本标识",
          dataIndex: "versionTag",
          key: "versionTag",
          width: "18%",
        },
        {
          title: "编辑语言",
          dataIndex: "ctType",
          key: "ctType",
          width: "20%",
        },
        {
          title: "提交人",
          dataIndex: "userAddress",
          key: "userAddress",
          scopedSlots: { customRender: "userAddress" },
          ellipsis: true,
          width: "300px",
        },
        {
          title: "提交时间",
          dataIndex: "createTime",
          key: "createTime",
          ellipsis: true,
          width: "20%",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "50px",
        },
      ],
      dataNode: [],

      // 开发版本
      columns: [
        {
          title: "版本号",
          dataIndex: "versionCode",
          key: "versionCode",
          width: "18%",
        },
        {
          title: "版本标识",
          dataIndex: "versionTag",
          key: "versionTag",
          width: "18%",
        },
        {
          title: "编辑语言",
          dataIndex: "ctType",
          key: "ctType",
          width: "20%",
        },
        {
          title: "提交人",
          dataIndex: "userAddress",
          key: "userAddress",
          ellipsis: true,
          width: "300px",
        },
        {
          title: "提交时间",
          dataIndex: "modifyTime",
          key: "modifyTime",
          ellipsis: true,
          width: "20%",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "140px",
        },
      ],
      data_list: [],
      isToView: false,
      ctMainId: "",
      ct_get: {},
      show: "",
      itemValue: {},
      pagination: { pageSize: 50, pageNum: 1 },
    };
  },
  watch: {},
  computed: {},
  methods: {
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getct_lastCt();
      this.getct_details();
    },
    getToView(value, item) {
      this.itemValue = item;
      this.show = value;
      this.isToView = !this.isToView;
    },
    //提交开发版本
    async getsubmitDevelopment() {
      await setSessionStorage("dataNode", this.data_list);
      this.$router.push({
        path: "/createContract",
        query: { type: true, id: this.ctMainId },
      });
    },
    //发布版本的弹框
    async confirm(e, type) {
      if (type) {
        // 发布
        // this.spinning = true;
        let res = await ct_sendCt({ ctId: e.ctId });
        if (res.data.code == 200) {
          // this.spinning = false;
          this.$message.success("发布成功");
        } else {
          this.spinning = false;
          this.$message.warning(res.data.msg);
        }
      } else if (!type) {
        // 删除
        let res = await ct_delect({ ctId: e.ctId });
        if (res.data.code == 200) {
          this.$message.success("删除成功");
        } else {
          this.spinning = false;
          this.$message.warning(res.data.msg);
        }
      }

      this.getct_lastCt();
      this.getct_details();
    },
    cancel(e) {
      this.$message.error("取消成功");
    },
    // 获取头部主合约信息
    async getct_get() {
      let res = await ct_get({ ctMainId: this.ctMainId });
      this.ct_get = res.data.data;
    },
    //获取合约最新版本 已发布
    async getct_lastCt() {
      let res = await ct_lastCt({ ctMainId: this.ctMainId, status: "Y" });
      this.dataNode = res.data.data ? [res.data.data] : [];
    },
    //获取合约详情列表
    async getct_details() {
      let param = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        ctMainId: this.ctMainId,
      };
      let res = await ct_details(param);
      this.data_list = res.data.data.rows;
      this.pagination.totalCount = res.data.data.total;
    },
    //返回
    goback() {
      this.$router.go(-1);
    },
  },
  created() {},
  mounted() {
    this.ctMainId = this.$route.query.id;
    this.getct_get();
    this.getct_details();
    this.getct_lastCt();
  },
};
</script>
<style lang="scss" scoped>
p {
  font-size: $size-inSmall;
  font-weight: 400;
  color: $color-tit;
  margin: 10px 0;
}
.managements-tit {
  height: 110px;
  background: $color-primary;
  margin: 4px 0 0 4px;
  padding: 12px 0 0 20px;

  span {
    font-size: $size-bodyThe;
  }
}
.mainBody {
  margin: 24px;
  .mainBody-top {
    background: $color-primary;
    padding: 3px 11px 24px 11px;
    margin-bottom: 24px;
  }
}
</style>