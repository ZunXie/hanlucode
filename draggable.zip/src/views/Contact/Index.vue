<template>
    <div class="Index">
        <!-- <h1>Index</h1> -->
        <router-view />
    </div>
</template>
<script>

export default {
    name: "Index",
};
</script>