<template>
  <div class="ContractTemplate">
    <div class="Contrac-tit">
      <Navigation :typeshow="true" title="合约模板">
        <div v-if="$route.query.type" slot="retlirn">
          <a-icon type="left" />返回
        </div>
        <div slot="select"></div>
      </Navigation>
    </div>
    <div v-if="value" class="ContractTemplate">
      <a-tabs default-active-key="1" @change="handleCallback">
        <a-tab-pane key="1" tab="模版类型一">
          <TreatyWord />
        </a-tab-pane>
        <a-tab-pane key="2" tab="模版类型二" force-render>
          <TreatyWord />
        </a-tab-pane>
        <a-tab-pane key="3" tab="模版类型三">
          <TreatyWord />
        </a-tab-pane>
      </a-tabs>
    </div>
    <TreatyWord v-else />
  </div>
</template>

<script>
import TreatyWord from "../../components/TreatyWord";
export default {
  components: { TreatyWord },
  props: {},
  data() {
    return {
      value: false,
      intelligentContract: [],
    };
  },
  watch: {},
  computed: {},
  methods: {
    handleCallback(key) {
      console.log(key);
    },
    getback() {
      this.$router.go(-1);
    },
  },
  created() {},
};
</script>
<style lang="scss" scoped>
.treatyWord {
  margin: 24px;
}
.goback {
  cursor: pointer;
}
</style>