<template>
  <div class="wrapper">
    <Navigation :title="TitleCompoents" />
    <div class="IntelligentContract">
      <div class="Inte_tit">
        <a-button @click="getcontractTemplate" style="margin: 8px"
          >合约模板</a-button
        >
        <a-button type="primary" icon="plus" @click="getCreated">
          创建合约
        </a-button>
        <a-table
          :locale="locale"
          size="middle"
          bordered
          :columns="columnsNode"
          :data-source="dataNode"
          :pagination="false"
          :scroll="{ y: 600 }"
          :rowKey="(record) => record.modifyTime"
        >
          <template slot="status" slot-scope="text, record">
            <div>
              <StatusColor :typeColor="record.status" />{{
                record.status | ContractStatus
              }}
            </div>
          </template>

          <template slot="curVersionCode" slot-scope="text, record">
            {{ record.curVersionCode ? record.curVersionCode : "----" }}
          </template>
          <template slot="operation" slot-scope="text, record">
            {{ record.operation }}
            <a @click="getManagement(record)">管理</a>
          </template>
        </a-table>
        <div style="display: inline-block">
          <PaginationcUser
            v-if="pagination.totalCount > 100"
            v-model="pagination.current"
            :total="pagination.totalCount"
            show-size-changer
            :page-size="pagination.pageSize"
            @onShowSizeChange="onShowSizeChange"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Navigation from "../../components/Navigation";
import { ct_mains } from "@/utils/Contact";
import { getSessionStorage } from "@/utils/util";
export default {
  components: { Navigation },
  props: {},
  data() {
    return {
      TitleCompoents: "智能合约",
      pagination: { pageSize: 100, pageNum: 1 },
      columnsNode: [
        {
          title: "合约工程名",
          dataIndex: "ctCode",
          key: "ctCode",
          scopedSlots: { customRender: "ctCode" },
          width: "18%",
        },
        {
          title: "合约简介",
          dataIndex: "ctIntro",
          key: "ctIntro",
          scopedSlots: { customRender: "ctIntro" },
          width: "32%",
        },
        {
          title: "当前版本号",
          dataIndex: "curVersionCode",
          scopedSlots: { customRender: "curVersionCode" },
          key: "curVersionCode",
          width: "20%",
        },
        {
          title: "状态",
          dataIndex: "status",
          className: "column-flexl",
          key: "status",
          scopedSlots: { customRender: "status" },
          ellipsis: true,
          width: "20%",
        },
        {
          title: "最新修改时间",
          dataIndex: "modifyTime",
          key: "modifyTime",
          ellipsis: true,
          width: "20%",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "50px",
        },
      ],
      dataNode: [],
      groupCode: "",
      page_key: this.$route.name,
      locale: { emptyText: <Empty text="暂无合约" /> },
    };
  },

  methods: {
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getct_mains();
    },
    callback(e) {
      console.log(e);
    },
    getManagement(item) {
      this.$router.push({
        path: "/managements",
        query: { id: item.ctMainId },
      });
    },
    //合约模板
    getcontractTemplate() {
      this.$router.push({
        path: "/contractTemplate",
        query: { type: true },
      });
    },
    // 创建合约
    getCreated() {
      this.$router.push("/createContract");
    },

    //获取智能合约列表
    async getct_mains() {
      let groupCode = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : getSessionStorage("groupCodeAll");
      let param = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        groupCode: groupCode,
      };
      let res = await ct_mains(param);
      this.pagination.totalCount = res.data.data.total;
      this.dataNode = res.data.data.rows;
    },
  },
  created() {},
  mounted() {
    this.getct_mains();
    this.setitem_event.add({ key: this.page_key, func: this.getct_mains });
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key);
  },
};
</script>
<style lang="scss" scoped>
.nav_title {
  height: 84px;
  background: $color-primary;
  margin: 3px 0 0 3px;
  padding: 15px 0 0 16px;
  span {
    font-size: $size-bodyThe;
    color: $color-info;
  }
  .tit-vale {
    margin: 0px 0 5px 0;
    font-size: 16px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(0, 0, 0, 0.85);
  }
}
.IntelligentContract {
  background: $color-primary;
  margin: 24px;
  padding: 16px;
}
.Inte_tit {
  text-align: right;
  margin-bottom: 5px;
}
</style>