<template>
  <div class="privateKeyEscrow">
    <EasilyOnChainNav
      nav_title="私钥托管（托管钱包）"
      :nav_center="nav_center"
    />
    <div class="privateKeyEscrow__center">
      <div>
        <a-tabs v-model="privateKeyEscrowkey" @change="getcallback">
          <a-tab-pane :key="1" tab="接入指南"> 接入指南 </a-tab-pane>
          <a-tab-pane :key="2" tab=" 接口文档">
            <div class="wrapper__center__api">
              <a-tabs v-model="apikey" @change="getcallbackApi">
                <a-tab-pane :key="1" tab="创建私钥">
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="2" tab="导出私钥" force-render>
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="3" tab="转账">
                  <InterfaceDocument />
                </a-tab-pane>
              </a-tabs>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import { goToBrowser } from "@/mixins/goToBrowser";
export default {
  mixins: [goToBrowser],
  props: {},
  data() {
    return {
      nav_center:
        "在区块链中，私钥是用户的账户证明，是区块链中的数据或资产的唯一所有凭证，是发起交易时的“盖章确认”，只要拥有的账户的私钥，则意味着拥有了账户中的数据或资产的所有权；因此私钥在区块链中是非常重要的。但是为了确保安全性，私钥往往冗长而又难以记忆，因此私钥的使用极为不便。而且在一些应用场景中，往往需要平台方代为发起交易或签名，因此，需要一个私钥托管的服务来为用户保存私钥，以便给用户带来更好的用户体验，匹配更多应用场景。",
      privateKeyEscrowkey: 1,
      apikey: 1,
    };
  },
  methods: {
    getcallback(key) {
      this.callback(key);
    },
    getcallbackApi(key) {
      this.callbackApi(key);
    },
  },
  created() {
    this.getinit();
  },
  destroyed() {
    this.getremove();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-tabs-nav-wrap {
  font-size: 12px;
}
::v-deep .ant-tabs-nav .ant-tabs-tab {
  padding: 8px 0;
  margin: 0 0 0 24px;
}
::v-deep .ant-tabs .ant-tabs-top-content > .ant-tabs-tabpane,
.ant-tabs .ant-tabs-bottom-content > .ant-tabs-tabpane {
  padding: 0 24px;
}
::v-deep .ant-tabs-bar {
  margin: 0;
}
@include b(privateKeyEscrow) {
  @include e(center) {
    margin: 16px;
    background: #ffffff;
  }
}
</style>