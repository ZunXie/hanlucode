<template>
  <div class="DataOnChain">
    <EasilyOnChainNav nav_title="数据上链服务" :nav_center="nav_center" />
    <div class="DataOnChain__center">
      <div>
        <a-tabs v-model="privateKeyEscrowkey" @change="getcallback">
          <a-tab-pane :key="1" tab="智能合约和场景">
            <IntelligentContract/>
          </a-tab-pane>
          <a-tab-pane :key="2" tab="接入指南"> 接入指南 </a-tab-pane>
          <a-tab-pane :key="3" tab=" 接口文档">
            <div class="wrapper__center__api">
              <a-tabs
                 v-model="apikey"
                @change="getcallbackApi"
              >
                <a-tab-pane :key="1" tab="数据上链">
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="2" tab="数据对比" force-render>
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="3" tab="数据查询">
                  <InterfaceDocument />
                </a-tab-pane>
              </a-tabs>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import { goToBrowser } from "@/mixins/goToBrowser";
export default {
  mixins: [goToBrowser],
  props: {},
  data() {
    return {
      nav_center:
        "基于区块链去中心化、不可篡改和公开透明的特性，将业务中的取信数据保存在区块链中，以保证数据真实可信。我们集成了现成的数据上链合约，并通过中间服务对接好对应和合约，开发者只需要通过调用API即可在指定的区块链完成数据上链",
      privateKeyEscrowkey: 1,
      apikey: 1,
    };
  },
  methods: {
    getcallback(key) {
      this.callback(key);
    },
    getcallbackApi(key) {
      this.callbackApi(key);
    },
  },
  created() {
    this.getinit();
  },
  destroyed() {
    this.getremove();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-tabs-nav-wrap {
  font-size: 12px;
}
::v-deep .ant-tabs-nav .ant-tabs-tab {
  padding: 8px 0;
  margin: 0 0 0 24px;
}
::v-deep .ant-tabs .ant-tabs-top-content > .ant-tabs-tabpane,
.ant-tabs .ant-tabs-bottom-content > .ant-tabs-tabpane {
  padding: 0 24px;
}
::v-deep .ant-tabs-bar {
  margin: 0 
}
@include b(DataOnChain) {
  @include e(center) {
    margin: 16px;
    background: #ffffff;
  }
}
</style>