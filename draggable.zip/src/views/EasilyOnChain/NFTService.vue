<template>
  <div class="NFTService">
    <EasilyOnChainNav nav_title="NFT铸币服务" :nav_center="nav_center" />
    <div class="NFTService__center">
      <div>
        <a-tabs v-model="privateKeyEscrowkey" @change="getcallback">
          <a-tab-pane :key="1" tab="智能合约和场景">
            <IntelligentContract />
          </a-tab-pane>
          <a-tab-pane :key="2" tab="接入指南"> 接入指南 </a-tab-pane>
          <a-tab-pane :key="3" tab=" 接口文档">
            <div class="wrapper__center__api">
              <a-tabs
               v-model="apikey"  @change="getcallbackApi"
              >
                <a-tab-pane :key="1" tab="NFT铸造(1155)">
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="2" tab="NFT转移(1155)" force-render>
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="3" tab="NFT铸造(721)">
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="4" tab="NFT转移(721)">
                  <InterfaceDocument />
                </a-tab-pane>
                <a-tab-pane :key="5" tab="NFT查询">
                  <InterfaceDocument />
                </a-tab-pane>
              </a-tabs>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import { goToBrowser } from "@/mixins/goToBrowser";
export default {
  mixins: [goToBrowser],
  props: {},
  data() {
    return {
      nav_center:
        "NFT（Non-Fungible Tokens）即非同质化代币，在区块链中代表现实世界的每一个商品（有形或无形），因区块链的技术特点，而具有唯一性、加密性，且NFT的所有权无法被篡改，也无法强制转移。<br/> 我们集成了721和1155两种NFT协议的智能合约，开发者可以直接创建对应的合约场景，中间服务会自动部署合约到指定的链上，只需要通过API对接中间服务即可实现NFT发行、转移、查询等业务功能。无需额外开发NFT合约，无需对接智能合约。",
      privateKeyEscrowkey: 1,
      apikey: 1,
    };
  },
  methods: {
    getcallback(key) {
      this.callback(key);
    },
    getcallbackApi(key) {
      this.callbackApi(key);
    },
  },
  created() {
    this.getinit();
  },
  destroyed() {
    this.getremove();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-tabs-nav-wrap {
  font-size: 12px;
}
::v-deep .ant-tabs-nav .ant-tabs-tab {
  padding: 8px 0;
  margin: 0 0 0 24px;
}
::v-deep .ant-tabs .ant-tabs-top-content > .ant-tabs-tabpane,
.ant-tabs .ant-tabs-bottom-content > .ant-tabs-tabpane {
  padding: 0 24px;
}
::v-deep .ant-tabs-bar {
  margin: 0;
}
@include b(NFTService) {
  @include e(center) {
    margin: 16px;
    background: #ffffff;
  }
}
</style>