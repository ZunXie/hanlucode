<template>
  <div class="Basis">
    <EasilyOnChainNav nav_title="基础接口服务" :nav_center="nav_center" />
    <div class="Basis__center">
      <div>
        <a-tabs :default-active-key="privateKeyEscrowkey" @change="getcallback">
          <a-tab-pane :key="1" tab="接入指南"> <BasicServices /> </a-tab-pane>
          <a-tab-pane :key="2" tab=" 接口文档">
            <InterfaceDocument :data_parameter='data_parameter' />
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
  </div>
</template>

<script>
import BasicServices from "@/components/EasilyOnChain/BasicServices.vue";
import { goToBrowser } from "@/mixins/goToBrowser";
import {
  open_base_getTxStatus,
  open_base_getAPiDocs,
} from "@/utils/EasilyOnChain";
export default {
  components: { BasicServices },
  mixins: [goToBrowser],
  props: {},
  data() {
    return {
      nav_center: "中间服务集成部分通用的基础接口服务，以支撑业务的需求",
      privateKeyEscrowkey: 1,
      data_parameter:[]
    };
  },
  methods: {
    getcallback(key) {
      this.callback(key);
    },
      //上链信息
    async getopen_base_getTxStatus() {
      let res = await open_base_getTxStatus();
    },
    //获取服务的api文档信息
    async getopen_base_getAPiDocs() {
      let res = await open_base_getAPiDocs();
      this.data_parameter=res.data.data[0].requestParams
    },
    getinit() {
      this.getopen_base_getTxStatus();
      this.getopen_base_getAPiDocs();
    },
  },
  created() {
    this.getinit();
  },
  destroyed() {
    this.getremove();
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-tabs-nav-wrap {
  font-size: 12px;
}
::v-deep .ant-tabs-nav .ant-tabs-tab {
  padding: 8px 0;
  margin: 0 0 0 24px;
}
::v-deep .ant-tabs .ant-tabs-top-content > .ant-tabs-tabpane,
.ant-tabs .ant-tabs-bottom-content > .ant-tabs-tabpane {
  padding: 0 24px;
}
::v-deep .ant-tabs-bar {
  margin: 0;
}
@include b(Basis) {
  @include e(center) {
    margin: 16px;
    background: #ffffff;
  }
}
</style>