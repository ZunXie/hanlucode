<template>
  <div class="DeveloperApi">
    <iframe
      src="http://192.168.3.101:9025/index.html"
      style="width: 100%; height: 800px"
      id="tempHtml"
      ref="tempHtml"
      frameborder="0"
    ></iframe>
    <!-- <div>${{require('../../assets/about/超级共识-矩链开放平台-BaaS系统-开发者文档.html')}}</div> -->

    <!-- <div class="markdown-body">
      <about />
    </div> -->
    <!-- <div class="dev-lef">
    <p class="fontSize14">工具介绍</p>
    <iframe  src="http://192.168.3.101:9025/index.html" style="width: 100%; height: 800px;" id="tempHtml" ref="tempHtml" frameborder="0"></iframe> -->

    <!-- 工具介绍 -->
    <!-- <div
        v-for="(item, index) in introduceList"
        :key="index"
        class="introduce"
      >
        <div class="fontSize16">{{ item.title }}</div>
        <span class="fontSize12">{{ item.value }}</span>
        <div class="fontSize12" style="text-align: end">
          <a-space size="middle"> <a>下载</a><a>查看详情</a></a-space>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
        </div>
      </div> -->

    <!-- 详情列表 -->
    <!-- <div v-for="(item, index) in contentList" :key="index" class="content">
        <span @click="getDocumentDetails">{{ item.title }}</span>
        <div>
          {{ item.value }}
        </div>
      </div> -->
    <!-- </div> -->

    <!-- <div class="dev-rig">
      <p class="fontSize12">索引指南</p>
      <a-divider />
      <div>一、BaaS平台简介</div>
      <div>二、区块链在产业的应用场景</div>
      <div>三、如何应用智能合约</div>
      <div>四、钜链开放平台简介和基础 设施</div>
    </div> -->
  </div>
</template>
<script>
// import about  from '../../assets/about/超级共识-矩链开放平台-BaaS系统-开发者文档.html'
// import about from "../../assets/about";
// 代码高亮
import "highlight.js/styles/github.css";
// 其他元素使用 github 的样式
import "github-markdown-css";
export default {
  name: "DeveloperApi",
  data() {
    return {
      // ifeData:require('../../assets/temp'),
      // components: {
      //   about,
      // },
      introduceList: [
        { title: "SDK", value: "c++合约SDK" },
        { title: "合约编译工具", value: "智能合约编写、编译工具" },
      ],
      contentList: [
        {
          title: "一、如何编写智能合约？",
          value:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.",
        },
        {
          title: "二、开发环境的搭建",
          value:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.",
        },
        {
          title: "三、发起交易",
          value:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.",
        },
        {
          title: "四、调用合约",
          value:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.",
        },
        {
          title: "四、调用合约",
          value:
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.",
        },
      ],
    };
  },
  methods: {
    getDocumentDetails() {
      this.$router.push("/documentDetails");
    },
  },
  mounted() {
    // this.$refs.tempHtml.contentDocument.documentElement.innerHTML = this.ifeData
  },
};
</script>
<style lang="scss" scoped>
.DeveloperApi {
  margin: 24px 24px 0 24px;
  background: $color-primary;
  padding: 24px;
  display: flex;
  justify-content: space-between;
  .dev-lef {
    // margin-right: 40px;
    width: 100%;
    overflow-y: auto;
    .introduce {
      width: 208px;
      border-radius: 2px;
      border: 1px solid rgba(0, 0, 0, 0.15);
      // padding: 0px 16px 10px 16px;
      display: inline-block;
      // margin: 0 16px 40px 0;
      span {
        display: inline-block;
        margin: 10px 0 18px 0;
      }
    }
    .content {
      span {
        font-size: $size-title;
        font-weight: 500;
        color: $Black-85;
        border-bottom: 2px solid $Black-100;
        &:hover {
          cursor: pointer;
          color: $color-Blue-6;
          border-bottom: 2px solid $color-Blue-6;
        }
      }

      div {
        margin: 8px 0 24px 0;
        color: $Black-85;
        font-size: $size-bodyThe;
      }
    }
  }
  .dev-rig {
    width: 30%;
    width: 192px;
    height: 320px;
    background: #f5f7f9;
    padding: 16px;
    div {
      padding-left: 25px;
      text-indent: -25px;
      margin-bottom: 12px;
      font-size: 12px;
      font-weight: 400;
      color: rgba(0, 0, 0, 0.65);
    }
  }
}
</style>