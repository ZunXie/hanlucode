<template>
  <div class="Index">
    <Navigation
      :typeshow="true"
      :title="
        $route.name == 'documentDetails' ? '如何编写智能合约？' : '开发者文档'
      "
    >
      <div slot="select"></div>
      <div slot="search">
        <!-- <a-input-search
          placeholder="请输入关键字"
          size="small"
          style="width: 400px"
          enter-button
          @search="onSearch"
        /> -->
      </div>
    </Navigation>
    <router-view />
  </div>
</template>
<script>
import Navigation from "../../components/Navigation";

export default {
  name: "Index",
  components: { Navigation },
  data() {
    return {
      title: "开发者文档",
    };
  },
  methods: {
    onSearch() {
      console.log(1111111);
    },
  },
};
</script>