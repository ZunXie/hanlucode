<template>
  <div class="browser">
    <router-view v-if="route_key != 'browser'"></router-view>
    <div v-else>
      <Navigation :title="browserTitle" @search="onSearch"> </Navigation>
      <div v-if="show" class="browser_content">
        <!-- 数据展示 -->
        <div class="content_val">
          <div
            v-for="(item, index) in browser_content_list"
            :key="index"
            style="text-align: center"
          >
            <div>{{ item.title }}</div>
            <span v-if="index == 0"
              ><span>{{ item.value.toFixed(1) }}</span
              >s</span
            >
            <span v-else>{{ item.value ? item.value : '-' }}</span>
          </div>
        </div>
        <!-- 表格展示 -->
        <div class="content_table">
          <!-- <div style="text-align: end">
            <a-space
              ><a-icon type="reload" /><a-icon type="fullscreen"
            /></a-space>
          </div> -->

          <!-- 表格相关操作 -->
          <div class="top">
            <!-- 左侧预留位置 -->
            <div style="width:1px"></div>
            <!-- 右侧菜单栏 -->
            <div class="menu">
              <a-icon
                @click="reDo"
                style="marginLeft:16px;marginRight:8px;fontSize:16px"
                type="redo"
              />
              <a-icon
                v-if="fullStatu"
                @click="fullScreen"
                style="marginRight:8px;fontSize:16px"
                type="fullscreen"
              />
              <a-icon
                v-if="!fullStatu"
                @click="fullExit"
                style="marginRight:8px;fontSize:16px"
                type="fullscreen-exit"
              />
            </div>
          </div>

          <a-table
            bordered
            :columns="columns"
            size="small"
            :pagination="false"
            :scroll="{ y: 650 }"
            :locale="locale_browser"
            :data-source="data_browser"
            :rowKey="(record, index) => record.blockHeight"
            id="box"
          >
            <!-- 标题 -->
            <span slot="blockHeight"
              >区块高度
              <a-tooltip>
                <template slot="title"> 区块链上的块数 </template>
                <a-icon type="exclamation-circle" />
              </a-tooltip>
            </span>
            <span slot="blockTxCount"
              >交易数
              <a-tooltip>
                <template slot="title"> 当前区块内的交易数量 </template>
                <a-icon type="exclamation-circle" />
              </a-tooltip>
            </span>

            <!-- 内容 -->
            <template slot="blockHeight" slot-scope="text, record">
              <span class="formUnderline" @click="getBlockDeatils(record)">
                {{ record.blockHeight }}
              </span>
            </template>
            <template slot="blockId" slot-scope="text, record">
              <span class="formUnderline" @click="getBlockDeatils(record)">
                {{ record.blockId }}
              </span>
            </template>
            <template slot="proposer" slot-scope="text, record">
              <div>
                {{ record.jsonObject.proposer
                }}<CopyComp
                  tit="proposer"
                  :valuetext="record.jsonObject.proposer"
                />
              </div>
            </template>
            <template slot="timestamp" slot-scope="text, record">
              <span>
                {{ record.timestamp | format }}
              </span>
            </template>
          </a-table>
        </div>
      </div>
      <Empty v-else :height="emptyHeigth" text="暂无数据" />
    </div>
  </div>
</template>
<script>
import Navigation from './Browser_nav'
import { numAdd } from '@/utils/common'
import CopyComp from '@/components/CopyComp'

import { chainGroup_browInfo, chainGroup_getBlockHeight } from '@/utils/Browser'
import { getSessionStorage } from '../utils/util'
export default {
  name: 'browser',
  components: { Navigation, CopyComp },
  data() {
    return {
      // 全屏标志
      fullStatu: true,
      aa: 0,
      isshow: false,
      route_key: '',
      locale_browser: {
        emptyText: () => <Empty text="暂无数据" />,
      },
      browserTitle: '浏览器',
      browser_content_list: [
        { title: '同步区块', value: 0.1, key: 'periods' },
        { title: '区块高度', value: '', key: 'blockHeight' },
        { title: '合约总数', value: '', key: 'ctNumber' },
        { title: '交易总量', value: '', key: 'blockTxCount' },
      ],
      // 表格数据
      columns: [
        {
          scopedSlots: { customRender: 'blockHeight' },
          key: 'blockHeight',
          slots: { title: 'blockHeight' },
          width: '120px',
          className: 'column-right',
        },
        {
          dataIndex: 'blockTxCount',
          slots: { title: 'blockTxCount' },
          className: 'column-right',
          key: 'blockTxCount',
          width: '100px',
        },
        {
          title: '区块哈希',
          dataIndex: 'blockId',
          scopedSlots: { customRender: 'blockId' },
          key: 'blockId',
          width: '40%',
        },
        {
          title: '验证人',
          key: 'proposer',
          className: 'column-flex',
          scopedSlots: { customRender: 'proposer' },
          width: '24%',
        },
        {
          title: '提交时间',
          key: 'timestamp',
          scopedSlots: { customRender: 'timestamp' },
          sorter: (a, b) => a.timestamp - b.timestamp,
        },
      ],
      data_browser: null,
      // 定时器
      timer: null,
      str: {},
      page_key: this.$route.name,
      emptyHeigth: 0,
      show: true,
      timer2: null,
    }
  },
  methods: {
    // 刷新数据
    reDo() {
      this.getChainGroupBrowInfo()
    },
    // 全屏
    fullScreen() {
      // let ele = document.querySelector('.refTable')
      let ele = document.querySelector('.content_table')
      console.log('ele', ele)
      let requestMethod =
        ele.requestFullScreen ||
        ele.webkitRequestFullScreen || //谷歌
        ele.mozRequestFullScreen || //火狐
        ele.msRequestFullScreen //IE11

      if (requestMethod) {
        requestMethod.call(ele)
        ele.style.backgroundColor = '#fff'
      } else if (typeof window.ActiveXObject !== 'undefined') {
        // eslint-disable-next-line no-undef
        var wscript = new ActiveXObject('WScript.Shell') //创建ActiveX
        if (wscript !== null) {
          //创建成功
          wscript.SendKeys('{F11}') //触发f11
        }
      }
      this.fullStatu = !this.fullStatu
    },
    // 退出全屏
    fullExit() {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen()
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen()
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen()
      }
      this.fullStatu = !this.fullStatu
    },
    gettiiltip() {
      this.isshow = true
    },
    // 搜索
    async onSearch(data) {
      await this.getBlockDeatils({ blockHeight: data })
    },
    // 跳转区块详情
    getBlockDeatils(value) {
      this.$router.push({
        name: 'blockDetails',
        query: { str: value.blockHeight },
      })
    },
    //获取同步区块
    async getchainGroup() {
      let res = await chainGroup_browInfo({
        groupCode: getSessionStorage('groupCode')
          ? getSessionStorage('groupCode')
          : getSessionStorage('groupCodeAll'),
      })
      for (let key in res.data.data) {
        this.browser_content_list.map((i) => {
          if (i.key == key) {
            i.value = res.data.data[key]
          }
        })
      }
      return res
    },
    async getChainGroupBrowInfo() {
      await this.getchainGroup()
      // 获取列表
      let res = await this.getchainGroup_getBlockHeight('', 100, 1)
      this.show = false
      if (res.data.code == 200) {
        this.data_browser = res.data.data
        this.show = this.data_browser.length ? true : false
        this.browser_content_list[0].value = 0.1
      } else {
        this.$message.warning(res.data.msg)
        this.show = false
      }
    },
    async getchainGroup_getBlockHeight(height, size, direction) {
      // 获取详情列表表格
      let res = await chainGroup_getBlockHeight({
        groupCode: getSessionStorage('groupCode')
          ? getSessionStorage('groupCode')
          : getSessionStorage('groupCodeAll'),
        height: height,
        size: size,
        direction: direction,
      })
      return res
    },
    async handleScroll(e) {
      //变量scrollTop是滚动条滚动时，距离顶部的距离
      var scrollTop = e.target.scrollTop
      //变量windowHeight是可视区的高度
      var windowHeight = e.target.clientHeight
      //变量scrollHeight是滚动条的总高度
      var scrollHeight = e.target.scrollHeight
      //滚动条到底部的条件
      if (scrollTop + windowHeight == scrollHeight) {
        // // 获取数组最后一项
        var end = this.data_browser[this.data_browser.length - 1]
        if (end.blockHeight > 101) {
          let res = await this.getchainGroup_getBlockHeight(
            end.blockHeight - 21,
            20,
            0
          )
          this.data_browser = this.data_browser.concat(res.data.data.reverse())
          // //写后台加载数据的函数
        }
      }
    },
    //防抖
    debounce(fn, delay) {
      let timer = null //借助闭包
      return function(e) {
        if (timer) {
          clearTimeout(timer)
        }
        timer = setTimeout(() => {
          fn(e)
        }, delay) // 简化写法
      }
    },
    gettimer() {
      this.timer = setInterval(async () => {
        this.browser_content_list[0].value = numAdd(
          this.browser_content_list[0].value,
          0.1
        )
        if (this.browser_content_list[0].value % 3 == 0) {
          this.$store.commit('LOADDING_SHOW', true)
          let p2 = this.getchainGroup_getBlockHeight(
            this.data_browser[0].blockHeight,
            1,
            0
          )
          let p1 = this.getchainGroup()
          // 获取详情列表表格
          Promise.all([p2, p1])
            .then((result) => {
              if (result[0].data.data[0]) {
                if (
                  result[0].data.data[0].blockHeight !==
                  this.data_browser[0].blockHeight
                ) {
                  this.data_browser.unshift(result[0].data.data[0])
                  this.browser_content_list[0].value = 0.1
                }
              }
              this.$store.commit('LOADDING_SHOW', false)
            })
            .catch((error) => {
              console.log(error)
            })
        }
      }, 100)
    },
  },
  mounted() {
    this.emptyHeigth = document.body.clientHeight - 150
    // 获取点击到的链
    this.getChainGroupBrowInfo()
    // 获取表格的滚动条
    if (this.show) {
      let dom = document.getElementById('box')
      dom.addEventListener('scroll', this.handleScroll, true)
    }
    // if (this.data_browser&&this.data_browser.length > 0) {
    this.gettimer()
    // }
    this.setitem_event.add({
      key: this.page_key + '_brower',
      func: this.getChainGroupBrowInfo,
    })
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key + '_brower')
    clearInterval(this.timer)
    this.timer = null
  },
  watch: {
    $route: {
      immediate: true,
      deep: true,
      handler: function(val) {
        this.route_key = val.name
        // if (this.route_key == "browser") {
        //   this.setitem_event.del(this.page_key + "_brower");
        //   clearInterval(this.timer);
        //   this.timer = null;
        // } else{
        //    this.gettimer();
        // }
      },
    },
  },
}
</script>
<style lang="scss" scoped>
.searchslot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 33%;
}
.browser_content {
  margin: 24px 24px 0 24px;
  .content_val {
    background: $color-primary;
    display: flex;
    justify-content: space-around;
    padding: 24px 0;
    p {
      font-size: 14px;
      font-weight: 400;
      color: rgba(0, 0, 0, 0.45);
    }
    span {
      font-size: $size-Large;
      font-weight: bold;
      color: $color-tit;
    }
  }
  .content_table {
    margin-top: 16px;
    background: $color-primary;
    padding: 16px 16px 0 16px;
    .top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 35px;
    }
  }
  .formUnderline:hover {
    color: $color-Blue-6;
    cursor: pointer;
    border-bottom: 1px solid $color-Blue-6;
  }
}
</style>
