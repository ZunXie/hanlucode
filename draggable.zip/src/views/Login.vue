<template>
  <div>
    <!--使用draggable组件-->
    <div id="Dom" class="itxst">
      <!-- <div style="padding-left:10px">add事件例子,左边往右边拖动试试看</div> -->
      <div class="col">
        <draggable v-model="arr1" :options="{group:{name: 'itxst',pull:'clone',put:false }}" v-bind="{sort: false}"
          animation="300">
          <transition-group>
            <div :class="item.id==1?'item forbid':'item'" v-for="item in arr1" :id="item.id" :key="item.id">
              {{item.name}}
            </div>
          </transition-group>
        </draggable>
      </div>
      <div class="col twocol">
        <div :style="allstyle" id='box2'>
          <div :style="disstyle">
            <draggable v-model="arr2" :style="pidstyle" group="itxst" @choose="choose1" @add="add2" animation=" 300">
              <transition-group>
                <div v-for="(item,index) in arr2" :style="item.style" :id="item.id" @click="add2_box_click(item.id)"
                  :key="index">
                  <div>
                    <!-- <a-icon @click.stop="hlandClick(item)" type="close" /> -->
                  </div>
                  <div v-if="!item.imgurl"> {{item.name}}
                  </div>
                  <div :style="{'height':item.height}" v-else>
                    <img style="width:100%;height: 100%;" :src="item.imgurl" alt="">
                  </div>
                </div>
              </transition-group>
            </draggable>
          </div>
        </div>
      </div>
      <div class="col">
        <a-button @click="getgenerate" type="primary">
          生成代码 </a-button>
        <div style="width:300px" v-for="item in imgList">
          <img style="width:100%;height: 100%;" :src="item.imgurl" @click="getimg(item)" alt="">
        </div>


        <input v-model="url" />
        <button @click="sure_url">url</button>
        <div class="radio_group">
          <a-select style="width: 120px" @change="handleChange">
            <a-select-option value="1">
              头部
            </a-select-option>
            <a-select-option value="2">
              底部
            </a-select-option>
          </a-select>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  //导入draggable组件
  import draggable from "vuedraggable";

  function find_dom_data(id, arr) {
    let res = null;
    res = arr.find(item => item.id == id);
    return res;

  }
  export default {
    //注册draggable组件
    components: {
      draggable
    },
    data() {
      return {
        disstyle: {
          minHeight: 471 + 'PX',
          // 
        },
        pidstyle: {
          minHeight: 471 + 'px',
          overflow: 'auto',
          maxHeight: 918 + 'px',
          overflow: 'scroll',
          overflowX: 'hidden'
        },
        allstyle: {
          position: 'relative',
        },
        active_id: 0,
        url: '',
        //定义要被拖拽对象的数组
        arr1: [{
            id: 1,
            show: false,
            name: "www.itxst.com",
            imgurl: '',
            width: 50,
            height: 100,
            type: 'img',
            isheader: true,
            height: 88 + 'px',
            style: {
              background: 'red',
              height: 88 + 'px'
            }
          },
          {
            id: 2,
            show: false,
            name: "www.jd.com",
            imgurl: '',
            type: 'video',
            height: 300 + 'px',
            style: {
              background: 'yellow',
              height: 300 + 'px',
            }
          },
          {
            id: 3,
            show: false,
            name: "www.baidu.com",
            imgurl: '',
            height: 200 + 'px',
            style: {
              background: '#1890ff',
              height: 200 + 'px'
            }

          },
          {
            id: 4,
            show: false,
            name: "www.google.com"
          },
          {
            id: 5,
            show: false,
            name: "www.taobao.com"
          }
        ],
        arr2: [],
        arr: null,
        imgList: [{
          imgurl: 'https://img95.699pic.com/photo/40217/9777.jpg_wh300.jpg',
        }, {
          imgurl: 'https://img95.699pic.com/photo/40217/8608.jpg_wh300.jpg',
        }, {
          imgurl: 'https://img95.699pic.com/photo/40217/7127.jpg_wh300.jpg',
        }, {
          imgurl: 'https://img95.699pic.com/photo/40217/8599.jpg_wh300.jpg',
        }, ],
        type: false
      };
    },
    mounted() {},
    methods: {
      // 根据id删除指定数组
      detail_arr(item_arr, id) {
        let res = item_arr.filter((item) => item.id != id);
        return res
      },
      hlandClick(item) {
        this.arr2 = this.detail_arr(this.arr2, item.id)
      },
      callback(key) {
        console.log(key);
      },
      add2_box_click(id) {
        this.active_id = id;
      },
      getimg(item) {
        // this.dom_item.style.width = e.target.naturalWidth + 'px'
        // this.dom_item.style.height = e.target.naturalWidth + 'px'
        this.dom_item.imgurl = item.imgurl
      },
      // 鼠标选中的元素
      choose1(e) {
        this.arr1 = JSON.parse(JSON.stringify(this.arr1))
        let selt_id = e.item.id;
        this.dom_item = find_dom_data(selt_id, this.arr2);
        this.arr2.map((item) => {
          if (item.id == selt_id && item.style.background != 'none') {
            item.style.background = 'none'
            item.style.borderStyle = 'outset'
            item.style.borderColor = '#98bf21'
          } else {
            delete item.style.background
            delete item.style.borderStyle
            delete item.style.borderColor
          }
        })
      },
      sure_url() {
        let idx = this.arr2.findIndex(item => item.id == this.active_id);
        if (!this.active_id) {
          console.log('weixuanze');
        }
        this.arr2[idx].href = this.url;
        this.active_id = 0
      },
      //拖拽完成事件
      add1(e) {
        let selt_id = e.item.id;
        let item = find_dom_data(selt_id, this.arr1);
      },
      handleChange(value) {
        if (value) {
          this.dom_item.style.position = 'absolute';
          this.dom_item.style.width = 96 + '%'
          if (value == 1) {
            delete this.dom_item.style.bottom
            this.dom_item.style.top = 0;
            this.arr2[1].marginTop = this.arr2[0] + 'px'
            var end = this.arr2[this.arr2.length - 1].height
            this.arr2[this.arr2.length - 1].height = parseFloat(end) + parseFloat(this.dom_item.style.height) +
              'px'
          } else {
            delete this.dom_item.style.top
            var end = this.arr2[this.arr2.length - 1].height
            this.arr2[this.arr2.length - 1].style.height = parseFloat(end) + parseFloat(this.dom_item.style.height) +
              'px'
            this.dom_item.style.bottom = 0;
          }
          // 强制刷新视图
          this.$forceUpdate()
        }
      },
      add2(e) {
        this.arr1 = JSON.parse(JSON.stringify(this.arr1))
        let selt_id = e.item.id;
        let item = find_dom_data(selt_id, this.arr2);
        this.dom_item = item
        item.id = Math.random()
        this.arr2.map((i) => {
          if (i.id == item.id && item.style.background != 'none') {
            i.style.background = 'none'
            i.style.borderStyle = 'outset'
            i.style.borderColor = '#98bf21'
          } else {
            if (i.style.borderStyle || i.style.borderColor)
              delete i.style.background
            delete i.style.borderStyle
            delete i.style.borderColor
          }
        })
      },
      getgenerate() {
        //字符串转换成代码
        var s = new XMLSerializer();
        var d = document.getElementById('box2');
        var str = s.serializeToString(d);
        let s1_start = '<script>';
        let s_mid = '';
        for (let i = 0; i < this.arr2.length; i++) {
          //${this.arr2[i].href}
          s_mid += `document.getElementById('${this.arr2[i].id}').addEventListener('click',()=>{
        window.location.href = 'https://www.baidu.com/';
      });`
        }
        let s1_end = '<\/script>';
        str += s1_start;
        str += s_mid;
        str += s1_end;
        let stringHtml = (`
            <!DOCTYPE html>
            <html lang="zh-CN">
                 <head>
                    <meta http-equiv="x-ua-compatible" content="ie=edge, chrome=1">
                    <meta charset="UTF-8">
                    <meta name="renderer" content="webkit">
                    <meta name="author" content="WebpowerChina">
                    <link rel="WebpowerChina" href="mailto:market@webpowerchina.com">
                </head>
              <body >
                  <div style="width: 666px;margin: auto;">` + str + `
                  </div>
               </body>
            <html>
            `);
        console.log(stringHtml)
        let codeHtml = new DOMParser().parseFromString(stringHtml, 'text/html');
        console.log(codeHtml)
      }
    }
  };
</script>
<style scoped>
  .sTable::-webkit-scrollbar {
    display: none;
  }

  .itxst {
    margin: 10px;
    text-align: left;
    display: flex;
  }

  #box2 {}

  #box2 span {
    display: block;
    height: 100px;
  }

  .radio_group {
    margin-top: 20px;
  }

  .twocol {
    height: 500px;
  }

  .col {
    width: 40%;
    flex: 1;
    padding: 10px;
    border: solid 1px #eee;
    border-radius: 5px;
    float: left;

  }

  .all {
    height: 30px;
    background: red;
  }

  .col+.col {
    margin-left: 10px;
  }

  .item {
    padding: 6px 12px;
    margin: 0px 10px 0px 10px;
    border: solid 1px #eee;
    background-color: #f1f1f1;
    text-align: left;
  }

  .item+.item {
    border-top: none;
    margin-top: 6px;
  }

  .item:hover {
    background-color: #fdfdfd;
    cursor: move;
  }

  .item2 {
    padding: 6px 12px;
    margin: 0px 10px 0px 10px;
    border: solid 1px #eee;
    background-color: pink;
    text-align: left;
    height: 60px;
  }

  .item2+.item2 {
    border-top: none;
    margin-top: 6px;
  }

  .item2:hover {
    outline: solid 1px #ddd;
    cursor: move;
  }
</style>