<template>
  <!-- <a-spin :spinning="spinning"> -->
  <div class="Home">
    <div class="title">
      <div v-for="(item, index) in titlist" :key="index" class="title-box">
        <div class="box-left">
          <div>{{ item.tit }}</div>
          <div>
            <span class="title-box-value">{{ item.value }}</span
            ><span v-if="index == 1 || index == 2">个</span>
            <span v-else>条</span>
          </div>
        </div>
        <div class="box-right">
          <img style="width: 142px; height: 90px" :src="item.imgUrl" alt="" />
        </div>
      </div>
    </div>
    <!-- 引导流程 -->
    <div v-if="checkedShow" class="bootProcess">
      <div class="bootProcess-tit">
        <span class="fontSize14">引导流程</span>
        <a-popconfirm
          placement="left"
          ok-text="确认"
          cancel-text="取消"
          @confirm="confirm"
          @cancel="cancel"
        >
          <template slot="title">
            <div style="margin-bottom: 13px; width: 184px">
              <div style="margin-bottom: 6px">{{ text }}</div>
              <a-checkbox @change="onChange"> 不再提示 </a-checkbox>
            </div>
          </template>
          <a-icon type="close" />
        </a-popconfirm>
      </div>

      <div class="steps">
        <a-steps size="small" :current="current">
          <a-step v-for="(item, idnex) in stepslist" :key="idnex">
            <template slot="title"> {{ item.tit }} </template>
            <!-- <template slot="icon"> {{ item.tit }} </template> -->
            <a-step status="finish" title="Login">
              <a-icon type="user" slot="icon" />
            </a-step>
            <span slot="description"> {{ item.note }}</span>
            <div style="margin: 6px 0" slot="description">
              <a-button
                size="small"
                style="margin-right: 12px"
                v-if="item.button"
                @click="getsteps(item)"
                >{{ item.button }}</a-button
              >
              <a-button @click="goHelp" style="margin-left: -12px" type="link">
                {{ item.help }}
              </a-button>
            </div>
          </a-step>
        </a-steps>
      </div>
    </div>

    <!-- 我的节点 -->
    <div class="node">
      <div class="node-tit">
        <span class="fontSize14">我的节点</span>
        <a-button type="primary" @click="showDrawer" size="default" icon="plus">
          添加节点
        </a-button>
      </div>
      <a-table
        size="middle"
        bordered
        :columns="columns"
        :locale="localeNode"
        :pagination="false"
        :data-source="dataList"
        :rowKey="(record) => record.id"
      >
        <template slot="nodeAddress" slot-scope="text, record">
          <div>
            {{ record.nodeAddress
            }}<span
              ><CopyComp tit="nodeAddress" :valuetext="record.nodeAddress"
            /></span>
          </div>
        </template>
        <template slot="status" slot-scope="text, record">
          <div>
            <StatusColor :typeColor="record.status" />
            {{ record.status | NodeStatus }}
          </div>
        </template>
        <template slot="remark" slot-scope="text, record">
          <div>
            {{ record.remark ? record.remark : "---" }}
            <a-icon @click="getRemark(record)" type="form" />
          </div>
        </template>
        <template slot="operation" slot-scope="text, record">
          {{ record.operation }}
          <a-popconfirm
            v-if="record.status == 'Y'"
            placement="top"
            ok-text="确定"
            cancel-text="取消"
            :disabled="record.status == 'W'"
            @confirm="getstop(record)"
          >
            <template slot="title">
              <p>确认停止该节点</p>
            </template>
            <a>停止节点</a>
          </a-popconfirm>
          <a-popconfirm
            v-if="record.status == 'N'"
            placement="topRight"
            ok-text="确定"
            cancel-text="取消"
            @confirm="getstart(record)"
          >
            <template slot="title">
              <p>确认开启该节点</p>
            </template>
            <a>开启节点</a>
          </a-popconfirm>
          <a @click="getexport(record)" style="margin: 0 16px">导出私钥</a>
          <a @click="getdelete(record)">删除</a>
        </template>
      </a-table>
      <Paginationcom
        v-if="dataList.length > 4"
        v-model="paginationNode.current"
        :total="paginationNode.totalCount"
        show-size-changer
        :pageSize="paginationNode.pageSize"
        :page-size="paginationNode.pageSize"
        @onShowSizeChange="onShowSizeChangenode"
      ></Paginationcom>
    </div>

    <!-- 联盟链 -->
    <div class="leagueChain">
      <div class="node-tit">
        <span class="fontSize14">联盟链</span>
        <a-button @click="getLeagueChain">部署联盟链</a-button>
      </div>
      <a-table
        size="middle"
        bordered
        :pagination="false"
        :columns="columns_leagueChain"
        :data-source="data_leagueChain"
        :locale="locale"
        :rowKey="(record) => record.groupCode"
        ><template slot="status" slot-scope="text, record">
          <div>
            <StatusColor :typeColor="record.status" />
            {{ record.status | LeagueChainStatus }}
          </div>
        </template>
        <template slot="groupName" slot-scope="text, record">
          <div>
            {{ record.groupName }}
            <i
              @click="getModifyName(record)"
              class="iconfont icon-edit-square"
            ></i>
          </div>
        </template>
        <template slot="operation" slot-scope="text, record">
          {{ record.operation
          }}<span> <a @click="getManagement(record)">管理</a></span>
        </template>
      </a-table>
      <Paginationcom
        v-if="data_leagueChain.length > 0"
        v-model="pagination.current"
        :total="pagination.totalCount"
        show-size-changer
        :page-size="pagination.pageSize"
        @onShowSizeChange="onShowSizeChange"
      ></Paginationcom>
    </div>

    <!-- 添加节点抽屉 -->
    <DrawerHeadline
      v-if="isDrawerShow"
      :DrawerTitle="DrawerTitle"
      :isDrawerShow.sync="isDrawerShow"
      :isDrawerWidth="isDrawerWidth"
      @spinninglod="spinninglod"
    />

    <!-- 部署联盟链抽屉 -->
    <DrawerLeagueChain
      v-if="isLeagueChain"
      :isLeagueChain.sync="isLeagueChain"
      @spinninglod="spinninglod"
    />

    <!-- 修改ip地址 -->
    <CommonModal
      v-if="isModifyCommon"
      :isModifyCommon.sync="isModifyCommon"
      :CommonModalValue="CommonModalValue"
      @handFormValue="handleOk"
    />

    <!-- 删除节点弹框 -->
    <a-modal
      wrapClassName="removeNodes"
      v-model="isremoveNodes"
      centered
      :width="450"
      :closable="false"
      title="Basic Modal"
      @ok="handleOk"
    >
      <div style="display: flex">
        <div class="icon-lf">
          <a-icon
            style="color: #faad14; font-size: 24px"
            type="exclamation-circle"
            theme="filled"
          />
        </div>
        <div class="span-rg">
          <div class="nodeAddress">删除节点:{{ nodedellist.nodeAddress }}</div>
          <div>
            删除节点后，节点将从BAAS服务的管理列表中移除，但节点仍会运行，您可重新将节点添加到管理列表中。删除前请确保您已通过任何方式保存了本节点的私钥，否则您可能无法重新管理本节点，甚至导致资产永久丢失！
          </div>
        </div>
      </div>
      <template slot="footer">
        <a-button key="back" @click="getremove"> 取消 </a-button>
        <a-button
          key="submit"
          @click="getchainNode_removeNode(nodedellist)"
          :disabled="countdown > 0"
          type="danger"
        >
          删除<span v-if="countdown > 0">({{ countdown }}s)</span>
        </a-button>
      </template>
    </a-modal>

    <a-modal v-model="isvisiblestop" :width="360" centered title="输入SSH信息">
      <a-form-model
        layout="vertical"
        ref="ruleForm"
        :model="form"
        :rules="rules"
      >
        <a-form-model-item label="远程账号" prop="sshAccount">
          <a-input v-model="form.sshAccount" />
        </a-form-model-item>

        <a-form-model-item label="密码" prop="sshPassword">
          <a-input v-model="form.sshPassword" />
        </a-form-model-item>
        <a-form-model-item label="访问端口" prop="sshPort">
          <a-input v-model="form.sshPort" />
        </a-form-model-item>
      </a-form-model>
      <template slot="footer">
        <a-button key="back" @click="handleCancel('ruleForm')"> 取消 </a-button>
        <a-button key="submit" type="primary" @click="onSubmit('ruleForm')">
          确定
        </a-button>
      </template>
    </a-modal>
  </div>
  <!-- </a-spin> -->
</template>

<script>
import {
  getNodeNum,
  chainNode_list,
  chainNode_stopNode,
  chainNode_startNode,
  user_neverShowBootProcess,
  chainNode_updateRemarkById,
  chainGroup_list,
  ct_getDeployedContractNum,
  chainGroup_countChainGroupNum,
  chainGroup_getMnemonicByNodeId,
  chainNode_removeNode,
  chainGroup_testSSH,
  user_shouldShowBootProcess,
} from "../../src/utils/home";
import { chainGroup_all } from "@/utils/home";
import { goToBrowser } from "@/mixins/goToBrowser";

import "../assets/css/tablecommon.scss";
import DrawerHeadline from "../components/DrawerHeadline";
import DrawerLeagueChain from "../components/DrawerLeagueChain";
import CommonModal from "../components/CommonModal";
import { chainGroup_updateName } from "@/utils/LeagueChain";
import { getSessionStorage, setSessionStorage } from "../utils/util";
export default {
  name: "Home",
  components: { DrawerHeadline, DrawerLeagueChain, CommonModal },
  mixins: [goToBrowser],

  data() {
    return {
      onChangeType: 0,
      locale: {
        emptyText: () => <Empty text="暂无联盟链" />,
      },
      localeNode: {
        emptyText: () => <Empty text="暂无节点" />,
      },
      pagination: {
        //分页数据
        current: 1,
        pageSize: 10,
        totalCount: 0,
      },
      paginationNode: {
        //分页数据
        current: 1,
        pageSize: 4,
        totalCount: 0,
      },
      spinning: false,
      isvisiblestop: false,
      nodedellist: "",
      isDrawerShow: false,
      isLeagueChain: false,
      isModifyCommon: false,
      CommonModalValue: {
        RemarkTitle: "修改备注",
        label: "备注",
      },
      countdown: 5,
      timer: null,
      DrawerTitle: "添加节点",
      RemarkTitle: "",
      label: "",
      isDrawerWidth: 360,
      ravalue: 1,
      current: 0,
      user: {},
      // 标题
      titlist: [
        {
          tit: "已部署区块链",
          value: "",
          imgUrl: require("../img/2021-12-31/home_deploy@2x.png"),
        },
        {
          tit: "节点数",
          value: "",
          imgUrl: require("../img/2021-12-31/home_node@2x.png"),
        },
        {
          tit: "已部署智能合约",
          value: "",
          imgUrl: require("../img/2021-12-31/home_contract@2x.png"),
        },
      ],
      // 步骤条
      stepslist: [
        {
          tit: "添加区块链节点",
          note: "连接或一键部署区块链节点",
          button: "去添加",
          help: "查看帮助",
          current: 0,
        },
        {
          tit: "部署联盟链",
          note: "创建一条自己的联盟链",
          button: "去部署",
          help: "查看帮助",
          current: 1,
        },

        {
          tit: "编写和部署智能合约",
          note: "根据业务需求编写合约并部署到联盟链",
          button: "去看看",
          help: "查看帮助",
          current: 2,
        },
        {
          tit: "应用开发和业务对接",
          note: "开发区块链应用或者通过调用智能合约实现业务对接",
          //   button: "去添加",
          help: "查看帮助",
          current: 3,
        },
      ],
      columns: [
        {
          title: "IP地址",
          dataIndex: "serverIp",
          key: "serverIp",
          scopedSlots: { customRender: "serverIp" },
          width: "18%",
        },
        {
          title: "节点地址",
          className: "column-flex",
          key: "nodeAddress",
          scopedSlots: { customRender: "nodeAddress" },
          width: "35%",
        },
        {
          title: "联盟链数量",
          dataIndex: "chainGroupNum",
          className: "column-right",
          key: "chainGroupNum",
          width: "20%",
        },
        {
          title: "状态",
          dataIndex: "status",
          className: "column-flexl",
          scopedSlots: { customRender: "status" },
          key: "status",
          ellipsis: true,
          width: "20%",
        },
        {
          title: "备注",
          className: "column-flex",

          scopedSlots: { customRender: "remark" },
          key: "remark",
          ellipsis: true,
          width: "15%",
        },
        {
          title: "操作",
          key: "operation",
          className: "column-center",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "250px",
        },
      ],
      dataList: [],
      columns_leagueChain: [
        {
          title: "链名",
          dataIndex: "groupCode",
          key: "groupCode",
          width: "18%",
        },
        {
          title: "联盟链名称",
          dataIndex: "groupName",
          key: "groupName",
          className: "column-flex",
          scopedSlots: { customRender: "groupName" },
          width: "32%",
        },
        {
          title: "节点数",
          dataIndex: "nodeCount",
          className: "column-right",
          key: "nodeCount",
          width: "20%",
        },
        {
          title: "状态",
          className: "column-flexl",

          dataIndex: "status",
          scopedSlots: { customRender: "status", ellipsisSlot: true },
          key: "status",
          ellipsis: true,
          width: "20%",
        },
        {
          title: "创建时间",
          dataIndex: "modifyTime",
          key: "modifyTime",
          ellipsis: true,
          width: "20%",
        },
        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "50px",
        },
      ],
      data_leagueChain: [],
      buttonWidth: 70,
      text: "确定关闭引导流程吗?",
      checkedShow: getSessionStorage("checked") ? false : true,
      endValue: {},
      isremoveNodes: false,
      form: {},
      rules: {
        sshPassword: [
          {
            required: true,
            message: "请输入必填项",
            trigger: "blur",
          },
        ],
        sshAccount: [
          {
            required: true,
            message: "请输入必填项",
            trigger: "blur",
          },
        ],
        sshPort: [{ required: true, message: "请输入必填项", trigger: "blur" }],
      },
    };
  },
  methods: {
    cancel() {
      this.$message.warning("已取消");
    },
    spinninglod(val) {
      this.spinning = val;
    },

    onSubmit(formName) {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          let res = await chainGroup_testSSH(this.form);
          if (res.data.code == 200 && this.form.type == "stop") {
            // 关掉节点
            let res = await chainNode_stopNode(this.form);
            if (res.data.code == 200) {
              this.$message.success("操作成功");
              this.getinit();
              this.isvisiblestop = false;
              this.$refs[formName].resetFields();
            } else {
              this.$message.warning(res.data.msg);
            }
          } else if (res.data.code == 200 && this.form.type == "start") {
            // 开启节点
            let res = await chainNode_startNode(this.form);
            if (res.data.code == 200) {
              this.$message.success("操作成功");
              this.getinit();

              this.isvisiblestop = false;
            } else {
              this.$message.warning(res.data.msg);
            }
          } else if (res.data.code !== 200) {
            this.$message.warning(res.data.msg);
            this.form = {};
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    // 开启节点
    async getstart(value) {
      if (!value.hasSshInfo) {
        this.isvisiblestop = true;
      }
      this.form.serverIp = value.serverIp;
      this.form.nodeId = value.id;
      this.form.type = "start";
      this.spinning = true;
      // 开启节点
      let res = await chainNode_startNode(this.form);
      this.spinning = false;
      if (res.data.code == 200) {
        this.$message.success("操作成功");
        this.getinit();

        this.isvisiblestop = false;
      } else {
        this.$message.warning(res.data.msg);
      }
    },
    //停止开启节点
    async getstop(value) {
      if (!value.hasSshInfo) {
        this.isvisiblestop = true;
      }
      this.form.serverIp = value.serverIp;
      this.form.nodeId = value.id;
      this.form.type = "stop";
      this.spinning = true;
      // 关掉节点
      let res = await chainNode_stopNode(this.form);
      this.spinning = false;
      if (res.data.code == 200) {
        this.$message.success("操作成功");
        this.getinit();
        this.isvisiblestop = false;
        this.$refs[formName].resetFields();
      } else {
        this.$message.warning(res.data.msg);
      }
    },
    //取消
    handleCancel(formName) {
      this.$refs[formName].resetFields();
      this.isvisiblestop = false;
    },
    // 联盟链分页改变时调用组件里的方法
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getChainGroupList();
    },
    onShowSizeChangenode(current, pageSize) {
      this.paginationNode.current = current;
      this.paginationNode.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getChainNodeList();
    },
    //点击步骤条
    getsteps(e) {
      // if (e.current > this.current || e.current - this.current >= 1) {
      //   this.$message.destroy();
      //   this.$message.warning("未完成上一个步骤");
      //   return;
      // } else
      if (this.current < 2 && e.current < this.current) {
        this.$message.destroy();
        this.$message.warning("已完成此步骤");
        return;
      }
      if (e.current == 0) {
        this.isDrawerShow = !this.isDrawerShow;
      } else if (e.current == 1) {
        this.getLeagueChain();
      } else if (e.current == 2) {
        this.$router.push("igentContract");
      }
    },

    //倒计时
    sendCode() {
      this.loading(); //启动定时器
      this.timer = setInterval(() => {
        //创建定时器
        if (this.countdown === 0) {
          this.clearTimer(); //关闭定时器
        } else {
          this.loading();
        }
      }, 1000);
    },
    loading() {
      //启动定时器
      this.countdown--; //定时器减1
    },
    clearTimer() {
      //清除定时器
      clearInterval(this.timer);
      this.timer = null;
    },

    //添加节点
    showDrawer() {
      this.isDrawerShow = !this.isDrawerShow;
    },
    // confirm(e) {
    //   setSessionStorage("checked", true);
    //   this.checked = false;
    //   this.$message.info("已取消");
    // },

    downloadUrl(res, name) {
      const blob = new Blob([res], { type: "application/vnd.ms-excel" }); // 构造一个blob对象来处理数据
      const fileName = name + ".txt"; // 导出文件名
      const elink = document.createElement("a"); // 创建a标签
      elink.download = fileName; // a标签添加属性
      elink.style.display = "none";
      elink.href = URL.createObjectURL(blob);
      document.body.appendChild(elink);
      elink.click(); // 执行下载
      URL.revokeObjectURL(elink.href); // 释放URL 对象
      document.body.removeChild(elink); // 释放标签
    },
    //导出私钥
    getexport(value) {
      let that = this;
      this.$confirm({
        title: "导出私钥",
        okText: "确认导出",
        centered: true,
        cancelText: "取 消",
        icon: () =>
          this.$createElement("a-icon", {
            props: {
              type: "exclamation-circle",
              theme: "filled",
            },
          }),
        content:
          "导出私钥功能将通过网络传输将服务器中保存的私钥导出到您本地计算机；如果您已通过任何方式保存了当前节点私钥，请不要频繁使用导出私钥功能，避免网络传输过程中出现被盗风险！",
        onOk() {
          chainGroup_getMnemonicByNodeId({ nodeId: value.id }).then((res) => {
            // if (res.data.code == 200) {
            var exportFileName = "私钥"; //设置导出的文件名，可以拼接一个随机值
            that.downloadUrl(res.data, exportFileName);
            that.$message.success("导出成功");
            // } else {
            // that.$message.success(res.data.msg);
            // }
          });
        },
        onCancel() {},
      });
    },
    getremove() {
      this.isremoveNodes = false;
    },
    // 删除节点确定
    async getchainNode_removeNode(value) {
      const totalPage = Math.ceil(
        (this.paginationNode.totalCount - 1) / this.paginationNode.pageSize
      ); // 总页数
      this.paginationNode.current =
        this.paginationNode.current > totalPage
          ? totalPage
          : this.paginationNode.current;
      this.paginationNode.current =
        this.paginationNode.current < 1 ? 1 : this.paginationNode.current;
      chainNode_removeNode(
        { nodeId: value.id },
        "application/x-www-form-urlencoded"
      ).then((res) => {
        if (res.data.code == 200) {
          this.isremoveNodes = false;
          this.getinit();
          this.$message.success("删除成功");
        }
      });
    },
    //删除节点打开弹窗
    getdelete(value) {
      this.countdown = 5;
      this.nodedellist = value;
      this.sendCode();
      this.isremoveNodes = true;
    },
    //部署联盟链
    getLeagueChain() {
      if (this.dataList.length <= 0) {
        this.$message.destroy();
        this.$message.error("要添加节点后才能部署联盟链");
        return;
      }
      this.isLeagueChain = !this.isLeagueChain;
    },
    //修改备注
    getRemark(item) {
      console.log(item);
      let params = {
        RemarkTitle: "修改备注",
        label: "备注",
        value: item.remark,
        type: "remark",
        groupCode: item.groupCode,
        antCol: 2,
      };
      this.endValue.id = item.id;
      this.isModifyCommon = !this.isModifyCommon;
      this.CommonModalValue = params;
    },
    // 获取节点列表
    async getChainNodeList() {
      let param = {
        pageNum: this.paginationNode.current,
        pageSize: this.paginationNode.pageSize,
      };
      let res = await chainNode_list(param);
      this.dataList = res.data.data.rows;
      this.paginationNode.totalCount = res.data.data.total;
      if (res.data.data.total > 0) {
        this.$store.commit("DISABLED", true);
        setSessionStorage("disabled", true);
      } else if (res.data.data.total <= 0) {
        this.$store.commit("DISABLED", false);
        setSessionStorage("disabled", false);
      }
    },

    //获取联盟链列表
    async getChainGroupList() {
      let param = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
      };
      let res = await chainGroup_list(param);
      this.data_leagueChain = res.data.data.rows;
      this.pagination.totalCount = Number(res.data.data.total);
      //已部署区块链数量
      chainGroup_countChainGroupNum({}).then((res) => {
        this.titlist[0].value = res.data.data;
      });
      //获取节点数
      getNodeNum({}).then((res) => {
        this.titlist[1].value = res.data.data;
      });
      //已部署智能合约
      ct_getDeployedContractNum({}).then((res) => {
        this.titlist[2].value = res.data.data;
      });
    },
    //联盟链管理
    getManagement(value) {
      setSessionStorage("groupCode", value.groupCode);
      this.$router.push({
        path: "/LeagueChain",
        query: { id: value.groupCode },
      });
    },
    // 修改联盟链名称
    getModifyName(item) {
      let params = {
        RemarkTitle: "修改联盟链名称",
        label: "联盟链名称",
        value: item.groupName,
        type: "ModifyName",
        groupCode: item.groupCode,
        antCol: 4,
      };
      this.isModifyCommon = true;
      this.CommonModalValue = params;
    },
    //修改备注
    async handleOk(val) {
      if (val.type == "ModifyName") {
        let par = {
          groupCode: val.groupCode,
          name: val.value,
        };
        let res = await chainGroup_updateName(par);
        if (res.data.code == 200) {
          this.$message.success("修改成功");
          this.getChainGroupAll();
          this.getChainGroupList();
        }
      } else {
        this.endValue.remark = val.value;
        let res = await chainNode_updateRemarkById(this.endValue);
        if (res.data.code == 200) {
          this.$message.success("修改成功");
          this.getChainNodeList();
        }
      }
    },
    //获取链
    async getChainGroupAll() {
      let res = await chainGroup_all();
      setSessionStorage("groupCodeList", res.data.data);
      setSessionStorage("groupCodeAll", res.data.data[0].groupCode);
      this.$store.commit("GROUP_CODE", res.data.data[0].groupCode);
    },
    getinit() {
      this.getChainNodeList();
      this.getChainGroupList();
      this.getChainGroupAll();
    },
    // 获取引导流程是否显示
    async getuser_shouldShowBootProcess() {
      let res = await user_shouldShowBootProcess();
      this.checkedShow = res.data.data;
    },
    // 不再提示
    onChange(e) {
      this.onChangeType = e.target.checked;
    },
    async confirm() {
      if (this.onChangeType) {
        await user_neverShowBootProcess();
        this.checkedShow = false;
      } else {
        await setSessionStorage("checked", true);
        this.checkedShow = false;
      }
      this.$message.info("已取消");
    },
  },
  mounted() {
    if (!getSessionStorage("checked")) {
      this.getuser_shouldShowBootProcess();
    }
    this.getinit();
  },
  watch: {
    getList() {
      this.isLeagueChain = false;
      this.getinit();
    },
    getChainNode() {
      this.getinit();
    },
  },
  computed: {
    getList() {
      return this.$store.state.chainGroup_create;
    },
    getChainNode() {
      return this.$store.state.deploymentOf;
    },
  },
};
</script>
<style lang="scss" scoped>
.statusColor:before {
  content: " ";
  width: 8px;
  height: 8px;
  background: red;
  display: inline-block;
  border-radius: 50%;
}
.Home {
  padding: 24px;
}
.span-rg {
  margin-left: 20px;
  font-size: 12px;
  .nodeAddress {
    font-size: 14px;
    font-weight: 500;
    color: $Black-85;
    margin-bottom: 10px;
  }
  div {
    color: $Black-45;
  }
}
.title {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.title-box {
  width: 31.5%;
  box-shadow: 0px 0px 8px 0px rgba(0, 21, 41, 0.04);
  background: $color-primary;
  padding: 14px 16px 10px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .title-box-value {
    font-size: 28px;
    font-family: DIN-Bold, DIN;
    font-weight: bold;
    color: rgba(0, 0, 0, 0.85);
    line-height: 50px;
    margin-top: 14px;
  }
}
.bootProcess {
  height: 207px;
  background: $color-primary;
  box-shadow: 0px 0px 8px 0px rgba(0, 21, 41, 0.04);
  border-radius: 2px;
  margin: 16px 0;
  .ant-btn {
    width: 60px;
    height: 28px;
    border-radius: 2px;
    font-size: 12px;
  }
  .ant-steps-horizontal:not(.ant-steps-label-vertical)
    .ant-steps-item-description {
    margin-top: 5px;
  }
}
.bootProcess-tit {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 11px 16px;
  border-bottom: 1px solid $color-divider;
}
.steps {
  padding: 32px 24px 44px 32px;
}
::v-deep.ant-steps-horizontal:not(.ant-steps-label-vertical)
  .ant-steps-item-description {
  max-width: 208px;
  white-space: normal;
  font-size: 12px;
}
::v-deep.ant-steps-item-finish
  > .ant-steps-item-container
  > .ant-steps-item-content
  > .ant-steps-item-title {
  font-size: $size-title;
  font-weight: 600;
}
.node {
  background: #ffffff;
  box-shadow: 0px 0px 8px 0px rgba(0, 21, 41, 0.04);
  border-radius: 2px;
  padding: 11px 16px 36px 16px;
  margin: 16px 0 16px 0;
}

.leagueChain {
  background: $color-primary;
  box-shadow: 0px 0px 8px 0px rgba(0, 21, 41, 0.04);
  border-radius: 2px;
  padding: 11px 16px 0 16px;
}
::v-deep .removeNodes .ant-modal-body {
  padding: 24px 40px 24px 26px;
}
::v-deep .ant-modal-footer {
  padding: 0 24px 16px 0;
}
</style>