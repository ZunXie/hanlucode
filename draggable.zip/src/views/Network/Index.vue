<template>
  <div class="Index">
    <Navigation :title="$route.name == 'userlog' ? '用户日志' : '监控中心'" />
    <router-view />
  </div>
</template>
<script>
import Navigation from "../../components/Navigation";
export default {
  name: "Index",
  components: { Navigation },
  data() {
    return {
      title: "",
    };
  },
};
</script>