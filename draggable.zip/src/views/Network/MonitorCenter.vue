<template>
  <div class="MonitorCenter">
    <div class="netstatMap">
      <div class="map">
        <p class="fontSize14">区块网络监控</p>
        <a-divider />
        <div v-if="nodeLists.length > 0" id="container"></div>
        <Empty
          v-else
          style="margin: 17px"
          :height="320"
          background="#f5f7f9"
          text="暂无地图数据"
        />
      </div>
      <div class="netstat">
        <p class="fontSize14">网络状态</p>
        <a-divider />
        <div v-if="networkStatus.blockHeight">
          <div class="state">
            <img
              class="an img"
              style="width: 240px; height: 240px, position: relative;"
              src="../../img/monitoringcenter_operation@2x.png"
              alt=""
            />
            <div class="state_figure">
              <div
                style="
                  font-size: 28px;
                  font-family: DIN-Bold, DIN;
                  font-weight: bold;
                  color: #007aff;
                  text-align: center;
                "
              >
                {{ networkStatus.createdDays }}
              </div>
              安全运行/天
            </div>
          </div>
          <div class="newblock">
            <div>
              <div class="newblock_title">
                {{
                  networkStatus.blockHeight ? networkStatus.blockHeight : "---"
                }}
              </div>
              <span>最新区块</span>
            </div>

            <a-divider style="height: 48px" type="vertical" />
            <div>
              <div class="newblock_title">
                {{
                  networkStatus.blockHeight
                    ? networkStatus.blockHeight - 1
                    : "---"
                }}
              </div>
              <span>上一个区块</span>
            </div>
          </div>
        </div>
        <!-- 离线状态 -->
        <div v-else>
          <div class="state">
            <img
              style="width: 240px; height: 240px, position: relative;"
              src="../../img/monitoringcenter_off-line@2x.png"
              alt=""
            />
            <div class="state_figure">
              <div
                style="
                  font-size: 28px;
                  font-family: DIN-Bold, DIN;
                  font-weight: bold;
                  color: #ff5153;
                  text-align: center;
                "
              >
                -
              </div>
              离线/天
            </div>
          </div>
          <div class="newblock">
            <div>
              <div class="newblock_title">-</div>
              <span>最新区块</span>
            </div>

            <a-divider style="height: 48px" type="vertical" />
            <div>
              <div class="newblock_title">-</div>
              <span>上一个区块</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 节点列表 -->
    <div class="nodeList">
      <p class="fontSize14">节点列表</p>
      <a-table
        bordered
        :columns="columns"
        :rowKey="(record) => record.id"
        :pagination="false"
        :locale="localenodeList"
        :data-source="nodeLists"
        ><template slot="nodeAddress" slot-scope="text, record">
          <div>
            {{ record.nodeAddress ? record.nodeAddress : "----"
            }}<CopyComp
              v-if="record.nodeAddress"
              tit="nodeAddress"
              :valuetext="record.nodeAddress"
            />
          </div>
        </template>
        <template slot="serverIp" slot-scope="text, record">
          <div>
            {{ record.serverIp ? record.serverIp : "----" }}
          </div>
        </template>
        <template slot="operator" slot-scope="text, record">
          <div>
            {{ record.operator ? record.operator : "----" }}
          </div>
        </template>
      </a-table>
      <div style="display: inline-block">
        <PaginationcUser
          v-if="pagination.totalCount >= 100"
          v-model="pagination.current"
          :total="pagination.totalCount"
          show-size-changer
          :page-size="pagination.pageSize"
          @onShowSizeChange="onShowSizeChange"
        />
      </div>
    </div>
  </div>
</template>
<script>
const echarts = require("echarts");
import "echarts/extension/bmap/bmap";
import { chainGroup_nodes } from "@/utils/LeagueChain";
import { getSessionStorage } from "@/utils/util";
import { chainGroup_browInfo } from "@/utils/Browser";
import { chainNode_listCityNodeList } from "@/utils/Network";

export default {
  name: "MonitorCenter",
  data() {
    return {
      localenodeList: {
        emptyText: () => <Empty text="暂无数据" />,
      },
      columns: [
        {
          title: "节点ID",
          dataIndex: "nodeAddress",
          key: "nodeAddress",
          className: "column-flex",
          scopedSlots: { customRender: "nodeAddress" },
          width: "30%",
        },
        {
          title: "节点IP",
          dataIndex: "serverIp",
          key: "serverIp",
          scopedSlots: { customRender: "serverIp" },
          width: "20%",
        },
        {
          title: "运营方",
          key: "operator",
          dataIndex: "operator",
          scopedSlots: { customRender: "operator" },
          width: "20%",
        },
        {
          title: "提交时间",
          key: "createTime",
          dataIndex: "createTime",
          width: "20%",
          // sorter: (a, b) => a.action - b.action,
        },
      ],
      pagination: {
        //分页数据
        current: 1,
        pageSize: 100,
        totalCount: 0,
      },
      nodeLists: [],
      networkStatus: {},
      geoCoordMap: {
        // 位置1: [90.9180416971, 41.080715534],
        // 位置2: [123.4965120599, 51.0206466741],
        // 位置3: [100.4728967514, 26.1734892363],
        // 位置4: [121.5121844054, 31.2106872661],
        // 位置5: [111.50148, 31.2458353752],
        // 位置6: [111.50148, 24.2458353752],
      },
      page_key: this.$route.name,
      data: [
        // { name: "位置1", value: 19 },
        // { name: "位置2", value: 20 },
        // { name: "位置3", value: 32 },
        // { name: "位置4", value: 24 },
        // { name: "位置5", value: 46 },
        // { name: "位置6", value: 30 },
      ],

      length: "",
      myChart: null,

      options: {
        title: {
          left: "center",
        },
        tooltip: {
          trigger: "item",
        },
        bmap: {
          center: [104.114129, 37.550339],
          zoom: 4,
          roam: true,
          mapStyle: {
            styleJson: [
              {
                featureType: "water",
                elementType: "all",
                stylers: {
                  color: "#c2e3f4",
                },
              },
              {
                featureType: "land",
                elementType: "all",
                stylers: {
                  color: "#f3f3f3",
                },
              },
              {
                featureType: "railway",
                elementType: "all",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "highway",
                elementType: "all",
                stylers: {
                  color: "#fdfdfd",
                },
              },
              {
                featureType: "highway",
                elementType: "labels",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "arterial",
                elementType: "geometry",
                stylers: {
                  color: "#b7bbbf",
                },
              },
              {
                featureType: "arterial",
                elementType: "geometry.fill",
                stylers: {
                  color: "#b7bbbf",
                },
              },
              {
                featureType: "poi",
                elementType: "all",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "green",
                elementType: "all",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "subway",
                elementType: "all",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "manmade",
                elementType: "all",
                stylers: {
                  color: "#c2e3f4",
                },
              },
              {
                featureType: "local",
                elementType: "all",
                stylers: {
                  color: "#c2e3f4",
                },
              },
              {
                featureType: "arterial",
                elementType: "labels",
                stylers: {
                  visibility: "off",
                },
              },
              {
                featureType: "boundary",
                elementType: "all",
                stylers: {
                  color: "#b7bbbf",
                },
              },
              {
                featureType: "building",
                elementType: "all",
                stylers: {
                  color: "#c2e3f4",
                },
              },
              {
                featureType: "label",
                elementType: "labels.text.fill",
                stylers: {
                  color: "#999999",
                },
              },
            ],
          },
        },
        series: [
          {
            name: "",
            //悬浮文字
            tooltip: {
              show: true,
              formatter: function (params) {
                return params.name + " <br/>节点总数:" + params.data.num;
              },

              //文字样式
              // textStyle: {
              //   color: "red",
              // },
              //框的背景颜色
              // backgroundColor: 'orange'
            },
            //不用悬浮 直接显示的文字
            label: {
              //要显示的文字内容通过formatter获取 设置
              formatter: "{b}",
              position: "right",
              //控制显示隐藏
              show: false,
              //文本样式 颜色 textStyle
              textStyle: {
                color: "red",
              },

              //给背景色
              // backgroundColor:"pink",
              //给高
              // lineHeight: 56,
            },
            type: "effectScatter",
            coordinateSystem: "bmap",
            data: [],
            symbolSize: 12, // 图表的点的大小
            encode: {
              value: 2,
            },
            showEffectOn: "render",
            rippleEffect: {
              brushType: "stroke",
            },
            hoverAnimation: true,
            //小圆点的样式
            itemStyle: {
              shadowBlur: 30,
              shadowColor: "#007aff",
              color: "#007aff",
            },
            zlevel: 1,
          },
        ],
      },
      timer: null,
      aa: 0,
    };
  },
  async mounted() {
    this.getinit();
    this.setitem_event.add({
      key: this.page_key,
      func: this.getinit,
    });
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key);
    clearInterval(this.timer);
    this.timer = null;
  },
  methods: {
    // 分页
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getinit();
    },
    // 地图信息
    async getchainNode_listCityNodeList() {
      this.data = [];
      let groupCode = await this.getgroupCode();
      let res = await chainNode_listCityNodeList({
        groupCode: groupCode,
      });
      // 更改地图需要结构
      res.data.data.map((i, v) => {
        this.data.push({ name: i.city, value: i.nodeNums });
        this.data = JSON.parse(JSON.stringify(this.data));
        this.geoCoordMap[i.city] = [i.lng, i.lat];
      });
    },
    async getinit() {
      await this.getchainGroup_browInfo();
      await this.getchainNode_listCityNodeList();
      await this.getchainGroup_nodes();
      await this.initMap();
    },
    initMap() {
      this.data = this.data;
      this.options.series[0].data = this.convertData(
        this.data
          .sort(function (a, b) {
            return b.value - a.value;
          })
          .slice(0, 7)
      );

      this.myChart = echarts.init(document.getElementById("container"));
      this.myChart.setOption(this.options);
    },
    //固定写法
    convertData(data) {
      var res = [];
      for (var i = 0; i < data.length; i++) {
        var geoCoord = this.geoCoordMap[data[i].name]; //首先根据data中的name作为键值读入地理坐标
        //var rjj1 = data[i].value;
        if (geoCoord) {
          res.push({
            name: data[i].name,
            value: geoCoord.concat(data[i].value), //随后将地理坐标与对应信息值衔接起来
            //成为了 [name 经度 纬度 value]的形式
            num: data[i].value,
          });
        }
      }
      //console.log(res)
      return res;
    },
    getgroupCode() {
      let groupCode = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : getSessionStorage("groupCodeAll")
        ? getSessionStorage("groupCodeAll")
        : "";
      return groupCode;
    },
    async getchainGroup_nodes() {
      let groupCode = await this.getgroupCode();
      let param = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        groupCode: groupCode,
      };
      let res = await chainGroup_nodes(param);
      this.nodeLists = res.data.data.rows;
      this.pagination.totalCount = res.data.data.total;
      this.$nextTick(() => {
        this.initMap();
      });
    },
    async getchainGroup_browInfo() {
      let groupCode = await this.getgroupCode();
      let res = await chainGroup_browInfo({
        groupCode: groupCode,
      });
      if (res.data.code == 200) {
        this.networkStatus = res.data.data;
      } else {
        this.$message.warning(res.data.msg);
      }
    },
  },
  watch: {
    getName() {
      this.getinit();
    },
  },
  computed: {
    getName() {
      return this.$store.state.name;
    },
  },
};
</script>
<style lang="scss" scoped>
// 图片旋转
@-webkit-keyframes rotation {
  from {
    -webkit-transform: rotate(0deg);
  }
  to {
    -webkit-transform: rotate(360deg);
  }
}
.an {
  -webkit-transform: rotate(360deg);
  animation: rotation 3s linear infinite;
  -moz-animation: rotation 3s linear infinite;
  -webkit-animation: rotation 3s linear infinite;
  -o-animation: rotation 3s linear infinite;
}

.img {
  border-radius: 250px;
}
.MonitorCenter {
  margin: 24px 24px 0 24px;
  .netstatMap {
    display: flex;
    justify-content: space-between;
    height: 397px;
    p {
      margin: 11px 16px;
    }
    .map {
      background: $color-primary;
      width: 100%;
      margin-right: 16px;
      #container {
        padding: 0 16px 0 16px;
        width: 100%;
        height: 320px;
        margin: auto;
      }
    }
    .netstat {
      background: $color-primary;
      width: 280px;
      padding: 24px;
    }
  }
  .nodeList {
    margin-top: 16px;
    background: $color-primary;
    padding: 11px 16px 0 16px;
    margin-bottom: 40px;
  }
  .state {
    display: flex;
    align-items: center;
    height: 65%;
    justify-content: center;
  }
  .newblock {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    .newblock_title {
      font-size: $size-listFont;
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: bold;
      color: $Black-85;
    }
    span {
      font-size: 12px;
      color: $Black-45;
    }
  }
  .state_figure {
    position: absolute;
  }
  .ant-table-wrapper {
    min-height: 290px;
  }
}
</style>