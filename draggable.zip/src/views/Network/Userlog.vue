<template>
  <div class="Userlog">
    <div class="searchFrom">
      <a-form-model layout="inline" :model="form">
        <div style="display: flex; justify-content: space-between">
          <div>
            <a-form-model-item label="操作人">
              <el-input size="small" v-model="form.user" placeholder="请输入" />
            </a-form-model-item>
            <a-form-model-item label="操作IP">
              <el-input size="small" v-model="form.ip" placeholder="请输入" />
            </a-form-model-item>
            <a-form-model-item label="操作时间">
              <el-date-picker
                @change="getTime"
                size="small"
                v-model="value1"
                value-format="yyyy-MM-dd hh:mm:ss"
                type="datetimerange"
                prefix-icon=" "
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              >
                <template slot="range-separator"
                  ><a-icon type="swap-right"
                /></template>
              </el-date-picker>
            </a-form-model-item>
          </div>
          <div>
            <a-form-model-item>
              <a-button @click="getSearch" type="primary"> 搜索 </a-button>
            </a-form-model-item>
          </div>
        </div>
      </a-form-model>
    </div>

    <div class="content_table">
      <!-- <div style="text-align: end">
        <a-space><a-icon type="reload" /><a-icon type="fullscreen" /></a-space>
      </div> -->
      <!-- <div class="pagination_pas">
        <a-pagination size="small" :total="50" :show-total="total => `Total ${total} items`" />
      </div> -->
      <a-table
        bordered
        :columns="columns"
        :pagination="false"
        :data-source="data_list"
        :locale="locale"
        :rowKey="(record) => record.id"
      >
      </a-table>
      <div style="display: inline-block">
        <PaginationcUser
          :current="pagination.current"
          :total="pagination.totalCount"
          :page-size="pagination.pageSize"
          @onShowSizeChange="onShowSizeChange"
        />
      </div>
    </div>
  </div>
</template>
<script>
import { user_userlog_list } from '@/utils/Network'
import { getSessionStorage } from '@/utils/util'
import PaginationcUser from '../../components/PaginationcUser'
export default {
  name: 'Userlog',
  component: { PaginationcUser },
  data() {
    return {
      locale: {
        emptyText: () => <Empty text="暂无操作日志" />,
      },
      form: { groupCode: '' },
      // 表格数据
      columns: [
        {
          title: '操作人',
          dataIndex: 'operatorName',
          key: 'operatorName',
          width: '18%',
        },
        {
          title: 'ip',
          dataIndex: 'ip',
          key: 'ip',
          width: '15%',
        },
        {
          title: '操作内容',
          dataIndex: 'info',
          scopedSlots: { customRender: 'info' },
          key: 'info',
          width: '40%',
        },
        {
          title: '操作时间',
          key: 'createTime',
          dataIndex: 'createTime',
          scopedSlots: { customRender: 'createTime' },
          width: '24%',
          sorter: (a, b) => a.createTime - b.createTime,
        },
      ],
      data_list: [],
      page_key: this.$route.name,
      value1: [],
      pagination: {
        //分页数据
        current: 1,
        pageSize: 100,
        totalCount: 0,
      },
    }
  },
  methods: {
    getgroupCode() {
      let groupCode = getSessionStorage('groupCode')
        ? getSessionStorage('groupCode')
        : getSessionStorage('groupCodeAll')
        ? getSessionStorage('groupCodeAll')
        : ''
      return groupCode
    },
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current
      this.pagination.pageSize = pageSize
      //改变完 重新渲染数据
      this.getuser_userlog_list()
    },
    getTime(e) {
      console.log(e)
      this.form.startTime = e[0]
      this.form.endTime = e[1]
    },
    getSearch() {
      this.getuser_userlog_list()
      this.pagination.current = 1
    },
    async getuser_userlog_list() {
      let groupCode = this.getgroupCode()
      this.form.pageNum = this.pagination.current
      this.form.pageSize = this.pagination.pageSize
      this.form.groupCode = groupCode
      let res = await user_userlog_list(this.form)
      this.data_list = res.data.data.rows
      this.pagination.totalCount = res.data.data.total
    },
  },
  mounted() {
    this.getuser_userlog_list()
    this.setitem_event.add({
      key: this.page_key,
      func: this.getuser_userlog_list,
    })
    //  加在时间后面的图标
    document.getElementsByClassName('el-range__close-icon')[0].className +=
      ' el-icon-date' //在原来的后面加这个
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key)
  },
}
</script>
<style lang="scss" scoped>
.Userlog {
  margin: 24px 24px 48px 24px;
  .searchFrom {
    padding: 16px 0 16px 16px;
    background: $color-primary;
  }
}
.content_table {
  margin-top: 16px;
  background: $color-primary;
  padding: 16px 16px 0 16px;
  min-height: 697px;
}
.pagination_pas {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 40px;
  background: #970909;
  width: 100%;
  z-index: 1000;
}
</style>
