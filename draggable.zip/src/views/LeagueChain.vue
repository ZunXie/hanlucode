<template>
  <div class="wrapper">
    <Navigation :title="TitleCompoents">
      <div v-if="routeidtype" slot="retlirn">
        <a-icon style="font-size: 12px" type="left" />返回
      </div>
    </Navigation>
    <div v-if="!type" class="balanceinChain">
      <div class="node">
        <span v-if="OperationNode.length > 0">
          操作执行节点
          <a-tooltip>
            <template slot="title">
              联盟链中添加/删除节点、修改节点类型等操作需要消耗主链燃料，使用该功能时需要一个管理员节点账户来执行操作并支付对应的燃料
            </template>
            <a-icon type="exclamation-circle" />
          </a-tooltip>
        </span>
        <a-select
          v-if="OperationNode.length > 0"
          v-model="OperationNodedef"
          style="width: 400px; margin: 0 16px"
        >
          <a-select-option
            v-for="(item, index) in OperationNode"
            :key="index"
            @click="handleChange(item)"
            :value="item.nodeAddress"
          >
            {{ item.nodeAddress }}({{ item.serverIp }})
          </a-select-option>
        </a-select>
      </div>
      <div class="mainBody">
        <a-descriptions :column="4" title="基础信息">
          <a-descriptions-item
            v-for="(item, index) in basicInformationList"
            :key="index"
            :label="item.label"
          >
            {{ item.value }}&nbsp;<a-icon
              v-if="index == 1"
              @click="getModifyName(item)"
              style="color: rgba(28, 106, 235, 1); font-size: 11px"
              type="form"
            />
          </a-descriptions-item>
        </a-descriptions>
        <a-descriptions :column="4" style="margin: 50px 0" title="共识配置">
          <a-descriptions-item
            v-for="(item, index) in new_list"
            :key="index"
            :span="index == 4 ? 2 : 1"
          >
            <span slot="label">
              {{ item.label }}&nbsp;
              <a-tooltip
                v-if="index == 4"
                title="当区块高度每到“height_gap”的倍数时，出块奖励变为原来的“ratio”倍"
              >
                <a-icon type="exclamation-circle" />&nbsp;&nbsp;
              </a-tooltip>
            </span>
            <span v-if="index == 1">{{ item.value }}毫秒</span>
            <span v-else-if="index == 2">{{ item.value }}MB</span>
            <span v-else-if="index == 5 || index == 3">{{
              item.value == 1 ? "有手续费" : "无手续费"
            }}</span>
            <span v-else>{{ item.value }}</span>
          </a-descriptions-item>
        </a-descriptions>

        <!-- 联盟链节点 -->
        <div class="node-tit">
          <span class="fontSize14">联盟链节点</span>
          <a-button
            size="default"
            v-if="OperationNode.length > 0"
            @click="getAddNode"
            icon="plus"
          >
            添加节点
          </a-button>
        </div>

        <a-table
          size="middle"
          bordered
          :columns="leagueChainNodes"
          :rowKey="(record) => record.id"
          :locale="localeagueChain"
          :data-source="leagueChainNodes_data"
          :pagination="false"
        >
          <template slot="serverIp" slot-scope="text, record">
            <div>
              {{ record.serverIp ? record.serverIp : "---"
              }}<a-icon
                v-if="!record.manageable"
                @click="getserverIp(record)"
                type="form"
              />
            </div>
          </template>
          <template slot="remark" slot-scope="text, record">
            <div>
              {{ record.remark ? record.remark : "---"
              }}<a-icon @click="getRemark(record)" type="form" />
            </div>
          </template>
          <template slot="operator" slot-scope="text, record">
            <div>
              {{ record.operator ? record.operator : "---"
              }}<a-icon
                v-if="!record.manageable"
                @click="getOperator(record)"
                type="form"
              />
            </div>
          </template>
          <template slot="operation" slot-scope="text, record">
            <div v-if="OperationNode.length > 0">
              {{ record.operation
              }}<span>
                <a-popconfirm
                  placement="topRight"
                  ok-text="确定"
                  cancel-text="取消"
                  okType="danger"
                  @confirm="confirm(record)"
                >
                  <template slot="title">
                    <p>确认从联盟链中移除该节点？</p>
                  </template>
                  <a>移除节点</a>
                </a-popconfirm>
              </span>
            </div>
            <div v-else><span>------</span></div>
          </template>
          <template slot="isAdmin" slot-scope="text, record">
            {{ record.isAdmin | IsAdminStatus }}
          </template>
          <template slot="status" slot-scope="text, record">
            <div>
              <StatusColor :typeColor="record.status" />
              {{ record.status | LeagueChainStatus }}
            </div>
          </template>
        </a-table>
        <Paginationcom
          v-if="pagination.totalCount > 10"
          v-model="pagination.current"
          :total="pagination.totalCount"
          show-size-changer
          :page-size="pagination.pageSize"
          @onShowSizeChange="onShowSizeChange"
        ></Paginationcom>
        <!-- 验证人节点 -->
        <div style="margin-top: 20px;" class="node-tit">
          <span class="fontSize14">验证人节点</span>
        </div>
        <div style="padding-bottom: 24px">
          <a-table
            size="middle"
            bordered
            :locale="localedataNode"
            :columns="columnsNode"
            :data-source="dataNode"
            :pagination="paginationtwo"
            :rowKey="(record) => record.id"
          >
            <template slot="status" slot-scope="text, record">
              <div>
                <StatusColor :typeColor="record.status" />
                {{ record.status | NodeStatus }}
              </div>
            </template>
            <template slot="isAdmin" slot-scope="text, record">
              {{ record.isAdmin | IsAdminStatus }}<span></span>
            </template>

            <template slot="remark" slot-scope="text, record">
              <div v-if="record.remark">
                {{ record.remark }}
              </div>
              <div v-else>---</div>
            </template>
            <template slot="operator" slot-scope="text, record">
              <div v-if="record.operator">
                {{ record.operator }}
              </div>
              <div v-else>
                <span>---</span>
              </div>
            </template>

            <template slot="type" slot-scope="type">
              {{ type }}
            </template>
            <template slot="state" slot-scope="state">
              {{ state }}
            </template>
          </a-table>
        </div>
      </div>

      <!-- 添加节点弹框 -->
      <a-modal
        v-model="visible"
        title="添加节点"
        ok-text="确认"
        cancel-text="取消"
        @ok="hideModal(false)"
        :centered="true"
        :width="440"
      >
        <a-form-model
          :model="form"
          :label-col="labelCol"
          :wrapper-col="wrapperCol"
        >
          <a-form-model-item label="节点类型">
            <a-select
              :default-value="NodeType[0].title"
              style="width: 160px"
              @change="handNodeType"
            >
              <a-select-option
                v-for="item in NodeType"
                :key="item.key"
                :value="item.val"
              >
                {{ item.title }}
              </a-select-option>
            </a-select>
          </a-form-model-item>
          <a-form-model-item label="节点地址">
            <a-space :size="16">
              <a-input
                style="width: 200px"
                v-model="form.nodeId"
                placeholder="请输入"
              />

              <a @click="hideModalAdd(true)"> 添加 </a>
              <a @click="getBatchAdd"> 批量添加 </a>
            </a-space>
          </a-form-model-item>
          <div style="margin-left: 80px">
            <a-tag
              style="margin-bottom: 8px"
              v-for="item in form.nodeAddressArray"
              :key="item"
              closable
              @close="log(item)"
            >
              {{ item | getSubStr }}
            </a-tag>
          </div>
        </a-form-model>
      </a-modal>

      <!-- 批量添加节点 -->
      <a-modal
        v-model="isAddNode"
        title="批量添加节点（每行输入一个）"
        ok-text="确定"
        cancel-text="取消"
        @ok="getisAddNode"
        :centered="true"
      >
        <a-textarea
          v-model="value"
          @change="getenter"
          placeholder="请输入"
          :auto-size="{ minRows: 20, maxRows: 20 }"
        />
      </a-modal>

      <!-- 修改名称ip备注节点运营放 -->

      <CommonModal
        v-if="isModifyCommon"
        :isModifyCommon.sync="isModifyCommon"
        :CommonModalValue="CommonModalValue"
        @handFormValue="handleOk"
      />

      <!-- 修改节点ip -->
      <CommonModal
        v-if="isModifyCommon"
        :isModifyCommon.sync="isModifyCommon"
        :CommonModalValue="CommonModalValue"
        @handFormValue="handleOk"
      />
    </div>

    <Empty v-else :height="emptyHeigth" text="暂无联盟链" />
  </div>
</template>

<script>
import Navigation from "../components/Navigation";
import CommonModal from "../components/CommonModal";

import {
  chainGroup_nodes,
  chainNode_listAdminNodesByGroupCode,
  chainGroup_detail,
  chainNode_listVerifyNodesByGroupCode,
  chainNode_listUsingNodesByGroupCode,
  chainNode_listUnusedNodesByGroupCode,
  chainGroup_addNode,
  chainGroup_subNode,
  chainGroup_updateName,
  chainNode_updateOperatorById,
  chainNode_updateRemarkById,
  chainNode_updateIp,
  chainGroup_batchAddNode,
} from "@/utils/LeagueChain";
import { getSessionStorage } from "@/utils/util";
import { chainGroup_all } from "@/utils/home";
import { setSessionStorage } from "@/utils/util";

export default {
  components: { Navigation, CommonModal },
  props: {},
  data() {
    return {
      localedataNode: { emptyText: <Empty text="暂无验证人节点" /> },
      localeagueChain: { emptyText: <Empty text="暂无联盟链节点" /> },
      pagination: {
        //分页数据
        current: 1,
        pageSize: 10,
        totalCount: 0,
      },
      labelCol: { span: 4 },
      wrapperCol: { span: 20 },
      labelColALL: { span: 5 },
      wrapperColALL: { span: 11 },
      CommonModalValue: {
        value: "",
      },
      paginationtwo: {
        pageSize: 4, // 默认每页显示数量
        hideOnSinglePage: true,
      },
      form: {
        name: "",
        nodeAddress: undefined,
        nodeId: "",
        isAdmin: false,
        nodeAddressArray: [],
      },
      // 基础信息
      basicInformationList: [
        { label: "链名", value: "", key: "groupCode" },
        { label: "联盟链名称", value: "", key: "groupName" },
        { label: "创建时间", value: "", key: "createTime" },
        { label: "管理员节点数量", value: "", key: "adminNodeCount" },
        { label: "节点总数", value: "", key: "nodeCount" },
        { label: "燃料总量", value: "", key: "quota" },
        { label: "通证精度", value: "", key: "decimals" },
      ],
      //  公示配置
      consensusList: [
        { label: "共识机制", value: "", key: "consensus" },
        { label: "出块间隔", value: "", key: "period" },
        { label: "每个区块最大大小", value: "", key: "maxBlockSize" },
        { label: "出块奖励", value: "", key: "award" },
        {
          label: "出块奖励递减策略",
          value: "height_gap[10512000];ratio[1.1]",
          key: "null",
        },
        { label: "交易模式", value: "", key: "nofee" },
        { label: "转账手续费", value: "", key: "transferFee" },
        { label: "系统合约调用手续费", value: "", key: "contractFee" },
        {
          label: "gas费资源消耗比例",
          value: "cpu_rate[1000] ;mem_rate[1000000];disk_rate[1];xfee_rate[1]",
          key: "null",
        },
      ],
      leagueChainNodes: [
        {
          title: "节点地址",
          dataIndex: "nodeAddress",
          key: "1",
          scopedSlots: { customRender: "nodeAddress" },
          width: "32%",
        },
        {
          title: "IP地址",
          dataIndex: "serverIp",
          key: "2",
          className: "column-flex",
          scopedSlots: { customRender: "serverIp" },
          width: "18%",
        },
        {
          title: "备注",
          dataIndex: "remark",
          className: "column-flex",

          scopedSlots: { customRender: "remark" },
          key: "3",
          width: "20%",
        },
        {
          title: "运营方",
          dataIndex: "operator",
          key: "4",
          className: "column-flex",
          scopedSlots: { customRender: "operator" },
          ellipsis: true,
          width: "20%",
        },
        {
          title: "节点类型",
          dataIndex: "isAdmin",
          scopedSlots: { customRender: "isAdmin" },
          key: "5",
          ellipsis: true,
          width: "20%",
        },
        {
          title: "运行状态",
          dataIndex: "status",
          className: "column-flexl",

          key: "6",
          ellipsis: true,
          scopedSlots: { customRender: "status" },
          width: "20%",
        },
        {
          title: "操作",
          dataIndex: "operation",
          className: "column-center",
          key: "7",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "80px",
        },
      ],
      leagueChainNodes_data: [],
      //   验证人节点
      columnsNode: [
        {
          title: "节点地址",
          dataIndex: "nodeAddress",
          key: "nodeAddress",
          scopedSlots: { customRender: "nodeAddress" },
          width: "32%",
        },
        {
          title: "IP地址",
          dataIndex: "serverIp",
          key: "serverIp",
          className: "column-age",
          width: "18%",
        },
        {
          title: "备注",
          scopedSlots: { customRender: "remark" },
          key: "remark",
          className: "column-flex",
          width: "20%",
        },
        {
          title: "运营方",
          dataIndex: "operator",
          scopedSlots: { customRender: "operator" },
          key: "operator",
          className: "column-flex",
          ellipsis: true,
          width: "20%",
        },
        {
          title: "节点类型",
          dataIndex: "isAdmin",
          scopedSlots: { customRender: "isAdmin" },
          key: "isAdmin",
          width: "20%",
        },
        {
          title: "运行状态",
          dataIndex: "status",
          key: "status",
          className: "column-flexl",

          ellipsis: true,
          scopedSlots: { customRender: "status" },
          width: "20%",
        },
      ],
      type: true,
      //节点类型
      NodeType: [
        { title: "普通节点", val: "false", key: "1" },
        { title: "管理员节点", val: "true", key: "2" },
      ],
      dataNode: [],
      visible: false,
      isAddNode: false,
      value: "",
      isModifyCommon: false,
      isAllTit: "",
      isAllvalue: "",
      labelAll: "",
      TitleCompoents: "联盟链管理",
      routeidtype: false,
      OperationNode: [],
      id: "",
      haveAccessToNode: [],
      nodeAddressList: "",
      page_key: this.$route.name,
      emptyHeigth: 0,
      arr: [],
      OperationNodedef: "",
      new_list: [],
    };
  },
  methods: {
    // 分页组件
    onShowSizeChange(current, pageSize) {
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getChainGroupNodes();
    },
    callback(e) {
      console.log(e);
    },
    //执行操作节点的当前值
    handleChange(value) {
      this.form.adminNodeId = value.id;
    },
    //节点类型
    handNodeType(value) {
      this.form.isAdmin = value;
    },
    //移除节点的确认
    async confirm(e) {
      let groupCode = await this.getgroupCode();
      let params = {
        groupCode: groupCode,
        nodeId: e.id,
        adminNodeId: this.form.adminNodeId,
      };
      const totalPage = Math.ceil(
        (this.pagination.totalCount - 1) / this.pagination.pageSize
      ); // 总页数
      this.pagination.current =
        this.pagination.current > totalPage
          ? totalPage
          : this.pagination.current;
      this.pagination.current =
        this.pagination.current < 1 ? 1 : this.pagination.current;
      let res = await chainGroup_subNode(params);
      if (res.data.code == 200) {
        this.getChainGroupNodes(groupCode);
        this.$message.success("移除成功");
        this.getinit();
      } else {
        this.$message.error(res.data.msg);
      }
    },
    getenter(e) {
      this.arr = e.target.value.replace(/\n/g, ",");
    },
    //tag的移除
    async log(e) {
      this.form.nodeAddressArray.map((item, index) => {
        if (e == item) {
          this.form.nodeAddressArray.splice(index, 1);
        }
      });
    },
    cancel(e) {
      this.$message.error("已取消");
    },
    // 添加节点
    async getAddNode() {
      this.form.nodeAddressArray = [];
      this.getchainNode_listUsingNodesByGroupCode();
      this.getchainNode_listUnusedNodesByGroupCode();
      this.visible = true;
    },
    // 已获取节点
    async getchainNode_listUsingNodesByGroupCode() {
      let groupCode = await this.getgroupCode();
      let res = await chainNode_listUsingNodesByGroupCode({
        groupCode: groupCode,
      });
      this.haveAccessToNode = [];
    },

    // 未获取节点地址
    async getchainNode_listUnusedNodesByGroupCode() {
      let groupCode = await this.getgroupCode();
      let noderes = await chainNode_listUnusedNodesByGroupCode({
        groupCode: groupCode,
      });
      this.nodeAddressList = noderes.data.data;
    },
    //添加节点
    hideModalAdd() {
      if (!this.form.nodeId) {
        this.$message.destroy();
        this.$message.warning("节点地址不能为空");
        return;
      }
      this.form.isAdmin = this.form.isAdmin;
      if (this.form.nodeAddressArray.length == 0) {
        this.form.nodeAddressArray.push(this.form.nodeId);
        this.form.nodeId = null;
      } else {
        for (var i = 0; i < this.form.nodeAddressArray.length; i++) {
          //如果返回结果为-1（<0）证明新数组this.form.nodeAddressArra中没有这个元素，则把元素添加到新数组中
          if (this.form.nodeAddressArray.indexOf(this.form.nodeId) < 0) {
            this.form.nodeAddressArray.push(this.form.nodeId);
            this.form.nodeId = null;
            return;
          }
        }
        this.form.nodeId=null
        this.$message.warning("请勿重复添加");
      }
    },
    // 添加节点的确定
    async hideModal() {
      if (this.form.nodeAddressArray.length <= 0) {
        this.$message.destroy();
        this.$message.warning("节点地址不能为空");
        return;
      }
      this.form.groupCode = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : getSessionStorage("groupCodeAll");
      this.visible = false;
      let res = await chainGroup_batchAddNode(this.form, "application/json");
      if (res.data.code == 200) {
        this.$message.success("添加成功");
        this.form.nodeAddressArray = [];
        this.getinit();
      } else {
        this.$message.warning(res.data.msg);
      }
    },
    getisAddNode() {
      var strs = new Array(); //定义一数组
      strs = this.arr.split(","); //字符分割
      let r = strs.filter((item) => {
        return item.length > 0;
      });
      this.form.nodeAddressArray = [...this.form.nodeAddressArray, ...r];
      this.form.nodeAddressArray =[...new Set(this.form.nodeAddressArray)]
      this.value = "";
      this.isAddNode = false;
    },
    // 修改运营方
    getOperator(item) {
      let params = {
        RemarkTitle: "节点运营方",
        label: "节点运营方名称",
        value: item.operator,
        id: item.id,
        type: "Operator",
        antCol: 6,
      };
      this.CommonModalValue = params;
      this.isModifyCommon = true;
    },
    //修改ip地址
    getserverIp(item) {
      let params = {
        RemarkTitle: "修改Ip地址",
        label: "Ip地址",
        value: item.serverIp,
        id: item.id,
        type: "serverIp",
        maxlength: 15,
        antCol: 3,
      };
      this.CommonModalValue = params;
      this.isModifyCommon = true;
    },
    getBatchAdd() {
      this.isAddNode = true;
    },
    // 修改联盟链名称
    getModifyName(item) {
      let params = {
        RemarkTitle: "修改联盟链名称",
        label: "联盟链名称",
        value: item.value,
        type: "ModifyName",
      };

      this.isModifyCommon = true;
      this.CommonModalValue = params;
    },
    //修改备注
    getRemark(item) {
      let params = {
        RemarkTitle: "修改备注",
        label: "备注",
        value: item.remark,
        id: item.id,
        type: "Remark",
        antCol: 2,
      };

      this.CommonModalValue = params;
      this.isModifyCommon = true;
    },
    //获取联盟链
    getgroupCode() {
      let groupCode = getSessionStorage("groupCode")
        ? getSessionStorage("groupCode")
        : this.$route.query.id
        ? this.$route.query.id
        : getSessionStorage("groupCodeAll")
        ? getSessionStorage("groupCodeAll")
        : "";
      return groupCode;
    },
    //弹框的确定
    async handleOk(val) {
      let groupCode = await this.getgroupCode();
      // 修改联盟链
      if (val.type == "ModifyName") {
        let par = { groupCode: groupCode, name: val.value };
        let res = await chainGroup_updateName(par);
        if (res.data.code == 200) {
          await chainGroup_all();
          this.getinit();
          this.$message.success("修改成功");
        }
      } else if (val.type == "Operator") {
        //修改运营商
        let par = { id: val.id, operator: val.value };
        let res = await chainNode_updateOperatorById(par);
        if (res.data.code == 200) {
          this.$message.success("修改成功");
          this.getChainGroupNodes();
        }
      } else if (val.type == "Remark") {
        //修改运营商
        let par = { id: val.id, remark: val.value };
        let res = await chainNode_updateRemarkById(par);
        if (res.data.code == 200) {
          this.$message.success("修改成功");
          this.getinit();
        }
      } else if (val.type == "serverIp") {
        this.$store.commit("showloadding", true);
        console.log(this.$store.state);
        // 修改ip地址
        let par = { id: val.id, ip: val.value };
        let res = await chainNode_updateIp(par);
        this.$store.commit("showloadding", false);
        if (res.data.code == 200) {
          this.$message.success("修改成功");
          this.getChainGroupNodes();
        } else {
          this.$message.warning(res.data.msg);
        }
      }
    },
    //获取联盟链列表
    async getChainGroupNodes() {
      let groupCode = await this.getgroupCode();
      let param = {
        pageNum: this.pagination.current,
        pageSize: this.pagination.pageSize,
        groupCode: groupCode,
      };
      let res = await chainGroup_nodes(param);
      this.leagueChainNodes_data = res.data.data.rows;
      this.pagination.totalCount = Number(res.data.data.total);
    },
    //验证人节点列表
    async getchainNode_listVerifyNodesByGroupCode() {
      let groupCode = await this.getgroupCode();
      let res = await chainNode_listVerifyNodesByGroupCode({
        groupCode: groupCode,
      });
      this.dataNode = res.data.data;
    },
    //操作执行节点
    async getchainNodeListAdminNodesByGroupCode() {
      let groupCode = await this.getgroupCode();
      let res = await chainNode_listAdminNodesByGroupCode({
        groupCode: groupCode,
      });
      if (res.data.data.length > 0) {
        this.OperationNodedef =
          res.data.data[0].nodeAddress + `(` + res.data.data[0].nodeName + `)`;
      }
      this.form.adminNodeId = res.data.data[0].id;
      this.OperationNode = res.data.data;
      this.OperationNode = [...this.OperationNode];
    },
    //基础信息 共识配置
    async getChainGroupDetail() {
      let groupCode = await this.getgroupCode();
      let res = await chainGroup_detail({
        groupCode: groupCode,
      });
      //基础信息
      this.basicInformationList.forEach((i, v) => {
        for (let key in res.data.data) {
          this.type = false;
          if (key === i.key) {
            i.value = res.data.data[key];
          }
        }
      });
      this.CommonModalValue.value = this.basicInformationList[1].value;
      // 共识配置
      this.consensusList.forEach((i, v) => {
        for (let key in res.data.data) {
          if (key === i.key) {
            i.value = res.data.data[key];
          }
        }
      });

      if (this.consensusList[5].value == 0) {
        let arr = this.consensusList.slice(0, 6);
        let arr2 = this.consensusList.slice(0, 6);
        let arr3 = arr.slice(0, 3);
        let arr4 = arr2.slice(5, 6);
        this.new_list = [...arr3, ...arr4];
      } else {
        this.new_list = this.consensusList;
      }
    },
    getinit() {
      this.getchainNodeListAdminNodesByGroupCode();
      this.getChainGroupNodes();
      this.getChainGroupDetail();
      this.getchainNode_listVerifyNodesByGroupCode();
    },
  },
  watch: {
    $route: {
      immediate: true,
      deep: true,
      handler: function (val, oldVal) {
        if (val) {
          this.getinit();
        }
        if (val.query.id) {
          this.routeidtype = true;
        } else {
          this.routeidtype = false;
        }
      },
    },
    getName() {
      this.getinit();
    },
  },
  computed: {
    getName() {
      return this.$store.state.name;
    },
  },

  mounted() {
    this.setitem_event.add({ key: this.page_key, func: this.getinit });
    this.emptyHeigth = document.body.clientHeight - 150;
  },
  beforeDestroy() {
    this.setitem_event.del(this.page_key);
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-descriptions-item-label {
  font-size: 12px !important;
}
::v-deep .ant-descriptions-item-content {
  font-size: 12px !important;
}
::v-deep .ant-form-item {
  margin-bottom: 16px;
}
.nav_title {
  height: 110px;
  background: $color-primary;
  margin: 3px 0 0 3px;
  padding: 15px 0 0 16px;
  span {
    font-size: $size-bodyThe;
    color: $color-info;
  }
  .tit-vale {
    margin-top: 10px;
    font-size: 16px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(0, 0, 0, 0.85);
  }
}
.balanceinChain {
  background: $color-primary;
  margin: 24px;
  border-radius: 2px;
  .node {
    line-height: 60px;
    border-bottom: 1px solid $color-divider;
    text-align: right;
  }
  .mainBody {
    margin: 24px;
  }
}
</style>