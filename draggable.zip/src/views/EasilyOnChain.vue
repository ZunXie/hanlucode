<template>
  <div class="wrapper">
    <router-view v-if="route_key != 'easilyOnChain'"></router-view>
    <div v-else>
      <div class="navWrapper">
        <div class="navWrapper__title">轻松上链</div>
        <div class="navWrapper__center">
          集成数据上链、哈希上链、NFT铸造、数据验真、链上数据处理与查询、私钥托管等区块链中间服务，提供现成的智能合约，与中间服务无缝对接。开发者只需要直接通过API、SDK等调用中间服务即可实现数据上链、哈希上链等需求，快速打通业务系统和区块链体系的交互通道，有效降低开发成本和学习成本。
          <img src="@/img/cochain_illustration@2x.png" alt="" />
        </div>
      </div>
      <div class="easilyCenter">
        <div @click="getBasis('basis')" class="easilyCenter__all">
          <div class="easilyCenter__all__top">
            <img src="../img/cochain_cochain.png" alt="" />
            <div>
              <div class="easilyCenter__all__top__tit">基础接口服务</div>
              <div class="easilyCenter__all__top__bottm">
                集成数据上链、哈希上链、字数测试…
              </div>
            </div>
          </div>
          <div class="easilyCenter__bottom">进入服务</div>
        </div>
        <div @click="getBasis('privateKeyEscrow')" class="easilyCenter__all">
          <div class="easilyCenter__all__top">
            <img src="../img/cochain_cochain.png" alt="" />
            <div>
              <div class="easilyCenter__all__top__tit">私钥托管服务</div>
              <div class="easilyCenter__all__top__bottm">
                集成数据上链、哈希上链、NFT铸造
              </div>
            </div>
          </div>
          <div class="easilyCenter__bottom">进入服务</div>
        </div>
        <div class="easilyCenter__all" @click="getBasis('dataOnChain')">
          <div class="easilyCenter__all__top">
            <img src="../img/cochain_cochain.png" alt="" />
            <div>
              <div class="easilyCenter__all__top__tit">数据上链服务</div>
              <div class="easilyCenter__all__top__bottm">
                集成数据上链、哈希上链、NFT铸造
              </div>
            </div>
          </div>
          <div class="easilyCenter__bottom">进入服务</div>
        </div>
        <div class="easilyCenter__all" @click="getBasis('nftService')" >
          <div class="easilyCenter__all__top">
            <img src="../img/cochain_cochain.png" alt="" />
            <div>
              <div class="easilyCenter__all__top__tit">NFT服务</div>
              <div class="easilyCenter__all__top__bottm">
                集成数据上链、哈希上链、NFT铸造
              </div>
            </div>
          </div>
          <div class="easilyCenter__bottom">进入服务</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      route_key: "",
      nav_center:
        "集成数据上链、哈希上链、NFT铸造、数据验真、链上数据处理与查询、私钥托管等区块链中间服务，提供现成的智能合约，与中间服务无缝对接。开发者只需要直接通过API、SDK等调用中间服务即可实现数据上链、哈希上链等需求，快速打通业务系统和区块链体系的交互通道，有效降低开发成本和学习成本。",
    };
  },
  methods: {
    getBasis(route_key) {
      this.$router.push({
        name: route_key,
      });
    },
  },
  watch: {
    $route: {
      immediate: true,
      deep: true,
      handler: function (val, oldVal) {
        this.route_key = val.name;
      },
    },
  },
};
</script>
<style lang="scss" scoped>
@include b(navWrapper) {
  padding: 20px 64px 20px 24px;
  background: #ffffff;
  @include e(title) {
    font-size: 16px;
    color: rgba(0, 0, 0, 0.85);
  }
  @include e(center) {
    @include box-center;
    padding: 0px;
    font-weight: 400;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.65);
    line-height: 22px;
    img {
      width: 80px;
      height: 80px;
      margin-left: 160px;
    }
  }
}
@include b(easilyCenter) {
  margin: 24px 24px 18px 24px;
  @include grid(
    $display: flex,
    $flex-direction: null,
    $flex-wrap: wrap,
    $flex-flow: null,
    $justify-content: flex-start,
    $align-items: null,
    $align-content: flex-start,
    $gutter: null,
    $grid-type: skeleton
  );
  @include e(all) {
    background: #fff;
    box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.09);
    width: 330px;
    margin: 0 16px 16px 0;
    @include e(top) {
      padding: 24px;
      @include box-center;

      img {
        margin-right: 16px;
      }
      @include e(bottm) {
        font-size: 12px;
        color: rgba(0, 0, 0, 0.65);
        overflow: hidden;
      }
      @include e(tit) {
        margin-bottom: 4px;
        font-weight: 500;
        font-size: 16px;
        color: rgba(0, 0, 0, 0.85);
      }
    }
    :hover {
      cursor: pointer;
    }
  }

  @include e(bottom) {
    @include box-center;
    height: 40px;
    background: #f7f7f7;
    border-top: 1px solid #e9e9e9;
    border-radius: 0 0 2px 2px;
  }
}
</style>