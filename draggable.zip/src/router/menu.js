let menus = [
  {
    icon: 'home',
    name: '首页',
    path: '/home',
    key: 'home',
    component: () => import('../views/Home.vue'),
  },
  {
    icon: 'deployment-unit',
    name: '联盟链管理',
    key: 'LeagueChain',
    component: () => import('../views/LeagueChain.vue'),
  },
  {
    icon: 'deployment-unit',
    type: 'icon',
    name: '轻松上链',
    key: 'easilyOnChain',
    component: () => import('../views/EasilyOnChain.vue'),
    children: [
      {
        icon: 'question',
        name: '区块详情',
        key: 'basis',
        hideen: true,
        component: () => import('../views/EasilyOnChain/Basis.vue'),
      },
      {
        icon: 'question',
        name: '私钥托管',
        key: 'privateKeyEscrow',
        hideen: true,
        component: () => import('../views/EasilyOnChain/privateKeyEscrow.vue'),
      },
      {
        icon: 'question',
        name: '数据上链',
        key: 'dataOnChain',
        hideen: true,
        component: () => import('../views/EasilyOnChain/DataOnChain.vue'),
      },
      {
        icon: 'question',
        name: 'NFT',
        key: 'nftService',
        hideen: true,
        component: () => import('../views/EasilyOnChain/NFTService.vue'),
      },
    ],
  },
  {
    icon: 'audit',
    name: '智能合约管理',
    key: 'contact',
    component: () => import('../views/Contact/Index.vue'),
    children: [
      {
        icon: 'question',
        name: '智能合约',
        key: 'igentContract',
        component: () => import('../views/Contact/IigentContract.vue'),
      },
      {
        icon: 'question',
        name: '智能合约',
        key: 'managements',
        hideen: true,
        component: () => import('../views/Contact/Managements.vue'),
      },
      // {
      //     icon: 'question', name: '区块详情', key: 'blockDetails', hideen: true, component: () => import('../views/Browser/BlockDetails.vue'),
      // },
      {
        icon: 'question',
        name: '创建合约',
        key: 'createContract',
        hideen: true,
        component: () => import('../views/Browser/CreateContract.vue'),
      },
      {
        icon: 'minus',
        name: '合约模板',
        key: 'contractTemplate',
        component: () => import('../views/Contact/ContractTemplate.vue'),
      },
    ],
  },

  {
    icon: 'global',
    name: '浏览器',
    key: 'browser',
    component: () => import('../views/Browser.vue'),
    children: [
      {
        icon: 'question',
        name: '区块详情',
        key: 'blockDetails',
        hideen: true,
        component: () => import('../views/Browser/BlockDetails.vue'),
      },
    ],
  },
  {
    icon: 'safety-certificate',
    name: '网络与安全',
    key: 'network',
    component: () => import('../views/Network/Index.vue'),
    children: [
      {
        icon: 'question',
        name: '监控中心',
        key: 'monitorCenter',
        component: () => import('../views/Network/MonitorCenter.vue'),
      },
      {
        icon: 'minus',
        name: '用户日志',
        key: 'userlog',
        component: () => import('../views/Network/Userlog.vue'),
      },
    ],
  },
  {
    icon: 'read',
    name: '服务与支持',
    key: 'help',
    component: () => import('../views/Help/Index.vue'),
    children: [
      {
        icon: 'exclamation',
        name: '开发者文档',
        key: 'developerApi',
        component: () => import('../views/Help/DeveloperApi.vue'),
      },
      {
        icon: 'exclamation',
        name: '开发者文档',
        hideen: true,
        key: 'documentDetails',
        component: () => import('../views/Help/DocumentDetails.vue'),
      },
    ],
  },
  // {
  //     icon: 'home',
  //     name: '表格',
  //     path: '/mTable',
  //     key: 'mTable',
  //     component: () => import('../components/mTable/call.vue')
  // },
]

export default menus
