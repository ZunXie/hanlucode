<template>
  <div class="wrapper">
    <div
      class="status"
      :style="{
        backgroundColor:
          typeColor == 'Y'
            ? '#52C41A'
            : typeColor == 'S'
            ? '#007AFF'
            : typeColor == 'W'
            ? '#FAAD14 '
            : '#bbbbbb',
      }"
    ></div>
  </div>
</template>

<script>
export default {
  props: {
    //缺省文案
    typeColor: {
      type: String,
      default: "",
    },
  },
};
</script>
<style lang="scss" scoped>
.status {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 7px;
}
</style>