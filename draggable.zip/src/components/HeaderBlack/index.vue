<template>
  <a-layout-header class="_header">
    <div class="logo">
      <a-icon @click="goback" style="fontsize: 20px" type="left" />
      <div><SetUpThe /></div>
    </div>
  </a-layout-header>
</template>

<script>
import SetUpThe from "../SetUpThe";
import { goToBrowser } from "@/mixins/goToBrowser";

export default {
  components: { SetUpThe },
  mixins: [goToBrowser],
};
</script>
<style lang="scss" scoped>
@include b(_header) {
  background: #292b33 !important;
  height: 48px;
  color: rgba(255, 255, 255, 0.85);
  padding-left: 25px;
}
@include b(ant-layout-header) {
  line-height: 24px;
  box-shadow: 0px 1px 4px 0px #676872;
  z-index: 1000;
}
.logo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 54px;
}
</style>