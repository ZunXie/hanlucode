<template>
  <div class="InterfaceDocument">
    <div class="InterfaceDocument__title">上链状态查询</div>
    <div class="InterfaceDocument__descriptions">
      <a-descriptions layout="vertical">
        <a-descriptions-item label="接口说明">
          用于查询某个交易是否已经上链
        </a-descriptions-item>
        <a-descriptions-item label="接口地址"
          >https：//baas.chaojigongshi.com/siyuetuoguan/de
        </a-descriptions-item>
      </a-descriptions>
    </div>
    <div class="InterfaceDocument__margin">
      <div class="InterfaceDocument__margin__title">请求参数:</div>
      <div class="InterfaceDocument__margin__table">
        <a-table
          bordered
          :pagination="false"
          :columns="columns_parameter"
          :data-source="data_parameter"
          :rowKey="(record) => record.name"
        >
        </a-table>
      </div>
    </div>
    <div class="InterfaceDocument__margin">
      <div class="InterfaceDocument__margin__title">响应参数:</div>
      <div class="InterfaceDocument__margin__table">
        <a-table
          bordered
          :pagination="false"
          :columns="columns_Response"
          :data-source="data_Response"
          :rowKey="(record) => record.groupCode"
          :expanded-row-keys.sync="expandedRowKeys"
        >
        </a-table>
      </div>
    </div>
    <!-- <div class="InterfaceDocument__margin">
      <div class="InterfaceDocument__margin__title">请求示例</div>
      <div class="InterfaceDocument__margin__table">
        <div style="position: relative">
          <a-tabs type="card">
            <a-tab-pane
              v-for="item in SampleList"
              :key="item.id"
              :tab="item.language"
            >
              <CopyComp
                style="position: absolute; right: -13px; top: 0px; z-index: 999"
                :tit="item.sourceCode"
                show="link"
                :valuetext="item.sourceCode"
              />
              <div>{{ item.info }}</div>
            </a-tab-pane>
          </a-tabs>
        </div>
      </div>
    </div> -->
    <div class="InterfaceDocument__margin">
      <div class="InterfaceDocument__margin__title">错误码解释:</div>
      <div class="InterfaceDocument__margin__table">
        <a-table
          bordered
          :pagination="false"
          :columns="columns_Error"
          :data-source="data_Error"
          :rowKey="(record) => record.groupCode"
        >
        </a-table>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  components: {},
  props:['data_parameter'],
  data() {
    return {
      expandedRowKeys: [],
      columns_parameter: [
        {
          title: "名称",
          dataIndex: "name",
          key: "name",
          width: "20%",
        },
        {
          title: "类型",
          dataIndex: "type",
          key: "type",
          width: "20%",
        },
        {
          title: "必须",
          dataIndex: "required",
          key: "required",
          width: "15%",
        },
        {
          title: "描述",
          dataIndex: "description",
          scopedSlots: { customRender: "description", ellipsisSlot: true },
          key: "description",
          ellipsis: true,
        },
      ],
      columns_Response: [
        {
          title: "名称",
          dataIndex: "groupCode",
          key: "groupCode",
          width: "20%",
        },
        {
          title: "类型",
          dataIndex: "groupName",
          key: "groupName",
          width: "20%",
        },

        {
          title: "描述",
          dataIndex: "status",
          scopedSlots: { customRender: "status", ellipsisSlot: true },
          key: "status",
          ellipsis: true,
        },
      ],
      data_Response: [
        {
          groupCode: "1",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
        {
          groupCode: "2",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
        {
          groupCode: "4",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
        {
          groupCode: "3",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
      ],
      columns_Error: [
        {
          title: "错误码",
          dataIndex: "groupCode",
          key: "groupCode",
          width: "20%",
        },
        {
          title: "错误消息",
          dataIndex: "groupName",
          key: "groupName",
          width: "20%",
        },
        {
          title: "解决方案",
          dataIndex: "status",
          scopedSlots: { customRender: "status", ellipsisSlot: true },
          key: "status",
          ellipsis: true,
        },
      ],
      data_Error: [
        {
          groupCode: "1",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
        {
          groupCode: "2",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
      ],
      SampleList: [
        {
          id: 1,
          info: "# Lorem ipsum dolor sit amet, consecteturLorem ipsum dolor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consecteturLorem ipsum dor sit amet, consectetuLorem ipsum dolor sit amet, consectetuLorem ipsum dolor sit amet, consectetuLorem ipsum dolor sit amet, consectetuLorem ipsum dolor sit amet, consectetuLorem ipsum dolor sit amet, consectetuLorem ipsum dolor sit amet, consectetu adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin)",
          language: "Java",
          sourceCode: "122222",
        },
        {
          id: 2,
          info: "# Lorem ipsum dolor sit amet,m dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin)",
          language: "Js",
          sourceCode: "122222",
        },
        {
          id: 3,
          info: "# Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget odio. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin)",
          language: "go",
          sourceCode: "122222",
        },
      ],
    };
  },
  created() {
    // this.getinit();
  },
  methods: {
  
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-descriptions-item {
  padding-bottom: 4px !important;
  color: rgba(0, 0, 0, 0.65);
}
::v-deep .ant-descriptions-item > span {
  font-size: 12px;
}
@include b(InterfaceDocument) {
  @include e(title) {
    font-weight: 500;
    font-size: 14px;
    margin-top: 16px;
    color: rgba(0, 0, 0, 0.85);
  }
  @include e(descriptions) {
    margin-top: 16px;
  }
  @include e(margin) {
    margin-top: 24px;
    @include e(title) {
      font-weight: 400;
      font-size: 12px;
      color: rgba(0, 0, 0, 0.85);
      margin-bottom: 8px;
    }
  }
}
</style>