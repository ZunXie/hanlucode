<template>
  <div class="BasicServices">
    <div class="BasicServices__one">一、服务说明：</div>
    <div class="BasicServices__four">
      该接口用于校验交易是否已经被链所确认，保证数据已经上链。
    </div>
    <div class="BasicServices__one">二、准备工作：</div>
    <div class="BasicServices__two">
      2.1 确保Baas存在对应链可使用的节点调用链接口
    </div>
    <div class="BasicServices__four">
      调用需要至少一个运行中的节点存在于系统中，如图所示信息，该节点需要满足：1.正在运行中的状态、2.通过部署或者添加功能而创建的、3.节点加入了对应链的群组中（主链没有这点要求）
    </div>
    <div class="BasicServices__img">
      <img src="../../img/DocumentationImg/截图.png" alt="" />
    </div>
    <div class="BasicServices__one">三、服务调用说明：</div>
    <div class="BasicServices__two">3.1 接口访问</div>
    <div class="BasicServices__four">
      当前该服务为局域网内部服务，服务部署时会设定禁止公网ip访问，应经由后端服务对用户进行授权管理，再进行代理调用
    </div>
    <div class="BasicServices__two">3.2 hash长度基本校验</div>
    <div class="BasicServices__four">
      交易hash长度固定为64位长度，建议请求前进行基本的长度校验，避免无意义的请求
    </div>
    <div class="BasicServices__one">四、服务调用发生未知异常：</div>
    <div class="BasicServices__two">4.1 服务器繁忙：</div>
    <div class="BasicServices__three">4.1.1 现象</div>
    <div class="BasicServices__four">
      接口返回（code=500，message="服务器繁忙，请稍后重试"）
    </div>
    <div class="BasicServices__three">4.1.2 处理方案：</div>
    <div class="BasicServices__four">
      尝试重试请求，如果仍然返回服务器繁忙，请记录该异常交易，并联系相关人员走人工处理流程。
    </div>
  </div>
</template>

