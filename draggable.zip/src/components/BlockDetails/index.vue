<template>
  <div class="wrapper">
    <div class="toview-rg">
      <span class="transactionDetails">交易详情</span>
      <a-descriptions :column="1">
        <a-descriptions-item
          v-for="(item, index) in transactionDetails"
          :key="index"
          :label="item.label"
        >
          <span v-if="item.key == 'transferAmount' || item.key == 'fee'">
            {{ item.value }}
          </span>
          <span v-else>{{ item.value }} </span>
          <a-button type="link">
            <CopyComp
              v-if="item.icon"
              :tit="item.key"
              :valuetext="item.value"
            />
          </a-button>
        </a-descriptions-item>
      </a-descriptions>
      <div class="formatData">
        <json-viewer
          :value="jsonData"
          :expand-depth="10"
          copyable
        ></json-viewer>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["detailvalue"],
  data() {
    return {
      detail_list: [],
      jsonData: [],
      // 交易详情
      transactionDetails: [
        {
          label: "交易哈希",
          value:
            "0x0f5bde8969a820680b3e6d3be75cb794bcc1d8a2f04434a5f7afe40f56eb15ee",
          icon: "switcher",
          key: "txId",
        },
        { label: "区块", value: "12269748", key: "blockHeight" },
        { label: "时间戳", value: "1618822452750780000", key: "timestamp" },
        {
          label: "验证人",
          value: "0x3a17ebf1c42f38420f464b23a10c4d4640a96246",
          icon: "switcher",
          key: "proposer",
        },
        { label: "交易额", value: "0.00000000SUC", key: "transferAmount" },
        { label: "交易手续费", value: "0.01SUC", key: "fee" },
      ],
    };
  },
  mounted() {
    console.log(111111111111);
    let arr = { ...this.detailvalue[0] };
    //交易详情
    for (let key in arr) {
      this.transactionDetails.map((i, v) => {
        if (key == i.key) {
          i.value = arr[key];
        }
      });
    }
    //原始数据的展示
    this.jsonData = this.detailvalue;
  },
};
</script>
<style lang="scss" scoped>
.toview-rg {
  margin-top: 24px;
  .transactionDetails {
    display: inline-block;
    font-size: 16px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.85);
    margin-bottom: 17px;
  }
  .transactionDetails:before {
    content: "";
    border-left: 4px solid #007aff;
    margin-right: 16px;
  }
  .formatData {
    background: #232733;
    border-radius: 2px;
    color: $color-primary;
    padding: 24px;
  }
}
</style>