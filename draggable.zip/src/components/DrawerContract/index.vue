<template>
  <div>
    <a-drawer
      :title="value.ctName"
      placement="right"
      :closable="true"
      :width="680"
      :visible="visible"
      :after-visible-change="afterVisibleChange"
      @close="onClose"
    >
      <div class="ctm_info">
        <a-descriptions
          style="word-break: break-all; word-wrap: break-word"
          :column="1"
        >
          <a-descriptions-item label="语言">
            {{ introduce.ctType }}
          </a-descriptions-item>

          <a-descriptions-item label="介绍">
            {{ introduce.ctIntro }}
          </a-descriptions-item>
        </a-descriptions>
      </div>

      <!-- 借口描述 -->
      <div class="fontSize14 excuse">接口描述</div>
      <a-table
        size="middle"
        bordered
        :pagination="false"
        :columns="columns_leagueChain"
        :data-source="data_leagueChain"
      >
        <template slot="nodeName" slot-scope="text, record">
          {{ JSON.stringify(record.ctFuncInputs) }}
        </template>
      </a-table>

      <!--合约调用示例  -->
      <div class="fontSize14 call">合约调用示例</div>
      <div style="position: relative" class="fontSize14Tabs">
        <a-tabs type="card" @change="handleCallback">
          <a-tab-pane
            v-for="(item, index) in SampleList"
            :key="index + 1"
            :tab="item.language"
          >
          
            <CopyComp
              style="position: absolute; right: -13px; top: 0px; z-index: 999"
              :tit="item.sourceCode"
              show="link"
              :valuetext="item.sourceCode"
            />
            <MarkdownIt :value="item.info" />
          </a-tab-pane>
        </a-tabs>
      </div>
      <div class="fontSize14Bottom">
        <a-space>
          <a-button @click="onClose">返回</a-button>
          <a-button type="primary" @click="getUseTemplate"> 使用模板 </a-button>
        </a-space>
      </div>
    </a-drawer>
  </div>
</template>
<script>
import { ctm_info, ctm_getByCtTemplateId } from "@/utils/Contact";
import CodemirrorComp from "../CodemirrorComp";
import MarkdownIt from "../MarkdownIt";
export default {
  components: { CodemirrorComp },
  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isShow: {
      type: Boolean,
      default: false,
      required: true,
    },
    value: {
      type: Object,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      columns_leagueChain: [
        {
          title: "函数名",
          dataIndex: "ctFuncName",
          key: "ctFuncName",
          width: "18%",
        },

        {
          title: "参数",
          dataIndex: "ctFuncInputs",
          key: "ctFuncInputs",
          scopedSlots: { customRender: "ctFuncInputs" },
          width: "40%",
        },

        {
          title: "简介",
          dataIndex: "ctFuncDesc",
          key: "ctFuncDesc",
          width: "20%",
        },
      ],
      data_leagueChain: [],
      introduce: {},
      SampleList: [],
      Samplecopy: "",
    };
  },
  methods: {
    afterVisibleChange(val) {
      console.log("visible", val);
    },
    showDrawer() {
      this.visible = true;
    },
    onClose() {
      this.visible = false;
    },
    getCopy() {
      this.Samplecopy = !this.Samplecopy
        ? this.SampleList[0].info
        : this.Samplecopy;
      console.log(this.Samplecopy);
    },
    handleCallback(e) {
      this.Samplecopy = this.SampleList[e - 1].info;
    },
    //获取详情列表
    async getctm_info() {
      let res = await ctm_info({ ctId: this.value.id });
      this.introduce = res.data.data;
      this.data_leagueChain = res.data.data.funcs;
    },
    //获取合约调用示例
    async getctm_getByCtTemplateId() {
      let res = await ctm_getByCtTemplateId({ ctId: this.value.id });
      this.SampleList = res.data.data;
      this.Samplecopy = this.SampleList[0].info;
    },
    //使用模板
    getUseTemplate() {
      this.$router.push({
        path: "/createContract",
        query: { id: this.value.id },
      });
    },
  },
  computed: {
    visible: {
      get() {
        return this.isShow;
      },
      set(val) {
        this.$emit("update:isShow", val);
      },
    },
  },
  created() {
    this.getctm_info();
    this.getctm_getByCtTemplateId();
  },
};
</script>
<style lang="scss" >
.excuse {
  padding: 24px 0;
}
.call {
  margin: 40px 0 14px 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.fontSize14Bottom {
  height: 45px;
  line-height: 45px;
  text-align: end;
  padding-right: 30px;
  position: fixed;
  bottom: 0px;
  background: #ffffff;
  z-index: 1000;
  width: 665px;
  margin-left: -24px;
  border-top: 1px solid $Black-6;
}
.ctm_info {
  .ant-descriptions-item {
    display: flex;
    span:nth-child(1) {
      width: 50px;
    }
  }
}
</style>