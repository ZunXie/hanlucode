<template>
  <div>
    <a-drawer
      title="燃料账户"
      placement="right"
      :visible="visible"
      :width="480"
      :after-visible-change="afterVisibleChange"
      @close="onClose"
    >
      <p>账户地址</p>
      <div>
        <a-space style="font-size: 12px">
          {{ detailvalue.account
          }}<CopyComp
            show="iconCopy"
            :tit="detailvalue.account"
            :valuetext="detailvalue.account"
        /></a-space>
      </div>
      <div style="margin: 33px 0">
        <p>主网燃料余额</p>
        <a-descriptions :column="1">
          <a-descriptions-item label="总余额">
            {{ detailvalue.freeBalance + detailvalue.freezeBalance }}
          </a-descriptions-item>
          <a-descriptions-item label="可用余额">
            {{ detailvalue.freeBalance }}
          </a-descriptions-item>
        </a-descriptions>
      </div>

      <p>接收燃料</p>

      <div>
        <vue-qr
          style="width: 80px; height: 80px"
          ref="Qrcode"
          :text="text"
          qid="testQrId"
        ></vue-qr>
      </div>

      <div class="warmPrompt">
        <span>温馨提示:</span>
        <div>
          1、区块链上任何交易都会消耗链资源（如节点cpu、内存、磁盘等），如果有人恶意执行大量交易，那么将占用大量链资源，破坏链的稳定运行，为了避免此类攻击，保证主链能更稳定的运行，我们通过使用燃料来量化链上资源，每次执行交易时消耗对应量的燃料。
        </div>
        <div>
          2、在BaaS服务中，部署联盟链、添加/删除联盟链节点、修改节点类型等操作需要在主链上执行操作，因此需要消耗主链燃料，执行操作前请确保执行操作的账户燃料充足，否则可能导致操作失败。其中部署联盟链是通过BaaS燃料账户进行操作的；添加/删除联盟链节点、修改节点类型等是通过节点账户操作。
        </div>
        <div>
          3、联盟链内执行的交易和操作是不需要消耗主链燃料的；您可以在部署联盟链时自定义联盟链是否需要交易手续费。
        </div>
      </div>
    </a-drawer>
    <!-- <CommonModal
      v-if="isModifyCommon"
      :isModifyCommon.sync="isModifyCommon"
      :CommonModalValue="CommonModalValue"
      @handFormValue="handleOk"
    /> -->
  </div>
</template>
<script>
import { chainAccount_getMain } from "@/utils/home";
import VueQr from "vue-qr";

export default {
  components: { VueQr },

  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isFuelShow: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      detailvalue: {},
      text: "",
    };
  },
  methods: {
    afterVisibleChange(val) {
      console.log("visible", val);
    },
    showDrawer() {
      this.visible = true;
    },
    onClose() {
      this.visible = false;
    },
    async getchainAccount_getMain() {
      let res = await chainAccount_getMain();
      this.detailvalue = res.data.data;
      this.text = res.data.data.account;
    },
  },
  mounted() {
    this.getchainAccount_getMain();
  },
  computed: {
    visible: {
      get() {
        return this.isFuelShow;
      },
      set(val) {
        this.$emit("update:isFuelShow", val);
      },
    },
  },
};
</script>
<style lang="scss" scoped>
p {
  display: inline-block;
  font-size: 14px;
  font-family: PingFangSC-Medium, PingFang SC;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.85);
  margin-bottom: 17px;
}
p:before {
  content: "";
  border-left: 4px solid #007aff;
  margin-right: 16px;
}
.warmPrompt {
  font-size: $size-bodyThe;
  font-weight: 400;
  color: $Black-45;
  margin-top: 24px;
}
::v-deep .ant-drawer-body {
  padding: 26px 24px;
}
::v-deep .ant-descriptions-item > span {
  font-size: 12px;
}
::v-deep .ant-drawer-header{
  padding: 11px 16px;
  line-height: 44px;
}
::v-deep .ant-drawer-close {
  height: 44px;
  line-height: 44px;
}
::v-deep .anticon{
  font-size: 12px;
}
</style>