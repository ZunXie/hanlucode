<template>
  <div>
    <a-drawer
      title="交易详情"
      placement="right"
      :closable="true"
      :visible="visible"
      :width="940"
      @close="onClose"
    >
      <a-table
        bordered
        :columns="columns"
        :pagination="false"
        :data-source="detail_list"
        :rowKey="(record) => record.timestamp"
      >
        <!-- 标题 -->
        <span slot="blockHeight"
          >区块高度
          <a-tooltip>
            <template slot="title"> 当前区块内的交易数量 </template>
            <a-icon type="exclamation-circle" />
          </a-tooltip>
        </span>
        <!-- 内容 -->
        <template slot="txId" slot-scope="text, record">
          <span>
            {{ record.txId }}
          </span>
        </template>
        <template slot="proposer" slot-scope="text, record">
          <span>
            {{ record.proposer }}
          </span>
        </template>
        <template slot="blockId" slot-scope="text, record">
          <span>
            {{ record.blockId }}
          </span>
        </template>
        <template slot="timestamp" slot-scope="text, record">
          <span>
            {{ record.timestamp | format }}
          </span>
        </template>
      </a-table>

      <div class="toview-rg">
        <span class="transactionDetails">交易详情</span>
        <a-descriptions :column="1">
          <a-descriptions-item
            v-for="(item, index) in transactionDetails"
            :key="index"
            :label="item.label"
          >
            <span v-if="item.key == 'transferAmount' || item.key == 'fee'">
              {{ item.value }}
            </span>
            <span v-else>{{ item.value }} </span>
            <a-button type="link">
              <CopyComp
                v-if="item.icon"
                :tit="item.key"
                :valuetext="item.value"
              />
            </a-button>
          </a-descriptions-item>
        </a-descriptions>
        <div class="formatData">
          <json-viewer
            :value="jsonData"
            :expand-depth="10"
            copyable
          ></json-viewer>
        </div>
      </div>
    </a-drawer>
  </div>
</template>

<script>
import BlockDetails from "../BlockDetails";
export default {
  components: { BlockDetails },
  props: ["isTrawShow", "child_detailvalues"],
  data() {
    return {
      // 表格数据
      columns: [
        {
          dataIndex: "blockHeight",
          key: "blockHeight",
          slots: { title: "blockHeight" },
          className: "column-right",
          width: "11%",
        },
        {
          title: "区块哈希",
          key: "blockId",
          scopedSlots: { customRender: "blockId" },
          width: "35%",
        },
        {
          title: "验证人",
          scopedSlots: { customRender: "proposer" },
          key: "proposer",
          width: "23%",
        },
        {
          title: "提交时间",
          key: "timestamp",
          scopedSlots: { customRender: "timestamp" },
          width: "20%",
        },
      ],
      detail_list: [],
      jsonData: [],
      // 交易详情
      transactionDetails: [
        {
          label: "交易哈希",
          value:
            "0x0f5bde8969a820680b3e6d3be75cb794bcc1d8a2f04434a5f7afe40f56eb15ee",
          icon: "switcher",
          key: "txId",
        },
        { label: "区块", value: "12269748", key: "blockHeight" },
        { label: "时间戳", value: "1618822452750780000", key: "timestamp" },
        {
          label: "验证人",
          value: "0x3a17ebf1c42f38420f464b23a10c4d4640a96246",
          icon: "switcher",
          key: "proposer",
        },
        { label: "交易额", value: "0.00000000SUC", key: "transferAmount" },
        { label: "交易手续费", value: "0.01SUC", key: "fee" },
      ],
    };
  },
  methods: {
    showDrawer() {
      this.visible = true;
    },
    onClose() {
      this.visible = false;
    },
  },
  computed: {
    visible: {
      get() {
        return this.isTrawShow;
      },
      set(val) {
        this.$emit("update:isTrawShow", val);
      },
    },
  },
 watch: {
   'child_detailvalues': {
      immediate: true,
      deep: true,
      handler: function (val, oldVal) {
   this.detailvalues = val
    let arr = [this.detailvalues];
    //交易详情
    for (let key in this.detailvalues) {
      this.transactionDetails.map((i, v) => {
        if (key == i.key) {
          i.value = this.detailvalues[key];
        }
      });
    }
    //原始数据的展示
    this.jsonData = arr;
    //表格
    this.detail_list = arr.map((i, v) => {
      return {
        blockHeight: i.blockHeight,
        blockId: i.blockId,
        proposer: i.proposer,
        timestamp: i.timestamp,
      };
    });
      },
    },
  },
  mounted() {
    this.detailvalues = this.child_detailvalues
    let arr = [this.detailvalues];
    //交易详情
    for (let key in this.detailvalues) {
      this.transactionDetails.map((i, v) => {
        if (key == i.key) {
          i.value = this.detailvalues[key];
        }
      });
    }
    //原始数据的展示
    this.jsonData = arr;
    //表格
    this.detail_list = arr.map((i, v) => {
      return {
        blockHeight: i.blockHeight,
        blockId: i.blockId,
        proposer: i.proposer,
        timestamp: i.timestamp,
      };
    });
  },
};
</script>
<style lang="scss" scoped>
.toview-rg {
  margin-top: 24px;
  .transactionDetails {
    display: inline-block;
    font-size: 16px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 600;
    color: rgba(0, 0, 0, 0.85);
    margin-bottom: 17px;
  }
  .transactionDetails:before {
    content: "";
    border-left: 4px solid #007aff;
    margin-right: 16px;
  }
  .formatData {
    background: #232733;
    border-radius: 2px;
    color: $color-primary;
    padding: 24px;
  }
}
</style>
