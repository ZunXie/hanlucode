<template>
    <div class="Footer">
        
    </div>
</template>

<script>

export default {
    name: "Footer",
};
</script>
