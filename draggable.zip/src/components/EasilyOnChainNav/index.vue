<template>
  <div class="wrapper">
    <div @click="goback" class="wrapper__goback">
      <i style="font-size: 12px" class="iconfont icon-left"></i>返回
    </div>
    <div class="wrapper__title">{{ nav_title }}</div>
    <div v-html="nav_center" class="wrapper__center">
      <!-- {{ nav_center }} -->
    </div>
  </div>
</template>

<script>
import { goToBrowser } from "@/mixins/goToBrowser";
export default {
  mixins: [goToBrowser],
  props: ["nav_title", "nav_center"],
  data() {
    return {};
  },
};
</script>
<style lang="scss" scoped>
@include b(wrapper) {
  padding: 12px 64px 16px 24px;
  background: #ffffff;
  @include e(goback) {
    font-size: 12px;
  }
  :hover {
    cursor: pointer;
  }
  @include e(title) {
    font-size: 16px;
    color: rgba(0, 0, 0, 0.85);
    margin: 6px 0;
  }
  @include e(center) {
    @include box-center($justify: false, $align: center);
    padding: 0px;
    font-weight: 400;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.65);
    line-height: 22px;
  }
}
</style>