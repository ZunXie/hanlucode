
 <template>
  <div>
    <a-modal
      v-model="visiblemodal"
      ok-text="确定"
      cancel-text="取消"
      :title="CommonModalValue.RemarkTitle"
      @ok="handleOk"
    >
      <a-form-model
        :model="form"
        :label-col="labelCol"
        :wrapper-col="wrapperCol"
      >
        <a-form-model-item :label="CommonModalValue.label">
          <el-input
            :maxlength="maxlength"
            size="small"
            show-word-limit
            v-model="form.value"
          />
        </a-form-model-item>
      </a-form-model>
    </a-modal>
  </div>
</template>
<script>
export default {
  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isModifyCommon: {
      type: Boolean,
      default: false,
      required: true,
    },
    CommonModalValue: {
      type: Object,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      labelCol: { span: 6 },
      wrapperCol: { span: 14 },
      maxlength: 0,
      title: "",
      label: "",
      form: {
        value: "",
        type: "",
        id: "",
      },
    };
  },
  methods: {
    showModal() {
      this.visiblemodal = true;
    },
    handleOk(e) {
      this.$emit("handFormValue", this.form);
      this.visiblemodal = false;
    },
  },
  mounted() {
    this.maxlength = this.CommonModalValue.maxlength
      ? this.CommonModalValue.maxlength
      : 10;
      this.labelCol.span=this.CommonModalValue.antCol?this.CommonModalValue.antCol:4
    // this.label = this.CommonModalValue.label;
    // this.form = this.CommonModalValue;
    // this.form.remark = this.CommonModalValue.value;
    // this.form.type = this.CommonModalValue.type;
    // this.form.id = this.CommonModalValue.id;
    this.form = this.CommonModalValue;
  },
  computed: {
    visiblemodal: {
      get() {
        return this.isModifyCommon;
      },
      set(val) {
        this.$emit("update:isModifyCommon", val);
      },
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-modal-body{
  padding: 33px 24px;
} 
::v-deep .ant-form-item{
margin-bottom: 0px;
}
</style>
