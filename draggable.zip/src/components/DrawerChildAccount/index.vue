<template>
  <div>
    <a-drawer
      title="子账号管理"
      width="680"
      :visible="visible"
      @close="onClose"
      wrapClassName="web"
    >
      <div style="text-align: end; margin-bottom: 16px">
        <a-button icon="plus" @click="showChildrenDrawer">
          新增员工账号
        </a-button>
      </div>
      <a-table
        size="middle"
        :pagination="false"
        @change="handleTableChange"
        bordered
        :scroll="{ y: 620 }"
        :columns="columns"
        :data-source="data_list"
        :rowKey="(record) => record.id"
        id="box"
      >
        <template slot="roleName" slot-scope="text, record">
          <div @click="getroleName(record)">
            {{ record.remark }}<a-icon type="form" />
          </div>
        </template>
        <template slot="operation" slot-scope="text, record">
          {{ record.operation }}
          <a-space>
            <a @click="getPermissions(record)">设置权限</a>
            <a @click="getuser_delectUser(record)">删除账号</a>
          </a-space>
        </template>
      </a-table>
      <a-drawer
        :title="TwoDrawerTitle"
        width="480"
        :visible="childrenDrawer"
        @close="onChildrenDrawerClose"
        wrapClassName="twoDrawer"
      >
        <NewComponents v-if="TwoDrawerTitle == '新增员工账号'" />
        <RightsManagement v-else :PermissionsValue="PermissionsValue" />
      </a-drawer>
    </a-drawer>
    <!-- 修改名称ip备注节点运营放 -->

    <CommonModal
      v-if="isModifyCommon"
      :isModifyCommon.sync="isModifyCommon"
      :CommonModalValue="CommonModalValue"
      @handFormValue="handleOk"
    />
  </div>
</template>
<script>
import NewComponents from "./components/New";
import RightsManagement from "./components/RightsManagement";
import CommonModal from "@/components/CommonModal";

import {
  user_list,
  user_delectUser,
  user_creatUserd,
  user_saveGroupPower,
  user_saveRemark,
} from "@/utils/home";
export default {
  components: { NewComponents, RightsManagement, CommonModal },
  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isChildAccount: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  data() {
    return {
      pagination: {
        //分页数据
        current: 1,
        pageSize: 14,
        totalCount: 0,
      },
      childrenDrawer: false,
      TwoDrawerTitle: "",
      PermissionsValue: {},
      isModifyCommon: false,

      columns: [
        {
          title: "备注名",
          dataIndex: "roleName",
          key: "roleName",
          scopedSlots: { customRender: "roleName" },
          width: "25%",
          className: "column-flex",
        },

        {
          title: "账号",
          dataIndex: "userName",
          key: "userName",
          width: "17%",
        },
        {
          title: "链权限",
          dataIndex: "groupNames",
          key: "groupNames",
          ellipsis: true,
          width: "36%",
        },

        {
          title: "操作",
          dataIndex: "operation",
          key: "operation",
          scopedSlots: { customRender: "operation" },
          ellipsis: true,
          width: "150px",
        },
      ],
      data_list: [],
      CommonModalValue: {},
    };
  },
  methods: {
    // 分页组件
    onShowSizeChange(current, pageSize) {
      console.log(current, pageSize, "current, pageSize");
      this.pagination.current = current;
      this.pagination.pageSize = pageSize;
      //改变完 重新渲染数据
      this.getuser_list();
    },

    showDrawer() {
      this.visible = true;
    },
    onClose() {
      this.visible = false;
    },
    // 新增员工账号
    showChildrenDrawer() {
      this.TwoDrawerTitle = "新增员工账号";
      this.childrenDrawer = true;
    },
    // 设置权限
    getPermissions(value) {
      this.$store.commit("CHANGE_DATA", Math.random());
      this.PermissionsValue = value;
      this.TwoDrawerTitle = "设置权限";
      this.childrenDrawer = true;
    },
    onChildrenDrawerClose() {
      this.childrenDrawer = false;
    },
    handleTableChange(pagination, filters, sorter) {
      console.log(pagination);
    },
    //确定
    // async childrenOnClose() {
    //   if (this.$refs.newValue._data.creatUserDTO) {
    //     let value = this.$refs.newValue._data.creatUserDTO;
    //     let res = await user_creatUserd(value, "application/json");
    //     if (res.data.code == 200) {
    //       this.childrenDrawer = false;
    //       this.$message.success("新增成功");
    //       this.getuser_list();
    //     } else {
    //       this.$message.error(res.data.msg);
    //     }
    //   } else {
    //     let res = await user_saveGroupPower(this.$refs.newValue._data.saveUserDTO, "application/json" );
    //     if (res.data.code == 200) {
    //       this.childrenDrawer = false;
    //       this.$message.success("更新成功");
    //       this.getuser_list();
    //     }
    //   }
    // },
    //获取列表
    async getuser_list() {
      let res = await user_list();
      this.data_list = res.data.data;
    },
    //删除账好
    async getuser_delectUser(value) {
      let res = await user_delectUser({ userId: value.id });
      if (res.data.code == 200) {
        this.getuser_list();
        this.$message.success("删除成功");
      } else {
        this.$message.info(res.data.msg);
      }
    },
    // 修改备注
    async getroleName(val) {
      console.log(val);
      let params = {
        RemarkTitle: "修改备注",
        label: "备注",
        value: val.remark,
        id: val.id,
        type: "Operator",
      };
      this.CommonModalValue = params;
      this.isModifyCommon = true;
    },
    async handleOk(value) {
      let res = await user_saveRemark({
        userId: value.id,
        remark: value.value,
      });
      if (res.data.code == 200) {
        this.$message.success("修改成功");
        this.getuser_list();
      }
    },
    handleScroll(e) {
      //变量scrollTop是滚动条滚动时，距离顶部的距离
      var scrollTop = e.target.scrollTop;
      //变量windowHeight是可视区的高度
      var windowHeight = e.target.clientHeight;
      //变量scrollHeight是滚动条的总高度
      var scrollHeight = e.target.scrollHeight;
      //滚动条到底部的条件
      if (scrollTop + windowHeight == scrollHeight) {
        // this.getuser_list()
      }
    },
    //防抖
    debounce(fn, delay) {
      let timer = null; //借助闭包
      return function (e) {
        if (timer) {
          clearTimeout(timer);
        }
        timer = setTimeout(() => {
          fn(e);
        }, delay); // 简化写法
      };
    },
  },
  async mounted() {
    await this.getuser_list();
    let dom = document.getElementById("box");
    dom.addEventListener(
      "scroll",
      this.debounce(this.handleScroll, 1000),
      true
    );
  },
  watch: {
    getList() {
      this.childrenDrawer = false;
      this.getuser_list();
    },
  },

  computed: {
    getList() {
      return this.$store.state.user_creatUser;
    },
    visible: {
      get() {
        return this.isChildAccount;
      },
      set(val) {
        this.$emit("update:isChildAccount", val);
      },
    },
  },
};
</script>
<style lang="scss" scoped>
::v-deep .ant-drawer-body {
  padding: 16px;
  margin-top: 42px;
}
::v-deep .ant-descriptions-item > span {
  font-size: 12px;
}
::v-deep .ant-drawer-header {
  padding: 11px 16px;
  line-height: 44px;
  position: absolute;
  top: 0px;
  z-index: 1000;
  width: 100%;
}
::v-deep .ant-drawer-close {
  height: 44px;
  line-height: 44px;
}
::v-deep .anticon {
  font-size: 12px;
}
.web ::v-deep .ant-btn {
  border-radius: 2px;
  width: 114px;
  font-size: 12px;
  padding: 0px;
}
.twoDrawer::v-deep .ant-btn {
  width: 52px;
  height: 28px;
  border-radius: 2px;
   font-size: 12px;
  padding: 0px;
}
</style>
