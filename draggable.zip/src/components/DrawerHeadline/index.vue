<template>
  <div>
    <a-drawer
      :title="DrawerTitle"
      placement="right"
      :closable="true"
      :visible="visible"
      :width="width"
      :after-visible-change="afterVisibleChange"
      @close="onClose"
    >
      <div class="tabscale">
        <a-tabs default-active-key="1" @change="callback">
          <a-tab-pane key="1" tab="部署新节点">
            <a-form-model
              :layout="ruleForm.layout"
              ref="ruleForms"
              :model="ruleForm"
              :rules="rules"
            >
              <div style="display: flex">
                <a-form-model-item label="服务器IP地址/端口" prop="serverIp">
                  <el-input
                    style="width: 224px"
                    size="small"
                    v-model="ruleForm.serverIp"
                    placeholder="请输入"
                  />
                </a-form-model-item>
                <span class="nonexinxin">
                  <a-form-model-item
                    style="margin-left: 8px"
                    label=" "
                    :colon="false"
                    prop="sshPort"
                  >
                    <el-input
                      style="width: 80px"
                      size="small"
                      v-model="ruleForm.sshPort"
                      placeholder="请输入"
                    />
                  </a-form-model-item>
                </span>
              </div>

              <a-form-model-item label="远程账号" prop="sshAccount">
                <el-input
                  size="small"
                  v-model="ruleForm.sshAccount"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="密码" prop="sshPassword">
                <el-input
                  size="small"
                  v-model="ruleForm.sshPassword"
                  placeholder="请输入"
                />
              </a-form-model-item>
            </a-form-model>
          </a-tab-pane>
          <a-tab-pane key="2" tab="绑定已有节点" force-render>
            <p style="margin-top: 25px" class="titvalue">节点信息</p>
            <a-form-model
              :layout="ruleForm.layout"
              ref="ruleForm"
              :model="ruleForm"
              :rules="rules2"
            >
              <a-form-model-item label="节点IP地址" prop="serverIp">
                <el-input
                  size="small"
                  v-model="ruleForm.serverIp"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="端口" prop="nodePort">
                <el-input
                  size="small"
                  v-model="ruleForm.nodePort"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="节点地址助记词" prop="mnemonic">
                <a-textarea
                  size="small"
                  v-model="ruleForm.mnemonic"
                  placeholder="请输入"
                  :rows="4"
                />
              </a-form-model-item>

              <p style="margin-top: 14px" class="titvalue">SSH信息</p>

              <a-form-model-item label="远程账号" prop="sshAccount">
                <el-input
                  size="small"
                  v-model="ruleForm.sshAccount"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="密码" prop="sshPassword">
                <el-input
                  size="small"
                  v-model="ruleForm.sshPassword"
                  placeholder="请输入"
                />
              </a-form-model-item>
              <a-form-model-item label="访问端口" prop="sshPort">
                <el-input
                  size="small"
                  v-model="ruleForm.sshPort"
                  placeholder="请输入"
                />
              </a-form-model-item>
            </a-form-model>
          </a-tab-pane>
        </a-tabs>
      </div>

      <div
        :style="{
          position: 'absolute',
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e8e8e8',
          padding: '10px 16px',
          textAlign: 'right',
          left: 0,
          background: '#fff',
          borderRadius: '0 0 4px 4px',
        }"
      >
        <a-button
          style="margin-right: 8px"
          @click="resetForm(type == 1 ? 'ruleForms' : 'ruleForm')"
        >
          取消
        </a-button>
        <a-button
          type="primary"
          @click="submitForm(type == 1 ? 'ruleForms' : 'ruleForm')"
        >
          <span>{{ type == 1 ? "连接" : "绑定" }}</span>
        </a-button>
      </div>
    </a-drawer>
    <!-- 部署节点弹框 -->
    <a-modal
      v-model="isModalShow"
      title="部署节点"
      :width="400"
      centered
      :ruleForm="ruleForm"
      @ok="handleOk"
    >
      <p class="modaltitlt">服务器</p>
      <a-descriptions :column="{ sm: 2 }">
        <a-descriptions-item label="IP地址">
          {{ ruleForm.serverIp }}
        </a-descriptions-item>
        <a-descriptions-item label="端口">
          {{ ruleForm.sshPort }}
        </a-descriptions-item>
      </a-descriptions>
      <p class="modaltitlt">一键部署节点</p>
      <span
        >当您点击“开始部署”我们将在您的服务器部署节点：部署成功后，该服务器则成为钜链网络中的一个节点。</span
      ><template slot="footer">
        <a-button @click="handleCancel">取消</a-button>
        <a-button type="primary" @click="getchainNode_creatNode"
          >开始部署</a-button
        >
      </template>
    </a-modal>

    <!-- 正在部署 -->
    <a-modal
      centered
      v-model="visible1"
      :width="400"
      :maskClosable="maskClosable"
      :footer="null"
      title="IP地址/端口"
    >
      <div style="text-align: center">
        <a-spin>
          <a-icon
            slot="indicator"
            type="loading"
            style="font-size: 45px"
            spin
          />
        </a-spin>
        <h2 style="margin: 18px">正在部署</h2>
        <p>部署节点所需时间可能较长，请您耐心等候！</p>
        <!-- <a-button> 最小化窗口 </a-button> -->
      </div>
    </a-modal>
    <!-- 部署失败成功 -->
    <a-modal
      :footer="null"
      :width="400"
      v-model="isSuccessfulFailure"
      :title="`Ip地址/端口:` + ruleForm.serverIp + `/` + ruleForm.sshPort"
      @ok="handleOk"
      centered
    >
      <a-result
        :status="resultvalue.states"
        :title="resultvalue.title"
        :sub-title="resultvalue.creatNodeMessage"
      >
        <template #extra>
          <a-button key="console" @click="getclose" type="primary">
            关闭</a-button
          >
          <a-button
            key="buy"
            v-if="resultvalue.states == 'error'"
            @click="getretry"
          >
            重试
          </a-button>
        </template>
      </a-result>
    </a-modal>
  </div>
</template>
<script>
import { chainNode_bindNode, chainNode_creatNode } from "../../utils/home";
import { setSessionStorage } from "@/utils/util";
export default {
  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isDrawerShow: {
      type: Boolean,
      default: false,
      required: true,
    },
    //标题
    DrawerTitle: {
      type: String,
      default: false,
      required: true,
    },
    //宽度
    isDrawerWidth: {
      type: Number,
      default: false,
      required: true,
    },
  },
  data() {
    let serverIp = (rule, value, callback) => {
      if (value == "" || value == undefined) {
        return callback(new Error("请输入iP地址"));
      }
      let regexp =
        /^((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}$/;
      let valdata = value.split(",");
      let isCorrect = true;
      if (valdata.length) {
        for (let i = 0; i < valdata.length; i++) {
          if (regexp.test(valdata[i]) == false) {
            isCorrect = false;
          }
        }
      }
      if (value == "") {
        return callback(new Error("请输入iP地址"));
      } else if (!isCorrect) {
        callback(new Error("请输入正确的ip地址"));
      } else {
        callback();
      }
    };

    return {
      maskClosable: false,
      resultvalue: {},
      isModalShow: false,
      isModalShow1: false,
      visible1: false,
      isSuccessfulFailure: false,
      ModalTitle: "",
      FooterOk: "",
      FooterCancel: "",
      title: "",
      width: "",
      type: 1,
      stateValue: 1,
      creatNodeMessage: "",
      ruleForm: {
        layout: "horizontal",
      },
      rules: {
        serverIp: [
          {
            required: true,
            validator: serverIp,
            trigger: "change",
          },
        ],
        sshPassword: [{ required: true, message: "请输入", trigger: "change" }],
        sshAccount: [{ required: true, message: "请输入", trigger: "change" }],
        sshPort: [{ required: true, message: "请输入", trigger: "change" }],
      },
      rules2: {
        mnemonic: [{ required: true, message: "请输入", trigger: "change" }],
        serverIp: [{ required: true, validator: serverIp, trigger: "change" }],
        nodePort: [{ required: true, message: "请输入", trigger: "change" }],
        sshAccount: [{ required: true, message: "请输入", trigger: "change" }],
        sshPassword: [{ required: true, message: "请输入", trigger: "change" }],
        sshPort: [{ required: true, message: "请输入", trigger: "change" }],
      },
    };
  },
  methods: {
    // 开始部署
    async getchainNode_creatNode(e) {
      this.visibleModal = false;
      this.visible1 = true;
      this.maskClosable = false;
      this.$store.commit("LOADDING_SHOW", true);
      let res = await chainNode_creatNode(this.ruleForm);
      if (res.data.code == 200) {
        setSessionStorage("current", 1);
        this.resultvalue.creatNodeMessage = "";
        this.resultvalue.title = "部署成功";
        this.resultvalue.states = "success";
        this.$store.commit("DEPLOOY_MENTOF", Math.random());
        this.visible1 = false;
        this.isSuccessfulFailure = true;
      } else {
        this.resultvalue.creatNodeMessage = res.data.msg;
        this.resultvalue.title = "部署失败";
        this.resultvalue.states = "error";
        this.visible1 = false;
        this.isSuccessfulFailure = true;
      }
    },
    getcreatNode() {},
    handleCancel() {
      this.isModalShow = false;
    },
    // 关闭
    getclose() {
      this.visible = false;
      this.visible1 = false;
      this.isModalShow = false;
      this.isSuccessfulFailure = false;
    },
    // 重试
    getretry() {
      this.isSuccessfulFailure = false;
      this.getchainNode_creatNode();
    },
    submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          if (formName == "ruleForms") {
            this.isModalShow = !this.isModalShow;
            this.ModalTitle = "部署节点";
            this.FooterOk = "开始部署";
            this.FooterCancel = "取消";
          } else {
            this.$emit("spinninglod", true);
            let res = await chainNode_bindNode(this.ruleForm);
            this.$emit("spinninglod", false);
            if (res.data.code == 200) {
              this.$message.destroy();
              this.$message.success("绑定成功");
              this.isModalShow = false;
              this.visible = false;
              this.$store.commit("DEPLOOY_MENTOF", Math.random());
            } else {
              this.$message.destroy();
              this.$message.error(res.data.msg);
            }
          }
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },

    resetForm(formName) {
      this.$refs[formName].resetFields();
      this.visible = false;
    },
    handleOkval(val) {
      this.visible1 = val;
    },
    handleOk() {},
    callback(val) {
      console.log(val);
      this.type = val;
      this.ruleForm = {};
      this.stateValue = val;
    },
    afterVisibleChange(val) {
      console.log("visible", val);
    },
    onClose() {
      this.visible = false;
    },
  },
  computed: {
    visible: {
      get() {
        return this.isDrawerShow;
      },
      set(val) {
        this.$emit("update:isDrawerShow", val);
      },
    },
  },
  created() {
    this.title = this.DrawerTitle;
    this.width = this.isDrawerWidth;
  },
};
</script>
<style lang="scss" scoped>
.nonexinxin {
  ::v-deep .ant-form-item-required::before {
    color: #fff;
  }
}
.tabscale {
  padding-bottom: 30px;
}
.modaltitlt {
  font-size: $size-title;
  font-weight: 500;
  color: $color-tit;
  span {
    font-size: 12px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: rgba(0, 0, 0, 0.85);
  }
}
::v-deep .tabscale .ant-tabs-nav .ant-tabs-tab {
  width: auto !important;
  font-size: 12px;
  padding:4px 8px
}
::v-deep .ant-drawer-body{
  padding: 17px 24px;
}
</style>