<template>
  <div>
    <div>
      <a-modal v-model="visibleModal" :title="ModalTitle" :width="ModalWidth">
        <slot name="text"></slot>
        <template slot="footer">
          <a-button @click="handleCancel">{{ FooterCancel }}</a-button>
          <a-button type="primary" @click="handleOk">{{ FooterOk }}</a-button>
        </template>
      </a-modal>
    </div>
  </div>
</template>
<script>
import { chainNode_creatNode } from "@/utils/home";

export default {
  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isModalShow: {
      type: Boolean,
      default: false,
      required: true,
    },
    ModalTitle: {
      type: String,
      default: false,
      required: true,
    },
    ModalWidth: {
      type: Number,
      default: false,
      required: true,
    },
    FooterOk: {
      type: String,
      default: false,
      required: true,
    },
    FooterCancel: {
      type: String,
      default: false,
      required: true,
    },
    ruleForm: {
      type: Object,
      default: false,
      required: true,
    },
  },
  data() {
    return {};
  },
  methods: {
    async handleOk(e) {
      this.visibleModal = false;
      let res = await chainNode_creatNode(this.ruleForm);
    },
    handleCancel(e) {
      console.log(e);
      this.visibleModal = false;
    },
  },
  computed: {
    visibleModal: {
      get() {
        return this.isModalShow;
      },
      set(val) {
        this.$emit("update:isModalShow", val);
      },
    },
  },
  created() {
    this.ModalTitle = this.ModalTitle;
    this.FooterOk = this.FooterOk;
    this.FooterCancel = this.FooterCancel;
    this.ruleForm=this.ruleForm
    console.log( this.ruleForm);
  },
};
</script>
