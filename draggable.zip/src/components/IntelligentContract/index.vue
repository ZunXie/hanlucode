<template>
  <div class="wrapper">
    <div class="wrapper__button">
      <a-button type="primary"> 创建合约场景 </a-button>
    </div>
    <div class="wrapper__table">
      <a-table
        bordered
        :pagination="false"
        :columns="columns_parameter"
        :data-source="data_parameter"
        :rowKey="(record) => record.groupCode"
      >
      </a-table>
    </div>

    <div class="wrapper__textbottom">
      <div>说明:</div>
      <div>
        1、智能合约是运行在区块链中的一段代码，可以在没有第三方的情况下按合约中既定的规则自动执行命令。由于区块链公开透明和不可篡改的特性，智能合约的代码和规则也是公开透明和不可篡改的，因此我们认为通过智能合约执行的命令具有公开透明、不可篡改的特性。
      </div>
      <div>
        2、智能合约可以接受外部系统的数据并根据合约中约定的规则在区块链执行某些命令，如将输入的数据保存在区块链中，这就是我们常说的数据上链。
      </div>
      <div>
        3、数据上链服务集成了合约部署、合约的对接和业务处理等中间服务，开发者无需编写和部署合约，也无需对接合约，可以直接通过API调用数据上链服务即可实现数据上链。
      </div>
      <div>
        4、在对接数据上链服务前，需要先创建合约场景，我们将自动为您在指定的区块链上部署智能合约，BaaS中间服务会自动对接部署好的智能合约。
      </div>
      <div>
        5、一般来说，您可以根据不同的业务场景创建多个合约场景，每个合约场景对应不同的区块链和智能合约。
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
    return {
      columns_parameter: [
        {
          title: "场景ID",
          dataIndex: "groupCode",
          key: "groupCode",
          width: "20%",
        },
        {
          title: "场景名称",
          dataIndex: "groupName",
          key: "groupName",
          width: "20%",
        },
        {
          title: "合约工程名",
          dataIndex: "nodeCount",
          key: "nodeCount",
          width: "15%",
        },
        {
          title: "部署的链",
          dataIndex: "status",
          scopedSlots: { customRender: "status", ellipsisSlot: true },
          key: "status",
          ellipsis: true,
        },
        {
          title: "场景描述",
          dataIndex: "nodeCount1",
          key: "nodeCount1",
          width: "15%",
        },
        {
          title: "创建时间",
          dataIndex: "nodeCount2",
          key: "nodeCount2",
          width: "15%",
        },
      ],
      data_parameter: [
        {
          groupCode: "1",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
        {
          groupCode: "4",
          groupName: "John Brown",
          nodeCount: 32,
          status: "New York No. 1 Lake Park",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
@include b(wrapper) {
  @include e(button) {
    text-align: end;
    margin-bottom: 16px;
  }
  @include e(table) {
    margin-bottom: 26px;
  }
  @include e(textbottom) {
    font-weight: 400;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.65);
    line-height: 24px;
    margin-bottom: 24px;
    div {
      text-indent: -1.6em;
      margin-left: 1.6em;
    }
  }
}
</style>