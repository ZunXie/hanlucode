<template>
  <div class="wrapper">
      <MarkdownItVue class="md-body" :content="value" />
  </div>
</template>

<script>
import MarkdownItVue from "markdown-it-vue";
import "markdown-it-vue/dist/markdown-it-vue.css";

export default {
  components: { MarkdownItVue },
  props: ["value"],
  data() {
    return {};
  },
};
</script>
<style lang="less" scoped>
</style>