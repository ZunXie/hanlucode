<template>
  <div class="m-table">
    <!-- 表格相关操作 -->
    <div class="top">
      <!-- 左侧预留位置 -->
      <div style="width:1px"></div>
      <!-- 右侧菜单栏 -->
      <div class="menu">
        <a-button type="primary" style="width:72px;height:28px"
          >Primary</a-button
        >
        <a-button type="dashed" style="width:72px;height:28px;marginLeft:8px;"
          >表头设置</a-button
        >
        <a-icon
          @click="reDo"
          style="marginLeft:16px;marginRight:8px;fontSize:16px"
          type="redo"
        />
        <a-icon
          v-if="fullStatu"
          @click="fullScreen"
          style="marginRight:8px;fontSize:16px"
          type="fullscreen"
        />
        <a-icon
          v-if="!fullStatu"
          @click="fullExit"
          style="marginRight:8px;fontSize:16px"
          type="fullscreen-exit"
        />
      </div>
    </div>
    <a-table
      class="refTable"
      :ref="refName"
      :columns="tableHeader"
      :data-source="data"
      :bordered="option.bordered"
      :row-selection="rowSelection"
      :pagination="false"
    >
      <!-- slot 添加自定义配置项 -->
      <!-- <template slot="">

        </template> -->

      <!-- 序号 -->
      <template slot="index" slot-scope="text, record, index">
        {{ parseInt(index) + 1 }}
      </template>

      <!-- 编辑行 -->
      <template
        v-for="col in operateSlots"
        :slot="col"
        slot-scope="text, record"
      >
        <div :key="col">
          <a-input
            v-if="record.editable"
            style="margin: -5px 0"
            :value="text"
            @change="(e) => handleChange(e.target.value, record.key, col)"
          />
          <template v-else>
            {{ text }}
          </template>
        </div>
      </template>

      <!-- 操作列 -->
      <template slot="operate" slot-scope="text, record">
        <!-- {{ record.operate}} -->
        <!-- <div class="operateType">
                <span v-for="(item,index) in operate" :key="index"> <a @click="operateData(record,item.type)">{{item.name}}</a></span>
                </div> -->

        <div class="editable-row-operations operateType">
          <div class="operateCol" v-if="record.editable">
            <a @click="() => save(record.key)">保存</a>
            <a-popconfirm
              title="是否删除？"
              @confirm="() => cancel(record.key)"
            >
              <a>取消</a>
            </a-popconfirm>
          </div>
          <!-- 循环很少，对性能不会有太大的消耗，一般v-for和v-if不能联用 -->
          <span v-else v-for="(item, index) in operate" :key="index">
            <a
              :class="item.type"
              :disabled="editingKey !== ''"
              @click="operateData(record, item.type)"
              >{{ item.name }}</a
            >
            <!-- <a :disabled="editingKey !== ''" @click="() => edit(record.key)">Edit</a> -->
          </span>
        </div>
      </template>
    </a-table>
  </div>
</template>

<script>
export default {
  name: 'mTable',
  props: {
    data: {
      default: () => [],
      type: Array,
    },
    tableHeader: {
      type: Array,
      default: () => [],
    },
    option: {
      default: () => {
        return {
          bordered: true,
          maxHeight: 500,
        }
      },
      type: Object,
    },
    refName: {
      type: String,
      default: 'table',
    },
    rowSelection: {
      default: () => {},
      type: Object,
    },
  },
  data() {
    return {
      // 全屏标志
      fullStatu: true,
      operate: [],
      editingKey: '',
      // 编辑行slot
      operateSlots: [],
      cacheData: [],
    }
  },
  created() {
    this.cacheData = this.data.map((item) => ({ ...item }))
    this.tableHeader.forEach((item) => {
      // console.log(61,item);
      if (item.editable) {
        this.operateSlots.push(item.scopedSlots.customRender)
      }
      // console.log(112,this.operateSlots);
      if (item.key === 'operate') {
        this.operate = item.operateType
        this.$nextTick(() => {
          document.querySelectorAll('.delRow').forEach((item) => {
            item.style.color = 'red'
          })
        })
      }
    })
  },
  mounted() {
    this.changeStyle()
  },
  methods: {
    // 修改样式
    changeStyle() {
      let operateType = document.querySelectorAll('.operateType')
      operateType.forEach((item) => {
        // console.log(68,item.style);
        item.style.display = 'flex'
        item.style.justifyContent = 'space-around'
      })
    },
    // 刷新数据
    reDo() {
      this.$emit('changeSuccess')
    },
    // 全屏
    fullScreen() {
      // let ele = document.querySelector('.refTable')
      let ele = document.querySelector('.m-table')
      let requestMethod =
        ele.requestFullScreen ||
        ele.webkitRequestFullScreen || //谷歌
        ele.mozRequestFullScreen || //火狐
        ele.msRequestFullScreen //IE11

      if (requestMethod) {
        requestMethod.call(ele)
        ele.style.backgroundColor = '#fff'
      } else if (typeof window.ActiveXObject !== 'undefined') {
        // eslint-disable-next-line no-undef
        var wscript = new ActiveXObject('WScript.Shell') //创建ActiveX
        if (wscript !== null) {
          //创建成功
          wscript.SendKeys('{F11}') //触发f11
        }
      }
      this.fullStatu = !this.fullStatu
    },
    fullExit() {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen()
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen()
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen()
      }
      this.fullStatu = !this.fullStatu
    },
    // 操作行数据
    operateData(record, type) {
      // switch(type){
      //     case 'edit':
      //         this.$emit('edit',record)
      //         break
      //     case 'add':
      //         this.$emit('add',record)
      // }
      if (type === 'editRow') {
        console.log('子组件方法被触发了')
        this.editRow(record)
      } else {
        console.log('父组件方法被触发了')
        this.$emit(`${type}`, record)
      }
    },
    // 编辑行
    editRow(record) {
      const newData = [...this.data]
      const target = newData.find((item) => record.key === item.key)
      this.editingKey = record.key
      if (target) {
        target.editable = true
        this.$emit('changeData', newData)
        // this.data = newData;
      }
    },
    // 编辑行数据变化时
    handleChange(value, key, column) {
      const newData = [...this.data]
      const target = newData.find((item) => key === item.key)
      if (target) {
        target[column] = value
      }
    },
    // 编辑行保存
    save(key) {
      const newData = [...this.data]
      const target = newData.find((item) => key === item.key)
      const newCacheData = [...this.cacheData]
      const targetCache = newCacheData.find((item) => key === item.key)
      if (target) {
        delete target.editable
        // this.data = newData;
        this.$emit('changeData', newData)
        Object.assign(targetCache, target)
        this.cacheData = newCacheData
      }
      this.editingKey = ''
    },
    // 编辑行取消
    cancel(key) {
      const newData = [...this.data]
      const target = newData.find((item) => key === item.key)
      this.editingKey = ''
      if (target) {
        Object.assign(
          target,
          this.cacheData.find((item) => key === item.key)
        )
        delete target.editable
        this.$emit('changeData', newData)
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.m-table {
  width: 90%;
  margin: 0 auto;
  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 35px;
  }
  .operateCol {
    width: 100%;
    display: flex;
    justify-content: space-around;
  }
}
</style>
