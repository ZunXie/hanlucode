<template>
  <div>
      <m-table
        ref="table"
        :data = list
        :rowSelection = "rowSelection"
        :tableHeader = tableHeader
        @changeSuccess = "changeSuccess"
        @edit = "edit"
        @changeData = "changeData"
      >
        <!--  -->
      </m-table>
  </div>
</template>

<script>
export default {
    name:"Call",
    data(){
        return{
            list:[
                {
                    key: '1',
                    name: 'John Brown',
                    age: 32,
                    address: 'New York No. 1 Lake Park, New York No. 1 Lake Park',
                },
                {
                    key: '2',
                    name: 'Jim Green',
                    age: 42,
                    address: 'London No. 2 Lake Park, London No. 2 Lake Park',
                },
                {
                    key: '3',
                    name: 'Joe Black',
                    age: 32,
                    address: 'Sidney No. 1 Lake Park, Sidney No. 1 Lake Park',
                },
            ],
            tableHeader:[
                {
                    title:"序号",
                    dataIndex: 'index',
                    key: 'index',
                    // slot固定使用index
                    scopedSlots: { customRender: 'index' },
                    align: 'center',
                    width:50,
                    editable:false,
                },
                {
                    title: 'Name',
                    dataIndex: 'name',
                    key: 'name',
                    // 实现编辑行需要的参数
                    scopedSlots: { customRender: 'name' },
                    // 是否可编辑
                    editable:false,
                },
                {
                    title: 'Age',
                    dataIndex: 'age',
                    key: 'age',
                    scopedSlots: { customRender: 'age' },
                    editable:true,
                },
                {
                    title: 'Address',
                    dataIndex: 'address',
                    key: 'address',
                    ellipsis: true,
                    scopedSlots: { customRender: 'address' },
                    editable:true,
                },
                {
                    title: '操作',
                    dataIndex: 'operate',
                    key: 'operate',
                    // slot固定使用operate
                    scopedSlots: { customRender: 'operate' },
                    // 自定义方法使用步骤
                    // 1、在operateType中定义
                    // 2、在m-table中定义方法
                    // 3、在methods中直接定义方法体
                    // 4、编辑行的type固定是editRow,删除的type固定是delRow，name属性可以自定义
                    operateType:[{type:'edit',name:"编辑"},{type:'editRow',name:"编辑行"},{type:'delRow',name:"删除"}],
                    fixed:'right',
                    align:'center',
                    width:150,
                },
                
            ]
        }
    },
    created(){
        
    },
    computed: {
        // 选择框
        rowSelection() {
            return {
                onChange: (selectedRowKeys, selectedRows) => {
                    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
                },
                getCheckboxProps: record => ({
                    props: {
                        disabled: record.name === 'Disabled User', // Column configuration not to be checked
                        name: record.name,
                    },
                }),
                type:"checkbox" // 多选/单选，checkbox or radio
            };
        },
    },
    methods:{
        // 刷新数据
        changeSuccess(){
            console.log("数据被刷新了");
            this.fetch()
        },
        // 操作列的方法，让子组件调用自己定义的方法即可
        edit(data){
            console.log('数据被操作了',data);
        },
        // 返回编辑行修改的数据
        changeData(data){
            this.list = data
        },
        fetch(){}
    }
}
</script>

<style lang="scss" scoped>

</style>