<template>
  <div>
    <a-drawer
      placement="right"
      :maskClosable="maskClosable"
      :closable="true"
      :visible="visible"
      :width="600"
      :after-visible-change="afterVisibleChange"
      @close="onClose"
    >
      <template slot="title"
        >部署联盟链
        <a-tooltip placement="bottom">
          <template slot="title">
            <a style="color: #fff" @click="goHelp">查看帮助</a>
          </template>
          <i
            style="margin-left: 5px; color: #bfbfbf"
            class="iconfont icon-Question-Circle-Fill"
          ></i>
        </a-tooltip>
      </template>
      <a-spin :spinning="spinning">
        <p class="titvalue">基础信息</p>
        <a-form-model
          ref="ruleForm"
          :model="ruleForm"
          :rules="rules"
          v-bind="layout"
        >
          <a-form-model-item prop="groupCode">
            <span slot="label">
              链名&nbsp;
              <a-tooltip
                title="链名是联盟链的唯一标识，用于联盟链的查询、部署和调用合约、交易操作等"
              >
                <i
                  style="color: #595959"
                  class="iconfont icon-Warning-Circle"
                ></i
                >&nbsp;
              </a-tooltip>
            </span>
            <el-input
              size="small"
              maxlength="10"
              style="width: 200px"
              show-word-limit
              v-model="ruleForm.groupCode"
              placeholder="请输入"
            />
          </a-form-model-item>
          <a-form-model-item label="联盟链名称">
            <el-input
              size="small"
              maxlength="10"
              style="width: 200px"
              show-word-limit
              v-model="ruleForm.groupName"
              placeholder="请输入"
            />
          </a-form-model-item>
          <a-form-model-item prop="nodeId">
            <span slot="label">
              管理员节点&nbsp;
              <a-tooltip
                title="管理员节点有权限向联盟链中添加、删除节点以及停用该联盟链。"
              >
                <i
                  style="color: #595959"
                  class="iconfont icon-Warning-Circle"
                ></i
                >&nbsp;
              </a-tooltip>
            </span>
            <a-select v-model="ruleForm.nodeId" v-if="ruleForm.nodeId">
              <a-select-option
                v-for="(item, index) in nodeIdlist"
                :key="index"
                :value="item.id"
              >
                {{ item.serverIp + `【` + item.nodeAddress + `】` }}
              </a-select-option>
            </a-select>
            <!-- <el-input v-model.number="ruleForm.nodeId" /> -->
          </a-form-model-item>
          <p style="margin-top: 40px" class="titvalue">共识配置</p>

          <a-form-model-item prop="consensus">
            <span slot="label">
              共识机制&nbsp;

              <a-tooltip
                title="单节点矿工机制。在集群中仅有一个固定角色的矿工，该矿工负责生产区块，区域节点从其同步账本。"
              >
                <i
                  style="color: #595959"
                  class="iconfont icon-Warning-Circle"
                ></i
                >&nbsp;
              </a-tooltip>
            </span>
            <a-select placeholder="single" v-model="ruleForm.consensus">
              <a-select-option
                v-for="(item, index) in consensusList"
                :key="index"
                :value="item.value"
              >
                {{ item.title }}
              </a-select-option>
            </a-select>
          </a-form-model-item>
          <a-form-model-item>
            <span slot="label"> 出块间隔 </span>
            <a-input
              suffix="毫秒"
              style="width: 200px"
              placeholder="请输入"
              v-model.number="ruleForm.period"
            />
          </a-form-model-item>
          <a-form-model-item label="每个区块最大大小" prop="maxBlockSize">
            <a-input
              suffix="MB"
              placeholder="请输入"
              style="width: 200px"
              v-model="ruleForm.maxBlockSize"
            />
          </a-form-model-item>
          <a-form-model-item prop="nofee">
            <span slot="label">
              交易模式&nbsp;
              <a-tooltip
                title="在联盟链上执行普通交易、调用和部署合约等操作是否需要消耗联盟链燃料"
              >
                <i class="iconfont icon-Warning-Circle"></i>&nbsp;
              </a-tooltip>
            </span>
            <a-select
              :default-value="selectList[0].value"
              v-model="ruleForm.nofee"
            >
              <a-select-option
                v-for="(item, index) in selectList"
                :key="index"
                :value="item.value"
              >
                {{ item.title }}
              </a-select-option>
            </a-select>
          </a-form-model-item>
          <div
            :style="{
              position: 'fixed',
              bottom: 0,
              width: '600px',
              borderTop: '1px solid #e8e8e8',
              padding: '10px 16px',
              textAlign: 'right',
              right: 0,
              background: '#fff',
              borderRadius: '0 0 4px 4px',
            }"
          >
            <a-button
              type="primary"
              style="margin-right: 8px"
              @click="submitForm('ruleForm')"
            >
              部署
            </a-button>
            <a-button style="marginright: 8px" @click="resetForm('ruleForm')">
              取消
            </a-button>
          </div>
        </a-form-model>
      </a-spin>
    </a-drawer>
  </div>
</template>
<script>
import { chainGroup_create, chainNode_list } from '@/utils/home'
import { setSessionStorage } from '@/utils/util'
import { goToBrowser } from '@/mixins/goToBrowser'

export default {
  mixins: [goToBrowser],

  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isLeagueChain: {
      type: Boolean,
      default: false,
      required: true,
    },
  },
  data() {
    // let groupCode = (rule, value, callback) => {
    //   if (value === "") {
    //     callback(new Error("Please input the password"));
    //   }
    // };

    return {
      maskClosable: true,
      ruleForm: {
        consensus: undefined,
        period: '',
        maxBlockSize: '128',
        nofee: 0,
        nodeId: null,
      },
      selectList: [
        {
          title: '无手续费',
          value: 0,
        },
        {
          title: '有手续费',
          value: 1,
        },
      ],
      consensusList: [
        // 共识机制选项
        {
          title: 'single',
          value: 'single',
        },
      ],
      nodeIdlist: [],
      rules: {
        groupCode: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        groupName: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        nodeId: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        maxBlockSize: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        consensus: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
        nofee: [
          {
            required: true,
            message: '请输入必填项',
            trigger: 'change',
          },
        ],
      },
      layout: {
        labelCol: { span: 6 },
        wrapperCol: { span: 18 },
      },
      snodeIddef: '',
      spinning: false,
    }
  },

  mounted() {
    this.getchainNode_list()
  },
  methods: {
    afterVisibleChange(val) {
      console.log('visible', val)
    },
    onClose() {
      this.visible = false
    },
    // 获取所有节点
    async getchainNode_list() {
      let res = await chainNode_list({ status: 'Y' })
      this.nodeIdlist = res.data.data.rows
      this.ruleForm.nodeId = res.data.data.rows[0].id
    },
    submitForm(formName) {
      this.ruleForm.consensus = 'single'
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          this.spinning = true
          this.maskClosable = false
          this.$store.commit('LOADDING_SHOW', true)

          let res = await chainGroup_create(this.ruleForm)
          this.$store.commit('LOADDING_SHOW', false)
          this.spinning = false
          this.maskClosable = true
          if (res.data.code == 200) {
            this.$store.commit('CHAINGROUP_CREATE', Math.random())
            setSessionStorage('current', 2)
            this.$message.success('部署成功')
            this.visible = false
          } else {
            this.$message.warning(res.data.msg)
          }
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm(formName) {
      this.visible = false
      this.$refs[formName].resetFields()
    },
  },
  computed: {
    visible: {
      get() {
        return this.isLeagueChain
      },
      set(val) {
        this.$emit('update:isLeagueChain', val)
      },
    },
  },
}
</script>
<style lang="scss" scoped>
.titvalue {
  font-size: $size-title;
  font-weight: 500;
  color: $color-tit;
}
.titvalue::before {
  content: '';
  border-left: 4px solid #007aff;
  margin-right: 12px;
  height: 3px;
}
::v-deep .ant-drawer-close {
  z-index: 3 !important;
}
::v-deep .el-input__inner {
  height: 28px;
}
::v-deep .ant-select-selection {
  height: 28px;
}
::v-deep .ant-input {
  height: 28px;
}
</style>
