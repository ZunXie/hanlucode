<template>
  <div class="wrapper">
    <i
      style="color: #309efe"
      v-if="show == 'iconCopy'"
      :class="tit"
      :data-clipboard-text="valuetext"
      @click="handleCopyFun"
      class="iconfont icon-copy"
    ></i>
    <a-button
      v-if="show == 'link'"
      :class="tit"
      :data-clipboard-text="valuetext"
      @click="handleCopyFun"
      type="link"
    >
      复制全部
    </a-button>
    <i
      v-else-if="!show"
      :class="tit"
      :data-clipboard-text="valuetext"
      @click="handleCopyFun"
      type="copy"
      class="iconfont icon-copy"
    ></i>

    <img src="" alt="" />
  </div>
</template>

<script>
import Clipboard from "clipboard";
import { copy } from "@/utils/common";

export default {
  components: {},
  props: {
    tit: {
      type: String,
      default: "0",
    },
    valuetext: {
      type: String,
      default: "0",
    },
    show: {
      type: String,
      default: "",
    },
  },
  data() {
    return {};
  },
  watch: {},
  computed: {},
  methods: {
    handleCopyFun() {
      let instance = this.valuetext.replaceAll("<br>", "\r\n");
      copy(instance)
      // copy(this.valuetext);
      return;
      let clipboard = new Clipboard(`.` + this.tit);
      clipboard.on("success", () => {
        this.$message.success("恭喜你,复制成功!");
        clipboard.destroy(); // 释放内存
      });
      clipboard.on("error", () => {
        // 不支持复制
        alert("该浏览器不支持自动复制");
        clipboard.destroy(); // 释放内存
      });
    },
  },
  created() {},
  mounted() {},
};
</script>
<style lang="scss" scoped>
.iconfont icon-copy {
  color: red;
}
</style>