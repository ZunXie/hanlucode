<template>
  <div class="treatyWord">
    <div v-if="intelligentContract.rows" class="mainBody">
      <div
        @click="getContract(item)"
        v-for="(item, index) in intelligentContract.rows"
        :key="index"
        class="content"
      >
        <img :src="item.ctIcon" alt="" />
        <div class="mainBody-title">
          <div class="fontSize16">{{ item.ctName }}</div>
          <div
            style="
              height: 60px;
              display: -webkit-box;
              -webkit-box-orient: vertical;
              -webkit-line-clamp: 3;
              overflow: hidden;
            "
          >
            {{ item.ctIntro }}
          </div>
        </div>
        <div></div>
      </div>
   
      <!-- 分页 -->
      <a-pagination
        v-model="pagination.pageNum"
        :total="intelligentContract.total"
        :show-total="(total) => `共 ${total} 条`"
        :page-size="10"
        :default-current="pagination.pageSize"
        @change="getpagination"
        :hideOnSinglePage='true'
      />
    </div>
        <Empty v-else style="margin-top: 250px" text="暂无联盟链" />

    <DrawerContract v-if="isShow" :isShow.sync="isShow" :value="value" />
  </div>
</template>

<script>
import DrawerContract from "../DrawerContract";
import { ctm_list } from "@/utils/Contact";

export default {
  components: { DrawerContract },
  data() {
    return {
      isShow: false,
      value: "",
      current: 1,
      pagination: { pageNum: 1, pageSize: 10 },
      intelligentContract: [],
    };
  },
  watch: {},
  computed: {},
  methods: {
    getContract(value) {
      this.value = value;
      this.isShow = !this.isShow;
    },
    //获取合约列表
    async getctm_list() {
      let res = await ctm_list(this.pagination);
      this.intelligentContract = res.data.data;
    },
 
    // 改变分页数据
    getpagination() {
      this.getctm_list();
    },
  },
  created() {},
  mounted() {
    this.getctm_list();
  },
};
</script>
<style lang="scss" scoped>
.mainBody {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.content {
 width: 33%;
  background: $color-primary;
  padding: 16px;
  display: flex;
  margin-bottom: 16px;
}
.mainBody-title:hover{
  cursor: pointer;
}
img {
  width: 92px;
  height: 92px;
  margin-right: 16px;
}
</style>