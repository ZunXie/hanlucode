<template>
  <div class="wrapper">
    <codemirror
      v-model="ctInfo"
      :options="cmOption"
      class="code-mirror"
      @ready="onCmReady3"
      @focus="onCmFocus"
      @input="onCmCodeChange"
      ref="myCmGenerate"
    ></codemirror>
  </div>
</template>

<script>
import { codemirror } from "vue-codemirror";
// 我这里引入的是JS语言文件
import "codemirror/mode/javascript/javascript.js";
import "../../utils/setting";
export default {
  components: { codemirror },
  props: ["ctInfo", "theme"],
  data() {
    return {
      clipboardData: '',
      // aa:`"package mainimport (	"fmt"	"github.com/xuperchain/xuper-sdk-go/v2/account"	"github.com/xuperchain/xuper-sdk-go/v2/xuper"	"log")// 文件存储type HashDeposit struct {	// 链客户端	Client *xuper.XClient	// 链名	Bcname string	// 调用者	Account *account.Account	// 合约名	ContractName string}func NewHashDeposit(node, bcname, contractName string, account *account.Account)(*HashDeposit, error)   {	// 强制使用链名	if bcname == "" {		return nil, fmt.Errorf("bcname error, check it")	}	// 连接链	client, err := xuper.New(node)	if err != nil {		log.Println(err)		return nil, err	}	return &HashDeposit{		Client: client,		Bcname: bcname,		Account: account,		ContractName: contractName,	},nil}func (h *HashDeposit) Close()  {	_ = h.Client.Close()}func (h *HashDeposit) StoreFileInfo(user_id, hash_id, file_name string) {	args := map[string]string{		"user_id": user_id,		"hash_id": hash_id,		"file_name": file_name,	}	tx, err := h.Client.InvokeWasmContract(h.Account, h.ContractName, "storeFileInfo", args, xuper.WithBcname(h.Bcname))	if err != nil {		log.Println("excu error", err)		return	}	// 对返回结果进行处理	fmt.Printf("%#v\n",tx)}func (h *HashDeposit) QueryUserList() {	tx, err := h.Client.InvokeWasmContract(h.Account, h.ContractName, "queryUserList", nil, xuper.WithBcname(h.Bcname))	if err != nil {		log.Println("excu error", err)		return	}	// 对返回结果进行处理	fmt.Printf("%#v\n",tx)}func (h *HashDeposit) queryFileInfoByUser(user_id string) {	args := map[string]string{		"user_id": user_id,	}	tx, err := h.Client.InvokeWasmContract(h.Account, h.ContractName, "queryFileInfoByUser", args, xuper.WithBcname(h.Bcname))	if err != nil {		log.Println("excu error", err)		return	}	// 对返回结果进行处理	fmt.Printf("%#v\n",tx)}func (h *HashDeposit) queryFileInfoByHash(hash_id string) {	args := map[string]string{		"hash_id": hash_id,	}	tx, err := h.Client.InvokeWasmContract(h.Account, h.ContractName, "queryFileInfoByHash", args, xuper.WithBcname(h.Bcname))	if err != nil {		log.Println("excu error", err)		return	}	// 对返回结果进行处理	fmt.Printf("%#v\n",tx)}"`,
      cmOption: {
        tabSize: 2, // tab
        styleActiveLine: true, // 高亮选中行
        lineNumbers: true, // 显示行号
        styleSelectedText: true,
        line: true,
        foldGutter: true, // 块槽
        scrollbarStyle: null,
        gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
        highlightSelectionMatches: { showToken: /\w/, annotateScrollbar: true }, // 可以启用该选项来突出显示当前选中的内容的所有实例
        mode: {
          // 模式, 可查看 codemirror/mode 中的所有模式
          name: "javascript",
          json: true,
        },
        // hint.js options
        hintOptions: {
          // 当匹配只有一项的时候是否自动补全
          completeSingle: false,
        },
        // 快捷键 可提供三种模式 sublime、emacs、vim
        keyMap: "sublime",
        matchBrackets: true,
        showCursorWhenSelecting: true,
        theme: "dracula", // 主题
        extraKeys: { Ctrl: "autocomplete" }, // 可以用于为编辑器指定额外的键绑定，以及keyMap定义的键绑定
      },
    };
  },

  methods: {
    onCmReady3() {
      let height =
        Math.max(
          document.body.scrollHeight,
          document.documentElement.scrollHeight
        ) -
        64 +
        "px";
      this.$refs.myCmGenerate.codemirror.setSize("100%", height);
    },
    onCmFocus(instance, event) {},
    onCmCodeChange(instance, obj) {
      // console.log(instance);
      this.$emit("ctInfo", instance);
      // console.log(obj);
    },
  },
  mounted() {
    this.cmOption.theme = this.theme;
    document.onpaste = (e)=>{
      if(e.clipboardData) {
          console.log('谷歌,火狐');
          for (var i = 0, len = e.clipboardData.items.length; i < len; i++) {
              var item = e.clipboardData.items[i];
              if (item.kind === "string") {
                  item.getAsString(function (str) {
                      this.clipboardData = str;
                  })
              } else if (item.kind === "file") {
                  var f= item.getAsFile();
                
              }
          }
      }else if(window.clipboardData) {
          var txt = window.clipboardData.getData("Text");
      }else {
          this.$message.warning('浏览器版本过低')
      }
    }
    document.οnkeydοwn=function(event){   
        var e = event || window.event || arguments.callee.caller.arguments[0];   
       
        if (e.keyCode == 86 && e.ctrlKey) {
            this.ctInfo = this.ctInfo + this.clipboardData;
        }  
    };
  },
};
</script>
<style lang="less" scoped>
</style>