<template>
  <div class="DrawerToView">
    <a-drawer
      title="查看合约"
      placement="right"
      :closable="false"
      :visible="visible"
      :width="1057"
      :after-visible-change="afterVisibleChange"
      @close="onClose"
    >
      <div class="toview">
        <div class="toview-lf">
          <a-descriptions :column="2">
            <a-descriptions-item label="工程名">
              {{ ContractAll.ctCode }}
            </a-descriptions-item>
            <a-descriptions-item label="所属联盟链">
              {{ ContractAll.groupName }}
            </a-descriptions-item>
            <a-descriptions-item label="版本号">
              {{ ContractAll.versionCode }}
            </a-descriptions-item>
            <a-descriptions-item label="版本标识"
              >{{ ContractAll.versionTag }}
            </a-descriptions-item>
          </a-descriptions>
          <div class="content">
            <!-- <span>{{ ContractAll.ctInfo }}</span> -->
            <CodemirrorComp
              :ctInfo="ContractAll.ctInfo"
              theme="dracula"
            ></CodemirrorComp>
          </div>
        </div>
        <div class="toview-rg">
          <span class="tit">合约调用示例</span>
          <a-tabs type="card" @change="callback">
            <a-tab-pane
              v-for="(item, index) in MainIdlist"
              :key="index"
              :tab="item.language"
            >
              <div
                class="info"
                :style="{ height: show ? '280px' : content_height }"
              >
                <!-- <CodemirrorComp
                  :ctInfo="item.info"
                  theme="base16-light"
                ></CodemirrorComp> -->
                <MarkdownIt :value="item.info" />
              </div>
            </a-tab-pane>
          </a-tabs>
          <div v-if="show">
            <span class="tit" style="margin-top: 49px">合约调试</span>
            <a-descriptions :column="2">
              <a-descriptions-item label="链名">
                <el-input
                  style="width: 160px; margin-left: 11px"
                  v-model="itemValue.groupCode"
                  disabled
                />
              </a-descriptions-item>
              <a-descriptions-item label="合约工程名">
                <el-input
                  style="width: 124px"
                  v-model="itemValue.ctCode"
                  disabled
                />
              </a-descriptions-item>
            </a-descriptions>
            <div style="display: flex">
              <div style="width: 60px">助记词:</div>
              <a-textarea
                v-model="form.mnemonic"
                placeholder="请输入"
                :rows="2"
              />
            </div>
            <div class="aMethodIsCall">
              <div>调用方法</div>
              <div>
                <a-space>
                  <!-- <a-icon type="redo" /> -->
                  <a-icon @click="show_add_modal" type="plus" />
                </a-space>
              </div>
            </div>
            <div>
              <a-collapse
                v-for="(item, index) in listFunc"
                :key="index + 1"
                v-model="activeKey"
                @change="changeActivekey($event, item, index + 1)"
                :expand-icon-position="expandIconPosition"
              >
                <a-collapse-panel
                  :key="JSON.stringify(index + 1)"
                  :header="index + 1 + `.` + item.ctFuncName"
                  ><template slot="extra">
                    <a @click="getcontractFunc_removeContractFunc($event, item)"
                      >删除</a
                    ></template
                  >

                  <a-form-model
                    v-if="item.params"
                    :layout="form.layout"
                    :model="form"
                  >
                    <a-form-model-item
                      v-for="(item1, index1) in item.params"
                      :key="index1"
                      :label="item1.type == 'show' ? '' : item1.name + `:`"
                    >
                      <el-input
                        v-if="item1.name"
                        size="small"
                        v-model="item1.value"
                        placeholder="请输入"
                      />
                      <div
                        v-if="
                          item.params.length &&
                            item.params[0] &&
                            !item.params[0]['ctHash'] &&
                            item.params[0]['name'] &&
                            index1 === item.params.length - 1
                        "
                        style="text-align: end; margin-top: 16px"
                      >
                        <a-button type="primary" @click="getRequest(item)">
                          请求
                        </a-button>
                      </div>
                      <div>
                        <div
                          v-if="item1.ctHash"
                          style="
                            display: flex;
                            margin-bottom: 12px;
                            font-size: 12px;
                            font-family: PingFangSC-Regular, PingFang SC;
                            font-weight: 400;
                            color: rgba(0, 0, 0, 0.85);
                          "
                        >
                          交易哈希:{{ item1.ctHash | getSubStr
                          }}<CopyComp
                            :tit="item1.ctHash"
                            :valuetext="item1.ctHash"
                          />
                        </div>
                        <div v-if="item1.jsonValue" class="viewer-css">
                          <json-viewer
                            :value="item1.jsonValue"
                            :expand-depth="5"
                            copyable
                            boxed
                            sort
                          ></json-viewer>
                        </div>
                      </div>
                    </a-form-model-item>
                  </a-form-model>
                </a-collapse-panel>
              </a-collapse>
            </div>
          </div>
        </div>
      </div>

      <div>
        <!-- //添加 -->
        <a-modal
          v-model="visibleAdd"
          ok-text="确认"
          cancel-text="取消"
          centered
          title="添加调用方法"
          @ok="onSubmit"
          @cancel="getClose"
        >
          <a-form-model
            ref="ruleForm"
            :model="form"
            :rules="rules"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
          >
            <a-form-model-item label="是否为查询:">
              <a-select v-model="query">
                <a-select-option value="true"> true </a-select-option>
                <a-select-option value="false"> false </a-select-option>
              </a-select>
            </a-form-model-item>

            <a-form-model-item label="方法名:" prop="ctFuncName">
              <el-input
                size="small"
                v-model="form.ctFuncName"
                placeholder="请输入"
              />
            </a-form-model-item>
            <a-form-model-item label="参数名:">
              <a-space>
                <el-input
                  size="small"
                  v-model="form.valueName"
                  placeholder="请输入"
                />

                <a @click="getAdd">添加</a>
                <a @click="getBatchAdd">批量添加</a>
              </a-space>
            </a-form-model-item>
          </a-form-model>
          <div style="margin-left: 80px">
            <a-tag
              @close="log(item)"
              v-for="item in arrlist"
              :key="item"
              closable
              >{{ item }}
            </a-tag>
          </div>
        </a-modal>

        <a-modal
          v-model="isMethods"
          title="添加调用方法"
          ok-text="确认"
          cancel-text="取消"
          @ok="getMethods"
          :centered="true"
        >
          <a-textarea
            v-model="value"
            @change="getenter"
            placeholder="请输入"
            :auto-size="{ minRows: 20, maxRows: 20 }"
          />
        </a-modal>
      </div>
    </a-drawer>
  </div>
</template>
<script>
import {
  ct_info,
  ctm_getByCtMainId,
  contractFunc_listFunc,
  contractFunc_createContractFunc,
  ct_invokeContract,
  contractFunc_removeContractFunc,
} from '@/utils/Contact'
import CodemirrorComp from '@/components/CodemirrorComp'
import MarkdownIt from '@/components/MarkdownIt'
// 引入组件
import JsonViewer from 'vue-json-viewer'
export default {
  components: { CodemirrorComp, JsonViewer, MarkdownIt },

  props: {
    //弹窗组件是否显示 默认不显示 必传属性
    isToView: {
      type: Boolean,
      default: false,
      required: true,
    },
    show: {
      type: Boolean,
      default: false,
      required: true,
    },
    itemValue: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      jsonValue: '',
      cmOption: {
        tabSize: 2, // tab
        styleActiveLine: true, // 高亮选中行
        lineNumbers: true, // 显示行号
        styleSelectedText: true,
        line: true,
        foldGutter: true, // 块槽
        scrollbarStyle: null,
        gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
        highlightSelectionMatches: { showToken: /\w/, annotateScrollbar: true }, // 可以启用该选项来突出显示当前选中的内容的所有实例
        mode: {
          // 模式, 可查看 codemirror/mode 中的所有模式
          name: 'javascript',
          json: true,
        },
        // hint.js options
        hintOptions: {
          // 当匹配只有一项的时候是否自动补全
          completeSingle: false,
        },
        // 快捷键 可提供三种模式 sublime、emacs、vim
        keyMap: 'sublime',
        matchBrackets: true,
        showCursorWhenSelecting: true,
        theme: 'dracula', // 主题
        extraKeys: { Ctrl: 'autocomplete' }, // 可以用于为编辑器指定额外的键绑定，以及keyMap定义的键绑定
      },
      value: '',
      labelCol: { span: 4 },
      wrapperCol: { span: 15 },
      other: '',
      rules: {
        ctFuncName: [
          {
            required: true,
            message: '请输入方法名',
            trigger: 'change',
          },
        ],
      },
      ContractAll: {},
      content_height: '',
      expandIconPosition: 'right',
      form: {
        layout: 'vertical',
        ctId: '',
        valueName: '',
        params: [],
        mnemonic: '',
        detailsList: {},
      },
      formBackup: {
        layout: 'vertical',
        ctId: '',
        valueName: '',
        params: [],
        mnemonic: '',
        detailsList: {},
      },
      query: 'false',

      hash: '11111',
      MainIdlist: {},
      activeKey: ['-1'],
      listFunc: '',
      visibleAdd: false,
      arrlist: [],
      isMethods: false,
      arr: '',
    }
  },
  methods: {
    // 批量添加
    getBatchAdd() {
      this.value = ''
      this.isMethods = true
    },
    getMethods() {
      this.isMethods = false
      var strs = new Array() //定义一数组
      strs = this.arr.split(',') //字符分割
      let r = strs.filter((item) => {
        return item.length > 0
      })
      this.arrlist = [...this.arrlist, ...r]
      this.arrlist = [...new Set(this.arrlist)]
    },
    getenter(e) {
      this.arr = e.target.value.replace(/\n/g, ',')
    },
    async log(e) {
      this.arrlist.map((item, index) => {
        if (e == item) {
          this.arrlist.splice(index, 1)
        }
      })
    },
    //请求
    async getRequest(item) {
      this.form.params = []
      this.form.ctId = this.itemValue.ctId
      this.form.methodName = item.ctFuncName
      // this.form.query = item.query;
      item.params.map((i) => {
        if (i.name) {
          this.form.params.push({
            paramName: i.name,
            value: i.value,
          })
        }
      })
      let res = await ct_invokeContract(this.form, 'application/json')
      if (res.data.code == 200) {
        item.params[item.init_len] = {
          ctHash: res.data.data.ctHash,
          type: 'show',
          data: res.data.data.data,
          jsonValue: res.data.data,
        }
        item.params = JSON.parse(JSON.stringify(item.params))
      } else {
        this.$message.error(res.data.msg)
      }
      item.params.map((item1) => {
        if (item1.value) {
          item1.value = null
        }
      })
    },
    //获取手风琴的key 打开手风琴
    async changeActivekey(keys, item, curidx) {
      this.form = this.formBackup
      this.form.params = []
      let temp_hash = null
      this.form.methodName = item.ctFuncName
      if (keys.findIndex((it) => Number(it) === curidx) !== -1) {
        item.params.map((t_it, index) => {
          //初始化cthash
          if (t_it['ctHash']) {
            item.params.splice(index, 1)
          }
        })
        if (item.params.length) return

        let res = await ct_invokeContract(this.form, 'application/json')
        if (res.data.code == 200) {
          temp_hash = res.data.data.ctHash
          item.params.push({
            ctHash: temp_hash,
            type: 'show',
            data: res.data.data.data,
            jsonValue: res.data.data,
          })
        } else {
          this.$message.warning(res.data.msg)
        }
      }
    },
    //获取合约详情
    async getct_invokeContract() {
      let res = await ct_invokeContract(this.form, 'application/json')
      if (res.data.code == 200) {
        // this.listFunc = res.data;
      }
    },
    //查询合约列表 手风琴
    async getcontractFunc_listFunc() {
      this.form.ctId = this.itemValue.ctId
      let temp = { ...this.form }
      delete temp.params
      let res = await contractFunc_listFunc(temp)
      this.listFunc = res.data.data.map((item) => {
        return { ...item, init_len: item.params.length }
      })
    },
    //删除
    async getcontractFunc_removeContractFunc(event, item) {
      //阻止手风琴的展开
      event.stopPropagation()
      let res = await contractFunc_removeContractFunc({ funcId: item.id })
      if (res.data.code == 200) {
        this.$message.success('删除成功')
        this.getcontractFunc_listFunc()
      } else {
        this.$message.warning(res.data.msg)
      }
    },
    getClose() {
      this.arrlist = []
    },
    show_add_modal() {
      this.visibleAdd = true
      this.form = {}
    },
    // 添加
    getAdd() {
      if (!this.form.valueName) {
        this.$message.warning('参数名不能为空')
        return
      }
      if (this.arrlist.length <= 0) {
        this.arrlist.push(this.form.valueName)
        this.form.valueName = null
      } else {
        for (var i = 0; i < this.arrlist.length; i++) {
          //如果返回结果为-1（<0）证明新数组this.form.nodeAddressArra中没有这个元素，则把元素添加到新数组中
          if (this.arrlist.indexOf(this.form.valueName) < 0) {
            this.arrlist.push(this.form.valueName)
            this.form.valueName = null
            return
          }
        }
        this.$message.warning('请勿重复添加')
      }
    },
    onSubmit() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          this.form.params = this.arrlist
          this.form.ctId = this.itemValue.ctId
          this.form.query = this.query
          let res = await contractFunc_createContractFunc(
            this.form,
            'application/json'
          )
          if (res.data.code == 200) {
            // this.form.params = null;
            this.visibleAdd = false
            this.arrlist = []
          }
          this.getcontractFunc_listFunc()
          this.form = {}
        } else {
          console.log('error submit!!')
          this.form = {}
          return false
        }
      })
    },
    resetForm() {
      this.$refs.ruleForm.resetFields()
    },
    showModal() {
      this.visibleAdd = true
    },

    afterVisibleChange(val) {
      console.log('visible', val)
    },
    showDrawer() {
      this.visible = true
    },
    onClose() {
      this.visible = false
    },
    //抽屉
    callback(key) {
      console.log(key)
    },

    //获取合约内容
    async getct_info() {
      let res = await ct_info({ ctId: this.itemValue.ctId })
      this.ContractAll = res.data.data
    },
    //获取合约模板
    async getctm_getByCtMainId() {
      let res = await ctm_getByCtMainId({ ctMainId: this.itemValue.ctMainId })
      this.MainIdlist = res.data.data
    },
  },
  computed: {
    visible: {
      get() {
        return this.isToView
      },
      set(val) {
        this.$emit('update:isToView', val)
      },
    },
  },
  watch: {
    // activeKey(key) {
    // console.log(key);
    // if(key[1]==)
    // },
  },
  created() {
    this.form.ctId = this.itemValue.ctId
    this.formBackup.ctId = this.itemValue.ctId
    this.content_height =
      Math.max(document.documentElement.offsetHeight) - 225 + 'px'
    this.getct_info()
    this.getctm_getByCtMainId()
    this.getcontractFunc_listFunc()
  },
}
</script>
<style lang="scss">
.viewer-css {
  .jv-container .jv-code.boxed {
    max-height: 185px !important;
    overflow: auto;
    scrollbar-width: none; /* Firefox */
    -ms-overflow-style: none; /* IE 10+, edge */
    &::-webkit-scrollbar {
      display: none; /* Chrome Safari */
      // 或者 width: 0;
    }
  }
}

.DrawerToView {
  padding: 24px;
}
.toview {
  display: flex;
  justify-content: space-between;
  .toview-lf {
    width: 47%;
    // border-right: 1px solid;
    .content {
      width: 480px;
      overflow: overlay;
      height: calc(80vh);
      background: #232733;
      border-radius: 2px;
      color: $color-primary;
    }
    .content::-webkit-scrollbar {
      display: none;
    }
  }
  .toview-rg {
    width: 47%;
    .tit {
      display: inline-block;
      font-size: 16px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 600;
      color: rgba(0, 0, 0, 0.85);
      margin-bottom: 17px;
    }
    .tit:before {
      content: '';
      border-left: 4px solid #007aff;
      margin-right: 16px;
    }
    .info {
      overflow: auto;
    }
    .info::-webkit-scrollbar {
      display: none;
    }
  }
  .aMethodIsCall {
    display: flex;
    justify-content: space-between;
    margin: 16px 0;
  }
}
.prompt {
  color: #f5222d;
  font-size: 12px;
}
.toview-rg {
  .ant-tabs-bar {
    margin: 0px;
  }

  .ant-tabs .ant-tabs-top-content,
  .ant-tabs .ant-tabs-bottom-content {
    min-height: 100%;
    //  background: red;
    border-left: 1px solid $color-divider;
    border-bottom: 1px solid $color-divider;
    border-right: 1px solid $color-divider;
  }

  .ant-tabs.ant-tabs-card .ant-tabs-card-content > .ant-tabs-tabpane,
  .ant-tabs.ant-tabs-editable-card .ant-tabs-card-content > .ant-tabs-tabpane {
    padding: 16px;
  }

  .ant-row {
    margin-bottom: 5px;
  }

  .ant-form-inline .ant-form-item {
    margin-right: 0px;
  }

  .ant-collapse {
    margin-bottom: 16px;
  }
}
</style>
