import { message } from "ant-design-vue";
import {getSessionStorage} from '../utils/util'
export function copy(text) {
    let visl_dom_inp = document.createElement('textarea'), dom = null, res = null, _message = {};
    visl_dom_inp.id = `copy_input`;
    visl_dom_inp.value = text;
    visl_dom_inp.style.opacity = 0;
    document.body.appendChild(visl_dom_inp);
    dom = document.getElementById('copy_input');
    dom.select(); // 选择对象
    document.execCommand("Copy");
    res = document.body.removeChild(dom);
    if (res) {
        _message = {
            type: 'success',
            text: '复制成功'
        };
    } else {
        _message = {
            type: 'error',
            text: '复制失败'
        };
    }
    message[_message.type](_message.text);
    return;
}

//倒计时
export function numAdd(num1, num2) {
    var baseNum, baseNum1, baseNum2;
    try {
        baseNum1 = num1.toString().split(".")[1].length;
    } catch (e) {
        baseNum1 = 0;
    }
    try {
        baseNum2 = num2.toString().split(".")[1].length;
    } catch (e) {
        baseNum2 = 0;
    }
    baseNum = Math.pow(10, Math.max(baseNum1, baseNum2));
    return (num1 * baseNum + num2 * baseNum) / baseNum;
}
// 防抖
export function _debounce(fn, delay) {
    var delay = delay || 200;
    var timer;
    return function () {
        var th = this;
        var args = arguments;
        if (timer) {
            clearTimeout(timer);
        }
        timer = setTimeout(function () {
            timer = null;
            fn.apply(th, args);
        }, delay);
    };
}
// 节流
export function _throttle(fn, interval) {
    var last;
    var timer;
    var interval = interval || 200;
    return function () {
        var th = this;
        var args = arguments;
        var now = +new Date();
        if (last && now - last < interval) {
            clearTimeout(timer);
            timer = setTimeout(function () {
                last = now;
                fn.apply(th, args);
            }, interval);
        } else {
            last = now;
            fn.apply(th, args);
        }
    }
}
