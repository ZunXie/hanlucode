import { postAction, getAction, deleteAction, putAction } from './request';
import { setSessionStorage } from "@/utils/util";
import store from "@/store/index";

// 登录
export async function loginPassword(param) {
    return postAction('/login/password', param, undefined, true);
}

// 获取节点数量
export async function getNodeNum() {
    return getAction('/chainNode/getNodeNum', undefined, true);
}

//获取节点列表
export async function chainNode_list(param) {
    return postAction('/chainNode/list', param, undefined, true);
}

// 停止节点
export async function chainNode_stopNode(param) {
    return postAction('/chainNode/stopNode', param, undefined, true);
}
//启动节点
export async function chainNode_startNode(param) {
    return postAction('/chainNode/startNode', param, undefined, true);
}
//更新P2p地址
export async function chainNode_saveP2p() {
    return postAction('/chainNode/saveP2p', undefined, true);
}
//部署节点
export async function chainNode_creatNode(param) {
    return postAction('/chainNode/creatNode', param, undefined, true);
}
//修改备注
export async function chainNode_updateRemarkById(param) {
    return postAction('/chainNode/updateRemarkById', param, undefined, true);
}
export async function chainGroup_list(param) {
    return getAction('/chainGroup/list', param, true);
}
//绑定节点
export async function chainNode_bindNode(param) {
    return postAction('/chainNode/bindNode', param, undefined, true);
}
//获取已部署的合约数量
export async function ct_getDeployedContractNum() {
    return getAction('/ct/getDeployedContractNum', undefined, true);
}

//获取已部署联盟链数量
export async function chainGroup_countChainGroupNum() {
    return getAction('/chainGroup/countChainGroupNum', undefined, true);
}
//获取平行链列表（全部）
export async function chainGroup_all(param) {
    return new Promise((resolve, reject) => {
        getAction('/chainGroup/all', param, true).then(res => {
            if (res.data.code == 200) {
                setSessionStorage("groupCodeList", res.data.data);
                store.commit("MODIFYNAME", res.data.data);
            }
            resolve(res);
        }, err => {
            reject(err);
        });
    })
}
//导出节点私钥
export async function chainGroup_getMnemonicByNodeId(param) {
    return getAction('/chainNode/getMnemonicByNodeId', param, true);
}
//移除节点
export async function chainNode_removeNode(param, header) {
    return postAction('/chainNode/removeNode', param, header, true);
}
//获取用户主钱包 (燃料)
export async function chainAccount_getMain() {
    return getAction('/chainAccount/getMain', undefined, true);
}
//子账户列表
export async function user_list(param) {
    return postAction('/user/list', param, undefined, true);
}
//公司配置信息
export async function api_config_info(param) {
    return getAction('/api/config/info', param, true);
}
//更新组织名称
export async function user_saveOrg(param, header) {
    return postAction('/user/saveOrg', param, header, true);
}
//更新用户钱包私钥
export async function chainAccount_updateMnemonic(param) {
    return postAction('/chainAccount/updateMnemonic', param, undefined, true);
}
// 删除账户
export async function user_delectUser(param) {
    return postAction('/user/delectUser', param, undefined, true);
}
//查询所有链的权限
export async function userGroupPermission_list() {
    return getAction('/userGroupPermission/list', undefined, true);
}
//查询对应用户的链权限信息
export async function userGroupPermission_listByUserId(param) {
    return getAction('/userGroupPermission/listByUserId', param, true);
}
//创建子账号
export async function user_creatUserd(param, header) {
    return postAction('/user/creatUser', param, header, true);
}
// 更新子账号权限
export async function user_saveGroupPower(param, header) {
    return postAction('/user/saveGroupPower', param, header, true);
}
//更新子账号备注
export async function user_saveRemark(param) {
    return postAction('/user/saveRemark', param, undefined, true);
}
//校验用户密码
export async function user_verifyPassword(param) {
    return postAction('/user/verifyPassword', param, undefined, true);
}
// /更新用户密码
export async function user_savePassword(param) {
    return postAction('/user/savePassword', param, undefined, true);
}
//退出登录
export async function user_loginOut(param) {
    return postAction('/user/loginOut', param, undefined, true);
}
//获取用户详情
export async function user_info(param) {
    return getAction('/user/info', param, true);
}
//创建平行链
export async function chainGroup_create(param) {
    return postAction('/chainGroup/create', param, undefined, true);
}
//获取单个节点的状态
export async function chainNode_getStatusByIdt() {
    return getAction('/chainNode/getStatusById', undefined, true);
}
//测试连接
export async function chainGroup_testSSH(param) {
    return postAction('/chainServer/testSSH', param, undefined, true);
}
// 上传logo
export async function user_uploadLogo(param, header) {
    return postAction('/user/uploadLogo', param, header);
}

// 试用账户
export async function tourists_getTourists(param) {
    return getAction('/tourists/getTourists', param, true);
}

// 获取是否要显示引导流程
export async function user_shouldShowBootProcess(param) {
    return getAction('/user/shouldShowBootProcess', param, true);
}
// 不再显示引导流程
export async function user_neverShowBootProcess(param) {
    return postAction('/user/neverShowBootProcess', param, undefined, true);
}