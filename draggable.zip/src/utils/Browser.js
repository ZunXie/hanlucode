import { postAction, getAction, deleteAction, putAction } from './request';
//浏览器基本信息
export async function chainGroup_browInfo(params) {
    return getAction('/chainGroup/browInfo',params,undefined,false);
}
//创建新合约
export async function ct_creatCt(params) {
    return postAction('/ct/creatCt',params,undefined,false);
}
//获取合约语言类型集合
export async function ct_getCtTypeSet(params) {
    return getAction('/ct/getCtTypeSet',params);
}
//发布合约
export async function  ct_sendCt(params) {
    return postAction('/ct/sendCt',params);
}
// 删除合约
export async function  ct_delect(params) {
    return postAction('/ct/delect',params);
}
//区块详情查询
export async function  chainGroup_getBlockHeight(params) {
    return postAction('/chainGroup/getBlockHeight',params);
}
//联盟链浏览器查询
export async function  chainGroup_browQuery(params) {
    return postAction('/chainGroup/browQuery',params);
}
//提交合约开发版本
export async function  ct_creatCtVersions(params) {
    return postAction('/ct/creatCtVersions',params);
}
// 创建并发布新合约
export async function  ct_creatAndSendCt(params) {
    return postAction('/ct/creatAndSendCt',params);
}