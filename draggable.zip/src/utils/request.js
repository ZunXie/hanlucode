import axios from "axios";
import qs from 'qs'
const baseURL = "http://192.168.3.101:9987"
// const baseURL = "https://baas-v2-demo.chaojigongshi.com"

const apiURL = '/api'
import { getSessionStorage } from "@/utils/util";
import { message } from 'ant-design-vue';
import Router from '../router/index'
import store from "../store/index"

//post
export function postAction(url, parameter, header, status) {
    if (url.split("/").includes("user")) {
        return axios({
            url: `${baseURL}${apiURL}${url}`,
            method: 'post',
            data: parameter,
            headers: {
                'Content-Type': header ? header : 'application/x-www-form-urlencoded'
            }
        })
     }
    let groupCodeList = getSessionStorage('groupCodeList');
    if (status || groupCodeList && groupCodeList.length > 0) {
        return axios({
            url: `${baseURL}${apiURL}${url}`,
            method: 'post',
            data: parameter,
            headers: {
                'Content-Type': header ? header : 'application/x-www-form-urlencoded'
            }
        })
    }
    else {
        return Promise.reject();
    }
}

//put
export function putAction(url, parameter) {
    let groupCodeList = getSessionStorage('groupCodeList');
    if (groupCodeList && groupCodeList.length > 0)
        return axios({
            url: `${baseURL}${apiURL}${url}`,
            method: 'put',
            data: parameter
        })
    else return Promise.reject();
}

//get
export function getAction(url, parameter, status) {
    let groupCodeList = getSessionStorage('groupCodeList');
    if (status || groupCodeList && groupCodeList.length > 0) {
        return axios({
            url: `${baseURL}${apiURL}${url}`,
            method: 'get',
            params: parameter,
            headers: {
                'Content-Type': 'application/json'
            }
        })
    }
    else {
        return Promise.reject();
    }
}
//deleteAction
export function deleteAction(url, parameter) {
    return axios({
        url: `${baseURL}${apiURL}${url}`,
        method: 'delete',
        params: parameter
    })
}

//自动给同一个vue项目的所有请求添加请求头
axios.interceptors.request.use(function (config) {
    let token = getSessionStorage('token');
    config.data = config.headers['Content-Type'] == 'application/x-www-form-urlencoded' ? qs.stringify(config.data) : config.data
    if (token) {
        config.headers['X-Requested-Token'] = token;
    }

    return config;
})

axios.interceptors.response.use(function (response) {
    //获取相应结果 根据相应结果进行判断 
    const { data: data } = response;
    if (response.data.code == 202 || response.data.code == 201) {
        message.destroy()
        message.warning(data.msg);
        Router.push({ path: '/login' });
    }
    return response
}, function (error) {
    return Promise.reject(error)
});
axios.interceptors.request.use(function (config) {
    store.state.loadding = true; //在请求发出之前进行一些操作
    return config
}, function (error) {
    return Promise.reject(error)
});
axios.interceptors.response.use(function (response) {
    store.state.loadding = false;//在这里对返回的数据进行处理
    return response
}, function (error) {
    return Promise.reject(error)
})
export default axios