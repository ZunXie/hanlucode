import { postAction, getAction, deleteAction, putAction } from './request';
// 条件查询 用户日志
export async function user_userlog_list(param) {
    return postAction('/user/userlog/list',param);
}
// 获取节点地域分布列表 地图
export async function chainNode_listCityNodeList(param) {
    return getAction('/chainNode/listCityNodeList',param,false);
}