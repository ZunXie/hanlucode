import { postAction, getAction, deleteAction, putAction } from './request';
//获取节点列表
export async function chainGroup_nodes(param) {
    return getAction('/chainGroup/nodes', param,false);
}
// 获取平行链的管理员节点列表
export async function chainNode_listAdminNodesByGroupCode(param) {
    return getAction('/chainNode/listAdminNodesByGroupCode', param, false);
}
//根据编号查询详情
export async function chainGroup_detail(param) {
    return getAction('/chainGroup/detail', param, false);
}
//获取平行链正在使用的节点列表
export async function chainNode_listVerifyNodesByGroupCode(param) {
    return getAction('/chainNode/listVerifyNodesByGroupCode', param, false);
}
//获取平行链正在使用的节点列表
export async function chainNode_listUsingNodesByGroupCode(param) {
    return getAction('/chainNode/listUsingNodesByGroupCode', param, false);
}
//获取平行链未使用的节点列表
export async function chainNode_listUnusedNodesByGroupCode(param) {
    return getAction('/chainNode/listUnusedNodesByGroupCode', param);
}
//添加节点
export async function chainGroup_addNode(param) {
    return postAction('/chainGroup/addNode', param, undefined, true);
}

//移除节点
export async function chainGroup_subNode(param) {
    return postAction('/chainGroup/subNode', param, undefined, true);
}
//根据节点id修改运营方信息
export async function chainNode_updateOperatorById(param) {
    return postAction('/chainNode/updateOperatorById', param, undefined, true);
}
//更新平行链名称
export async function chainGroup_updateName(param) {
    return postAction('/chainGroup/updateName', param, undefined, true);
}
//根据节点id修改备注
export async function chainNode_updateRemarkById(param) {
    return postAction('/chainNode/updateRemarkById', param, undefined, true);
}
//根据节点id修改服务器ip
export async function chainNode_updateIp(param) {
    return postAction('/chainNode/updateIp', param, undefined, true);
}
// 添加节点(通过地址)
export async function chainGroup_addNodeByAddress(param) {
    return postAction('/chainGroup/addNodeByAddress', param, undefined, true);
}
// /批量增加节点
export async function chainGroup_batchAddNode(param, header) {
    return postAction('/chainGroup/batchAddNode', param, header, true);
}