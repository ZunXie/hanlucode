import { postAction, getAction, deleteAction, putAction } from './request';
//获取数据上链状态
export async function open_base_getTxStatus(param) {
    return postAction('/open/base/getTxStatus', param,true);
}
//获取服务的api文档信息
export async function open_base_getAPiDocs(param) {
    return getAction('/open/base/getAPiDocs', param,true);
}