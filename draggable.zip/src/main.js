import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Antd from 'ant-design-vue'
import plugins from './plugins'
Vue.config.productionTip = false
import 'ant-design-vue/dist/antd.css'
import 'element-ui/lib/theme-chalk/index.css'
import echarts from 'echarts'
import JsonViewer from 'vue-json-viewer'
import Empty from '@/components/Empty'
import Paginationcom from '@/components/Paginationcom'
import Navigation from '@/components/Navigation'
import CopyComp from '@/components/CopyComp'
import axios from './utils/request'

import StatusColor from '@/components/StatusColor'
import '../src/assets/font/iconfont.css'
import { setSessionStorage, getSessionStorage } from './utils/util'
Vue.prototype.setSessionStorage = setSessionStorage
Vue.prototype.getSessionStorage = getSessionStorage
import { Input, InputNumber } from 'element-ui'

// 全局组件
import MTable from '@/components/mTable/index.vue'
Vue.component('m-table', MTable)

Vue.use(Input)
Vue.use(InputNumber)
// 注册为全局组件
Vue.component('Empty', Empty)
Vue.component('Paginationcom', Paginationcom)
Vue.component('Navigation', Navigation)
Vue.component('CopyComp', CopyComp)
Vue.component('StatusColor', StatusColor)
import { DatePicker, TimeSelect, TimePicker } from 'element-ui'
// 注册全局过滤器
import * as filters from './utils/filters'
Object.keys(filters).forEach((key) => {
  Vue.filter(key, filters[key])
})
Vue.prototype.$echarts = echarts
Vue.config.productionTip = false
Vue.prototype.$ajax = axios

Vue.use(Antd)
Vue.use(JsonViewer)

Vue.use(plugins)
Vue.use(DatePicker, TimeSelect, TimePicker)
new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app')
Vue.prototype.setitem_event = create_setitem_event()
function create_setitem_event() {
  let func_arr = []

  window.addEventListener('setItem', (e) => {
    func_arr.map((item) => {
      if (typeof item.func === 'function') {
        item.func(e)
      }
    })
  })

  function add(func_obj) {
    if (typeof func_obj.func === 'function') {
      let exits = false
      func_arr.map((item) => {
        if (func_obj.key == item.key) {
          item.func = func_obj.func
          exits = true
        }
      })
      if (!exits) func_arr.push(func_obj)
    }
  }
  function del(key) {
    func_arr.map((item, index) => {
      if (item.key === key) {
        func_arr.splice(index, 1)
      }
    })
  }
  return {
    add,
    del,
  }
}

Vue.prototype.resetSetItem = function(key, newVal) {
  if (key === 'groupCode') {
    // 创建一个StorageEvent事件
    var newStorageEvent = document.createEvent('StorageEvent')
    const storage = {
      setItem: function(k, val) {
        sessionStorage.setItem(k, val)
        // 初始化创建的事件
        newStorageEvent.initStorageEvent(
          'setItem',
          false,
          false,
          k,
          null,
          val,
          null,
          null
        )
        // 派发对象
        window.dispatchEvent(newStorageEvent)
      },
    }
    return storage.setItem(key, newVal)
  }
}
