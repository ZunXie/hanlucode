import Vue from "vue";
import Vuex from "vuex";
import getters from "./getters";
if (!window.VueRouter) {
  Vue.use(Vuex);
}

export default new Vuex.Store({
  getters,
  state: {
    groupCode: {},
    changeIndent: 0,
    groupCode: {},
    groupCodeNEW: '',
    chainGroup_create: 0,
    deploymentOf: 0,
    disabled: '',
    imageUrl: '',
    name: "",
    modifyName: 0,
    user_creatUser: 0,
    loadding: false,
    loaddingShow:false
  },
  mutations: {
    GROUP_CODE: (state, data) => {
      state.groupCode = data;
    },
    CHANGE_DATA: (state, data) => {
      state.changeIndent = data
    },
    GROUP_CODE: (state, data) => {
      state.groupCode = data
    },
    GROUP_CODEMEW: (state, data) => {
      state.groupCodeNEW = data
    },
    CHAINGROUP_CREATE: (state, data) => {
      state.chainGroup_create = data
    },
    DEPLOOY_MENTOF: (state, data) => {
      state.deploymentOf = data
    },
    DISABLED: (state, data) => {
      state.disabled = data
    },
    IMAGEURL: (state, data) => {
      state.imageUrl = data
    },
    NAME: (state, data) => {
      state.name = data
    },
    MODIFYNAME: (state, data) => {
      state.modifyName = data
    },
    USER_CREATUSER: (state, data) => {
      state.user_creatUser = data
    },
    showloadding(state, data) {
      state.loadding = data
    },
    LOADDING_SHOW(state, data) {
      state.loaddingShow = data
    }
  },
  // 可以用store.dispatch来调用
  actions: {
    setloadding(context,load){
      context.commit("showloadding",load);
    }
  },
  getters: {
    isloading:(state)=>{
      return state.loadding
    }
  }
});
