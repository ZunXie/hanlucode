export const goToBrowser = {
    data() {
        return {
            keyArr: [],
            keyArrapi: []
        }
    },
    methods: {
        goToBrowserAddr() {
            window.open("https://chaojigongshi.gitbook.io/docs/");
        },
        goback() {
            this.$router.go(-1);
        },
        goHelp() {
            this.$router.push({
                path: "/developerApi"

            });
        },
        getkey(val) {
            let arr = this.getSessionStorage("defaultActive");
            if (arr) {
                let a = "";
                arr.map((item) => {
                    for (let key in item) {
                        if (key == val) {
                            a = item[key];
                        }
                    }
                });
                console.log(a);
            }

        },
        getkeyapi(val) {
            let arr = this.getSessionStorage("defaultActiveApi");
            if (arr) {
                let a = "";
                arr.map((item) => {
                    for (let key in item) {
                        if (key == val) {
                            a = item[key];
                        }
                    }
                });
                return a
            }

        },
        callback(key) {
            let keyArr = [];
            keyArr.push({ privateKeyEscrowkey: key });
            this.setSessionStorage("defaultActive", keyArr);
            this.apikey = 1;
            sessionStorage.removeItem("defaultActiveApi");
        },
        callbackApi(key) {
            let keyArrapi = [];
            keyArrapi.push({ apikey: key });
            this.setSessionStorage("defaultActiveApi", keyArrapi);
        },
        getinit() {
            this.privateKeyEscrowkey = this.getkey("privateKeyEscrowkey")
                ? this.getkey("privateKeyEscrowkey")
                : 1;
            this.apikey = this.getkeyapi("apikey") ? this.getkeyapi("apikey") : 1;
        },
        getremove() {
            sessionStorage.removeItem("defaultActive");
            sessionStorage.removeItem("defaultActiveApi");
        }
    }
}