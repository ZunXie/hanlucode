import { get, post, deleted, put } from '/@/utils/http/axios';

const newProducts = async () =>
  get<any>({
    url: '/jeecg-mall-applet/v4/api/website/newProductRecommend'
  });

  export { newProducts };