export default [
  {
    path: "/",
    component: () => import('/@/QiaoJiang/views/index.vue'),
  },
  {
    path: "/brief",
    component: () => import('/@/QiaoJiang/views/brief/index.vue'),

  },
  {
    path: "/developmental",
    component: () => import('/@/QiaoJiang/views/developmental/index.vue'),
  },
  {
    path: "/merchandise",
    component: () => import('/@/QiaoJiang/views/product/index.vue'),

  },
  {
    path: "/culture",
    component: () => import('/@/QiaoJiang/views/culture/index.vue'),
  },
  {
    path: "/merchandiseDetail/:type",
    name:"merchandiseDetail",
    component: () => import('/@/QiaoJiang/views/product/detail.vue'),
  },
  { path: '/404', component: () => import('/@/QiaoJiang/views/errorPage/404.vue') },
  //匹配所有路径 vue3不再使用*而是得用正则匹配。
  { path: '/:pathMatch(.*)', redirect: '/404' },
]