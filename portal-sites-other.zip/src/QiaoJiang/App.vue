<template>
  <q-header></q-header>
  <router-view/>
</template>

<script setup lang="ts">

</script>

<style scoped lang="less">
@font-face {
    font-family: "hs";        //自定义字体名称
    src:url("https://static.jinzhuangli.com/staticFile/font/HanSansCN_Normal.otf");       //字体包路径
    font-weight: normal;
    font-style: normal;
}
body{
  user-select:none;
}
</style>
