<template>
  <header>
    <h1>
      <a href="/" alt="qiaoJiang Logo" title="翘匠">翘匠</a>
    </h1>
    <ul class="flex m-0 p-0 pt-31px">
      <li
        class="mr-97px"
        v-for="(item,idx) in menus"
        :key="idx"
        @mouseenter="mouseenter(idx)"
        @mouseleave="mouseleave(idx)"
        @click="viewPage(idx)"
      >{{item.name}}</li>
    </ul>
    <transition
      enter-active-class="animate__animated animate__fadeIn"
      leave-active-class="animate__animated animate__fadeOut"
    >
      <div
      @mouseleave="leaveChild(i)"
        class="child h-90px flex flex-items-center flex-justify-center ftcom-14-400"
        v-show="childMenu.showChild&&childMenu.children.length>0"
      >
        <span
          class="mr-97px cursor-pointer"
          v-for="(item,i) in childMenu.children"
          :key="item.id"
          @click="viewChild(i)"
        >{{item.name}}</span>
      </div>
    </transition>
  </header>
</template>


<script setup lang="ts">
import { getCurrentInstance } from "vue";
const cxt = getCurrentInstance(); //相当于Vue2中的this
const bus = cxt?.appContext.config.globalProperties.$bus;
window.onscroll = function() {
  menus.forEach(e => (e.showChild = false));
};
const menus = reactive<any>([
  {
    name: "品牌简介",
    showChild: false,
    children: [],
    path: "/"
  },
  {
    name: "翘匠产品",
    path: "/merchandise",
    showChild: false,
    children: [
      {
        id: "1_0",
        name: "入户门系列",
        path: "/merchandiseDetail/0",
        type: 0
      },
      {
        id: "1_1",
        name: "室内门系列",
        path: "/merchandiseDetail/1",
        type: 1
      }
    ]
  },
  {
    name: "翘匠文化",
    path: "/culture",
    showChild: false,
    children: [
      {
        id: "2_0",
        name: "愿景",
        type: 0
      },
      {
        id: "2_1",
        name: "核心价值观",
        type: 0
      },
      {
        id: "2_3",
        name: "口号",
        type: 1
      },
      {
        name: "使命",
        type: 1
      },
      {
        id: "2_4",
        name: "奋斗目标",
        type: 1
      },
      {
        id: "2_5",
        name: "发展方向",
        type: 1
      }
    ]
  },
  {
    name: "发展历程",
    showChild: false,
    children: [],
    path: "/developmental"
  }
]);
const router = useRouter();
const route = useRoute();
let childMenu = computed(() => {
  let item = menus.find(v => v.showChild);
  return item ? item : {};
});

function leaveChild(){
  menus.forEach(v => (v.showChild = false));

}

async function viewChild(idx: number) {
  const { path, type } = childMenu.value.children[idx];
  if (path) {
    router.push({ path });
    menus.forEach(v => (v.showChild = false));
    window.scrollTo(0, 0);
  } else {
    if(route.path!=path){
      router.push({ path:childMenu.value.path });
    }
    menus.forEach(v => (v.showChild = false));
    await nextTick()
    setTimeout(()=>{
      bus.$emit("clickChild", type);
    },200)
  }
}

function mouseenter(idx: number) {
  for (let i = 0; i < menus.length; i++) {
    if (idx == i) {
      setTimeout(() => {
        menus[i].showChild = true;
      }, 100);
    } else {
      menus[i].showChild = false;
    }
  }
}
function mouseleave(idx: number) {
}

async function viewPage(idx: number) {
  const { path } = menus[idx];
  router.push({ path });
  window.scrollTo(0, 0);
  await nextTick();
  menus.forEach(v => (v.showChild = false));
}
</script>

<style scoped lang="less">
.child {
  position: absolute;
  bottom: -90px;
  width: 100%;
  background-color: #fff;
  border-top: 1px solid #f0f0f0;
  :last-child {
    margin-right: 0;
  }
}
ul {
  list-style: none;
  :last-child {
    margin-right: 0;
  }
  li {
    cursor: pointer;
    font-weight: bold;
  }
}
header {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 147px;
  font-size: 16px;
  position: sticky;
  top: 0;
  z-index: 7;
  background: #fff;
  h1 {
    margin: 0;
  }
  h1 a {
    display: inline-block;
    width: 120px;
    height: 39px;
    background: url(https://static.jinzhuangli.com/staticFile/images/2309182.png)
      no-repeat left top/120px 39px;
    text-indent: -9999px;
    overflow: hidden;
  }
}
</style>