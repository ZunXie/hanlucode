<template>
  <div class="main">
    <transition enter-active-class="animate__animated          
animate__fadeInLeft">
      <div class="img" v-show="showImg">
        <img src="https://static.jinzhuangli.com/staticFile/images/2309159.png" alt />
      </div>
    </transition>
    <div class="change">
      <div @click="viewPre" :class="['change_row',dataList[0].key==0?'color-#999':'']">
        <svg
          width="7"
          height="13"
          viewBox="0 0 7 13"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            id="Vector"
            d="M6.08025 0L6.95619 0.867243L1.74435 6.11481L7 11.3182L6.13148 12.1927L-4.76837e-07 6.12196L6.08025 0Z"
            fill="#AE1F24"
            :fill-opacity="dataList[0].key==0?0.5:1"
          />
        </svg>
        <span>上一个</span>
      </div>
      <div
        :class="['change_row',dataList[dataList.length-1].key==0?'color-#999':'']"
        @click="viewNext"
      >
        <svg
          width="7"
          height="13"
          viewBox="0 0 7 13"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            id="Vector"
            d="M0.919751 0L0.0438149 0.867243L5.25565 6.11481L0 11.3182L0.868517 12.1927L7 6.12196L0.919751 0Z"
            fill="#AE1F24"
            :fill-opacity="dataList[dataList.length-1].key==0?0.5:1"
          />
        </svg>

        <span>下一个</span>
      </div>
    </div>
    <div class="card_box">
      <div>
        <div
          class="card"
          :style="{'transform':`translateX(${500*item.key}px)`,'background':''}"
          v-for="(item,i) in dataList"
          :key="i"
        >
          <transition enter-active-class="animate__animated          
          animate__fadeInUp">
          <div class="card_ani" v-show="item.show">
            <h3>{{item.title}}</h3>
            <p :style="{'transform':`translateX(${i==0?'-15px':'0'})`}">{{item.subTitle}}</p>
            <p>{{item.desc}}</p>
            <img :src="`https://static.jinzhuangli.com/staticFile/images/${item.uri}.png`" alt />
          </div>

          </transition>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup lang="ts">
const dataList = reactive<any>([
  {
    key: 0,
    show: false,
    title: "2018年至今",
    subTitle: "“互联网+翘匠智造”阶段",
    desc:
      "在翘匠制造的基础上引入“互联网+”思维，利用物联网、信息化技术实现产品品质与品牌的双重突破。2022年2月，翘匠商标正式注册，从过往代工模式正式走上自有品牌推广阶段。",
    uri: "2309161",
    color: "red"
  },
  {
    key: 1,
    title: "2015-2018年",
    show: false,

    subTitle: "国际化战略阶段",
    desc:
      "翘匠以“中国制作，国际名牌”为口号，开启国际化战略，通过以国际市场作为发展空间策略，加大产品研发与销售力度，产品远销东南亚、澳洲、中东、欧洲等地区。",
    uri: "2309186",
    color: "pink"
  },
  {
    key: 2,
    title: "2002-2015年",
    show: false,

    subTitle: "代加工阶段",
    desc:
      "翘匠门凭借专业专注的服务态度，以及上乘的品质，产品逐步收到市场认可，并销往国内近百座城市，并成为众多国内一线门业、地产品牌的重要合作伙伴。",
    uri: "2309187",

    color: "skyblue"
  },
  {
    key: 3,
    show: false,

    title: "1902-2002年",
    subTitle: "产品研发阶段",
    desc:
      "1999年，国内房地产行业开始迎来世纪之交的春风，人们对各类家具家居产品有了更高品质与更多元化选择的需求，翘匠初创团队紧跟时代潮流，从家用木门的制造开始，潜心分析市场需要，不断改进产品设计。",
    uri: "2309188",

    color: "green"
  }
]);
const showImg = ref<boolean>(false);
function viewPre() {
  if (dataList[0].key == 0) {
    return;
  }
  for (let i = 0; i < dataList.length; i++) {
    let item = dataList[i];
    item.key += 1;
  }
}
// 查看下一个的时候，全部的key-1
function viewNext() {
  if (dataList[dataList.length - 1].key == 0) {
    return;
  }
  for (let i = 0; i < dataList.length; i++) {
    let item = dataList[i];
    item.key -= 1;
  }
}

onMounted(() => {
  showImg.value = true;
  for (let i = 0; i < dataList.length; i++) {
    let item = dataList[i];
    setTimeout(() => {
      item.show = true;
    }, 500 * i);
  }
});
</script>

<style scoped lang="less">
p,
h3 {
  margin: 0;
  padding: 0;
}
.ani_delay {
  animation-delay: 0.2s !important;
}
.ani_delay_03 {
  animation-delay: 0.3s !important;
}
.ani_delay_04 {
  animation-delay: 0.4s !important;
}
.main {
  min-height: calc(100vh - 147px);
  background-color: #f9fafc;
  width: calc(100% - 330px);
  padding-left: 330px;
  overflow: hidden;
  flex-wrap: nowrap;
  position: relative;
  .card_box {
    width: 100%;
    position: relative;
    min-height: 900px;
    overflow: hidden;
    .card {
      display: inline-block;
      width: 500px;
      min-height: 930px;
      border-left: 1px solid #d0d0d0;
      position: absolute;
      transition: all 0.5s;
      padding: 260px 40px 70px 40px;
      box-sizing: border-box;
      .card_ani {
      }
      h3 {
        color: #ae1f24;
        font-size: 44px;
        padding-bottom: 8px;
      }
      :nth-child(2) {
        color: rgba(174, 31, 36, 0.85);
        font-size: 26px;
        padding-bottom: 134px;
        font-family: hs;
      }
      :nth-child(3) {
        display: flex;
    align-items: end;
        font-size: 14px;
        color: #444444;
        line-height: 28px;
        padding-bottom: 20px;
        font-family: hs;
        height: 112px;
      }
      :nth-child(4) {
        width: 420px;
        height: 228px;
      }
    }
  }
  .img {
    position: absolute;
    top: 100px;
    left: 370px;
    width: 242px;
    height: 80px;
    z-index: 1;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .change {
    position: absolute;
    top: 115px;
    right: 250px;
    font-size: 14px;
    z-index: 1;
    .change_row {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      cursor: pointer;
      svg {
        margin-right: 6px;
      }
      img {
        margin-right: 6px;
        width: 7px;
        height: 12px;
      }
    }
  }
}
</style>