<template>
  <div class="main pb-120px">
    <transition enter-active-class="animate__animated          
animate__fadeInUp">
      <div class="title pt-63px pb-50px" v-show="showTit">
        <img
          class="w-330px h-97px"
          src="https://static.jinzhuangli.com/staticFile/images/23091410.png"
          alt
        />
      </div>
    </transition>
    <div :style="{'height':showTit?0:'214px'}"></div>
    <div class="card_a flex h-580px w-1260px flex-justify-between m-auto">
      <div class="ca_comm ca_left w-412px h-100%">
        <div class="ca_act w-100% h-100% flex flex-justify-center flex-items-center">
          <span>愿景</span>
          <span>引领世界门业潮流</span>
        </div>
      </div>
      <div class="ca_comm ca_right flex flex-justify-center flex-items-center w-824px h-100%">
        <div class="ca_act  w-100% h-100% flex flex-justify-center flex-items-center">
          <span>核心价值观</span>
          <span>用感恩之心待人，用工匠精神处事</span>
        </div>
      </div>
    </div>

     <div class="motto h-350px w-1260px m-auto mt-113px flex br-8">
        <img class="w-840px" src="https://static.jinzhuangli.com/staticFile/images/2309151.png" alt="" />
        <div class="mo_card m_card card_comm w-420px h-100% ">
          <img class="w-40px h-43px" src="https://static.jinzhuangli.com/staticFile/images/2309152.png" alt="" />
          <span class="mt-30px mb-22px h-1px w-16px bg-#999" ></span>
          <span class="ftcom-26-700 color-#666666 pb-15px ">口号</span>
          <span class="color-#666 ftcom-16-700">守护你的一方天地</span>
        </div>
      </div>

      <!-- 目标，使命 发展方向 -->
      <div class="msf w-1260px m-auto mt-24px flex h-326px br-8">
        <div :class="['card_comm  w-420px h-100%',idx==1?'m_card':'o_card']" v-for="(item,idx) in cardList" :key="idx" :style="{'background-image':`url(https://static.jinzhuangli.com/staticFile/images/${item.bg}.png)`}">
          <img class="w-40px h-43px" :src="`https://static.jinzhuangli.com/staticFile/images/${item.icon}.png`" alt="" />
          <span class="mt-30px mb-22px h-1px w-16px bg-#fff" ></span>
          <span class="ftcom-26-700 color-#fff pb-15px ">{{item.name}}</span>
          <span class="color-#fff ftcom-16-700">{{item.desc}}</span>
        </div>
        
      </div>
      <!-- 目标，使命 发展方向 -->

  </div>
</template>


<script setup lang="ts">
import { getCurrentInstance } from "vue";
const cxt = getCurrentInstance(); //相当于Vue2中的this
const bus = cxt.appContext.config.globalProperties.$bus;

console.log('bus',bus)
const showTit = ref<boolean>(false);
const cardList=reactive<any>([
  {
    name:"奋斗目标",
    desc:"国内驰名，国际知名",
    bg:"2309153",
    icon:"2309155"
  },
  {
    name:"使命",
    desc:"让家居更美，让行业更新",
    bg:"2309151",
    icon:"2309156"
  },
  {
    name:"发展方向",
    desc:"走出国门，走向世界",
    bg:"2309154",
    icon:"2309157"
  },
])


onMounted(() => {
  setTimeout(() => {
    showTit.value = true;
  }, 250);

  bus.$on('clickChild',(type)=>{
      if(type==0){
       window.scrollTo(0, 0);
      }else if(type==1){
       window.scrollTo(0, 850);

      }
  })

});

onBeforeUnmount(()=>{
  bus.$off('clickChild')
})
</script>

<style scoped lang="less">

.card_comm{
  cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: end;
    padding-bottom: 65px;
    background-color: #F5F5F5;
    box-sizing: border-box;
    background-repeat: no-repeat;
    background-size: cover;
    transition: all 0.8s;
}
.m_card{
    
  }
  .o_card:hover{
    padding-bottom: 95px;
    span{color: #fff;}
    :nth-child(2){background-color: #fff;}
  }
  .m_card:hover{
    background-color: #E93B45;
    background-image: none !important;
    padding-bottom: 95px;
    span{color: #fff;}
    :nth-child(2){background-color: #fff;}
  }
  .mo_card:hover img{
    content: url(https://static.jinzhuangli.com/staticFile/images/2309158.png);
  }
.motto{
  overflow: hidden;
}
.title {
  text-align: center;
  min-height: 97px;
}
.ca_comm:hover .ca_act {
  background: rgba(174, 31, 36, 0.7) !important;
}
.ca_comm:hover {
  border-radius: 0 100px 0 100px;
  overflow: hidden;
}

.card_a {
  .ca_left {
    background-image: url(https://static.jinzhuangli.com/staticFile/images/23091411.png);
    
  }
  .ca_right {
    cursor: pointer;
    background-image: url(https://static.jinzhuangli.com/staticFile/images/23091412.png);
    :nth-child(1) {
      font-size: 26px;
      font-weight: bold;
      padding-bottom: 15px;
    }
  }
  .ca_right,
  .ca_left {
    background-repeat: no-repeat;
    background-size: 100% 100%;
    flex-direction: column;
    color: #fff;
    font-size: 18px;
    cursor: pointer;
    transition: all 0.5s;

    .ca_act {
      border-radius: 0 30px 0 30px;

      flex-direction: column;
      transition: all 0.5s;
     
      :nth-child(1) {
        font-size: 26px;
        font-weight: bold;
        padding-bottom: 15px;
        position: relative;
        
      }
      :nth-child(1)::after{
          content: "";
          position: absolute;
          bottom: 8px;
          width: 20px;
          left: 50%;
          transform: translateX(-50%);
          height: 2px;
          background-color: #fff;
        }
    }
  }
}
</style>