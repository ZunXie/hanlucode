<template>
  <div class="main">
    <div class="banner h-700px w-100%">
      <img src="https://static.jinzhuangli.com/staticFile/images/2309181.webp" alt />
      <transition enter-active-class="animate__animated animate__fadeInUp">
        <div class="info" v-if="showBanner">
          <img class="banner_txt" src="https://static.jinzhuangli.com/staticFile/images/2309143.png" alt srcset />
          <button class="w-250px h-72px">进一步了解</button>
        </div>
      </transition>
    </div>


    <div class="content pt-100px flex flex-justify-center pb-100px min-h341px">
      <transition enter-active-class="animate__animated animate__fadeInUp">
        <div style="text-align: center;" v-show="showDesc">
          <img class="w-200px h-65px mb-56px" src="https://static.jinzhuangli.com/staticFile/images/2309183.png" alt="" />
          <p>“翘匠”是隶属于广州市泽昌门业有限公司的门业品牌，</p>
          <p>集居室门研发、生产、销售、服务于一体，</p>
          <p>自创立以来，始终专注于各类门产品的研发与生产，</p>
          <p>以“用感恩之心待人，用工匠精神处事”为企业价值观，</p>
          <p>以“引领世界门业潮流”为企业愿景，以“让家居更美，让行业更新”为企业使命，</p>
          <p>不断推陈出新，注重产品研发和设计，为提高人们的生活品质而不断努力。 </p>
        </div>

      </transition>

    </div>
  </div>
  <!-- <img src="/public/QiaoJiang.jpg" alt=""> -->
</template>

<script setup lang="ts">
const showBanner = ref<boolean>(false)
const showDesc = ref<boolean>(false)

document.body.onscroll = function () {
  let top = document.documentElement.scrollTop || document.body.scrollTop;
  console.log('top',top)
  if (top >= 80 && !showDesc.value) {
    showDesc.value = true;
  }
};
onMounted(() => {
  setTimeout(() => {
    showBanner.value = true;
  }, 50)
})
</script>

<style scoped lang="less">
.content {
  flex-direction: column;
  align-items: center;

  p {
    font-size: 18px;
    margin: 0 0 12px 0;
  }
}

.banner {
  position: relative;

  img {
    width: 100%;
    height: 100%;
  }

  .info {
    position: absolute;
    left: 330px;
    bottom: 93px;

  }

  button {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 30px;
    line-height: 30px;
    border-radius: 150px;
    border: 1px solid #fff;
    background-color: transparent;
    margin-top: 70px;
  }

  .banner_txt {
    width: 661px;
    height: 132px;
    top: 331px;
  }
}
</style>