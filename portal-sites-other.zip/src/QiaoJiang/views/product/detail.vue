<template>
  <div class="main">
    <transition enter-active-class="animate__animated animate__fadeIn ">
      <div v-if="tabIdx === '0'">
        <div class="card" v-for="item in dataListA" :key="item.id">
          <div class="title">
            <div class="tit_line"></div>
            <span>{{ item.title }}</span>
          </div>
          <p class="desc">{{ item.desc }}</p>

          <div class="shop_list">
            <div class="shop_item" v-for="(child, idx) in item.list" :key="idx">
              <img :src="`https://static.jinzhuangli.com/staticFile/images/${child.uri}.png`" :alt="child.name" />
              <p>{{ child.name }}</p>
              <p>{{ child.desc }}</p>
            </div>
          </div>
        </div>
      </div>
    </transition>

    <transition enter-active-class="animate__animated animate__fadeIn ">
      <div v-if="tabIdx == 1">
        <div class="card" v-for="item in dataListB" :key="item.id">
          <div class="title">
            <div class="tit_line"></div>
            <span>{{ item.title }}</span>
          </div>
          <p class="desc">{{ item.desc }}</p>

          <div class="shop_list">
            <div class="shop_item" v-for="(child, idx) in item.list" :key="idx">
              <img :src="`https://static.jinzhuangli.com/staticFile/images/${child.uri}.png`" :alt="child.name" />
              <p>{{ child.name }}</p>
              <p>{{ child.desc }}</p>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
let tabIdx = ref<any>("");
const dataListA = reactive<any>([
  {
    title: "免漆系列",
    desc:
      "采用环保性能的 PVC 膜替代油漆，解决甲醛和苯的释放。门扇采用全包覆工艺，密闭性表面木纹质感，可选花型和色，适应不同装修风格",
    id: "x0",
    list: [
      {
        uri: "2309163",
        name: "QJ81晨夕",
        desc: "武士黑胡桃·星云摩卡棕，星雀灰，白沙秋月灰"
      },
      {
        uri: "2309164",
        name: "0J11朝露",
        desc: "武士黑胡桃·星云摩卡棕，熔云红橡·星雀灰，白沙秋月灰"
      },
      {
        uri: "2309165",
        name: "QJ31 见野",
        desc: "武士黑胡桃·星云摩卡棕，武士黑胡桃·雅川棕"
      },
      {
        uri: "2309166",
        name: "QJ-2Z",
        desc: "武士黑胡桃·星云摩卡棕，熔云红橡·星雀灰，樱桃木·波尔多红"
      }
    ]
  },
  {
    title: "烤漆系列",
    desc:
      "实木填充，五底三面烤漆，有效提高抗热防火性，时尚美观更实用，轻松搭配适各种装修风格。",
    id: "x1",
    list: [
      {
        uri: "2309167",
        name: "简爱",
        desc: "甲板科技水洗灰玫瑰"
      },
      {
        uri: "2309168",
        name: "惊鸿",
        desc: "高密度科技勃良第橡木(星云摩卡棕/气宇白)"
      },
      {
        uri: "2309169",
        name: "知意",
        desc: "高密度科技雅典馨灰，武士黑胡桃·星云摩卡棕，武士黑胡桃·雅川棕"
      }
    ]
  },

  {
    title: "厨房门系列",
    desc: "厨房环境潮湿、厨卫门要求保温性、静音、防潮",
    id: "x2",
    list: [
      {
        uri: "23091610",
        name: "16极窄推拉门",
        desc:
          "突破极限，零框感设计极简风不只是简单地把型材变窄，更要从每一处地方尽显极简的韵味."
      },
      {
        uri: "23091611",
        name: "简爱系列转角L型推拉门",
        desc: "高精度硅钵镁铝合金"
      }
    ]
  },

  {
    title: "整装定制系列",
    desc:
      "0.6cm 极窄立体设计设计，以极简风格见证纯爱空间，阳极氧化+瓷泳工艺，大大提高保温性、静音、防潮效果，重新定义表面高精级",
    id: "x3",
    list: [
      {
        uri: "23091612",
        name: "恋家",
        desc:
          "突破极限，零框感设计极简风，不只是简单地把型材变窄，更要从每一处地方尽显极简的韵味"
      },
      {
        uri: "23091613",
        name: "简爱系列转角L型推拉门",
        desc: "高精度硅钵镁铝合"
      }
    ]
  }
]);

const dataListB = reactive<any>([
  {
    title: "防盗安全门系列",
    desc:
      "甲级防盗等级，外观融合东方美学设计，同时兼具防盗和美感，让安防也可登上大雅之堂",
    id: "x0",
    list: [
      {
        uri: "23091614",
        name: "QJ-J138",
        desc: "武士黑胡桃·星云摩卡棕，白沙秋月灰多色可选"
      },
      {
        uri: "23091615",
        name: "QJ-J215",
        desc: ""
      },
      {
        uri: "23091616",
        name: "QJ-J237",
        desc: "武士黑胡桃·星云摩卡棕，熔云红橡·星雀灰，白沙秋月灰多色可选"
      },
      {
        uri: "23091617",
        name: "QJ-J213",
        desc: "武士黑胡桃·星云摩卡棕，熔云红橡·星雀灰，白沙秋月灰多色可选"
      },
      {
        uri: "23091618",
        name: "QJ-J243",
        desc: "武士黑胡桃·星云摩卡棕，武士黑胡桃·雅川棕多色可选"
      }
    ]
  },
  {
    title: "防火入户门系列",
    desc:
      "烤漆系列: 实木填充，五底三面烤漆，有效提高抗热防火性，时尚美观更实用，轻松搭配适各种装修风格。",
    id: "x1",
    list: [
      {
        uri: "23091619",
        name: "QJ-G5",
        desc: "甲板科技水洗灰玫瑰"
      },
      {
        uri: "23091620",
        name: "QJ-G6",
        desc: "高密度科技良第橡木(星云摩卡棕/气宇白)"
      },
      {
        uri: "23091621",
        name: "QJ-G7(木纹)",
        desc: "武士黑胡桃·星云摩卡棕，武士黑胡桃·雅川棕多色可选"
      }
    ]
  },

  {
    title: "装甲门系列",
    desc:
      "坚硬钢结构体，无惧暴力拆卸。前后表面覆盖平滑饰面材料，塑造极简科技美学，不止坚固更具美观。",
    id: "x1",
    list: [
      {
        uri: "23091622",
        name: "悠然",
        desc: "甲级(铸铝)防盗门"
      },
      {
        uri: "23091623",
        name: "凝立",
        desc: "甲级(铸铝)防盗门"
      }
    ]
  },

  {
    title: "整装定制系列",
    desc: "针对全屋风格制定个性化家装方案",
    id: "x1",
    list: [
      {
        uri: "23091624",
        name: "生机",
        desc:
          "把自然引进住所，大片的明光穿过阳光房项部的防晒玻离，让人享受难得的宁静与自然"
      },
      {
        uri: "23091625",
        name: "江帆",
        desc: "出色的隔音保温性能，安全稳定、坚固牢靠"
      }
    ]
  }
]);
const router = useRouter();
const route = useRoute();
watch(() => route.params.type, (newValue, oldValue) => {
  tabIdx.value = newValue;
})
onMounted(() => {
  tabIdx.value = route.params.type;
});
</script>

<style lang="less" scoped>
.main {
  width: 1260px;
  margin: auto;
  padding-top: 55px;
}

p {
  margin: 0;
}

img {
  width: 100%;
}

.shop_list {
  display: flex;
  flex-wrap: wrap;

  > :nth-child(3n) {
    margin-right: 0 !important;
  }

  .shop_item:hover {
    color: #AE1F24;
  }

  .shop_item:hover :nth-child(3) {
    color: #C2575B;
  }

  .shop_item {
    width: 400px;
    padding-bottom: 72px;
    margin-right: 30px;
    transition: all 0.5s;

    :nth-child(2) {
      padding: 20px 0 8px 0;
      font-size: 28px;
    }

    :nth-child(3) {
      color: #555555;
      font-size: 16px;
    }
  }
}

.card {
  cursor: pointer;

  .desc {
    width: 520px;
    box-sizing: border-box;
    padding-left: 16px;
    line-height: 28px;
    color: #333333;
    margin-bottom: 30px;
  }

  .title {
    display: flex;
    align-items: center;
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 12px;
    padding-top: 18px;

    .tit_line {
      width: 4px;
      height: 40px;
      background: #ae1f24;
      margin-right: 12px;
    }
  }
}</style>