<template>
  <div class="main">
    <transition enter-active-class="animate__animated animate__fadeIn">
      <div class="title" v-if="showTitBol">
      <h2>核心产品</h2>
      <p class="m-0">作为国内门业新锐品牌，翘匠始终致力于让更多家庭享受到安静、舒适的高品质生活,</p>
      <p class="m-0">以高品质的产品、贴心的服务，守护你的一方天地!</p>
    </div>
    </transition>
    

    <div class="content flex" :style="{'padding-top':showTitBol?'0':'163px'}">
      <div
        :class="['card','flex','flex-items-center','flex-justify-end', 'w-294px','h-480px','mr-28px','br-8', 'pb-35px',]"
        v-for="(item,idx) in list"
        :key="idx"
        @click="viewDetail(idx)"
        @mouseenter="mouseenter(idx)"
      >
        <div :class="['hd',item.show?'act_hd':'']">
            <div>{{item.name}}</div>
            <div>{{item.desc}}</div>
            <img src="https://static.jinzhuangli.com/staticFile/images/2309149.png" alt="">
        </div>
        <img
          :class="[item.show?'h-320px':'h-261px pb-49px']"
          :src="`https://static.jinzhuangli.com/staticFile/images/${item.path}.png`"
          alt
        />
        <div :class="['c_tit pb-10px',!item.show?'color-#252525':'color-#fff']">{{item.name}}</div>
        <div  :class="[!item.show?'color-#333':'color-#fff']">{{item.desc}}</div>
      </div>

     
    </div>
  </div>
</template>


<script setup lang="ts">
const list = reactive<any>([
  {
    path: "2309145",
    show: false,
    name: "商用门 系列",
    desc: "大局处运筹帷幄 细节处精雕细琢"
  },
  {
    path: "2309146",
    name: "入户门 系列",
    uri:"/merchandiseDetail/0",
    show: false,
    desc: "丝丝缕缕勾勒出家居生活的多元魅力"
  },
  {
    path: "2309147",
    name: "防火门 系列",
    show: false,
    desc: "终极使命是敬畏生命"
  },
  {
    path: "2309148",
    show: false,
    name: "室内门 系列",
    uri:"/merchandiseDetail/1",
    desc: "丝丝缕缕勾勒出家居生活的多元魅力"
  }
]);
const router = useRouter();
const showTitBol=ref<boolean>(false);
function viewDetail(idx:number){
  const {uri}=list[idx]
  if(uri){
    router.push({path:uri})
     window.scrollTo(0, 0);

  }

}
function mouseenter(idx: number) {
  for (let i = 0; i < list.length; i++) {
    list[i].show = idx == i ? true : false;
  }
  console.dir(list);
}

onMounted(()=>{
  setTimeout(() => {
    showTitBol.value=true;
  }, 200);
})
</script>

<style scoped lang="less">
.main {
  padding-top: 103px;
  min-height: 100vh;
  background-color: #fff;
}

.content {
  width: 1260px;
  margin: auto;

  > :last-child {
    margin-right: 0;
  }
 
  .hd {
    width: 100%;
    height: 0;
    position: absolute;
    bottom: 0;
    overflow: hidden;
    background: linear-gradient(
      180deg,
      rgba(174, 31, 36, 0) 26%,
      rgba(174, 31, 36, 0.95) 100%
    );
    border-radius: 8px 8px 8px 8px;
    transition: all 0.5s;
    color: #fff;
    display: flex;
    align-items: center;
    flex-direction: column;
    box-sizing: border-box;
    :nth-child(1){
        font-size: 22px;
        padding-bottom: 10px;
    }
    :nth-child(2){
        font-size: 16px;
        padding-bottom: 35px;
    }
    img{
        width: 38px;
        height: 43px;
    }
  }
  .act_hd{
    height: inherit;
    padding-top: 301px;
    

  }
  .card {
    cursor: pointer;
    flex-direction: column;
    background-color: #fafafa;
    box-sizing: border-box;
    position: relative;

    .c_tit {
      font-size: 22px;
      font-weight: bold;
    }
    img{
        transition: all 0.3s;
    }
  }
}
.title {
  display: flex;
  align-items: center;
  flex-direction: column;
  justify-content: center;
  padding-bottom: 30px;
  h2 {
    font-size: 50px;
    line-height: 50px;
    margin: 0;
    margin-bottom: 15px;
  }
  p {
    color: #666666;
    font-size: 18px;
    padding-top: 15;
    width: 672px;
    text-align: center;
    padding-bottom: 10px;
  }
}
</style>