<template>
    <div class="w-full h-100vh bg-#ffffff">
       <div class="w-1200px mtu-0 pt-140px flex pl-100px items-center">
        <img src="https://gw.alipayobjects.com/zos/rmsportal/KpnpchXsobRgLElEozzI.svg" class="imgsrt-360-430">
        <div class="ml-52px flex flex-col items-center">
          <h1 class="ftcom-72-600">404</h1>
          <div class="mt-24px ftcom-20-400 c-#1A1A1A">
            抱歉，你访问的页面不存在
          </div>
          <el-button type="primary" @click="backHome" class="mt-20px">返回首页</el-button>
        </div>
       </div>
    </div>
</template>

<script setup name='' lang='ts'>
import {} from 'vue'
//  const { proxy }: any = getCurrentInstance();
const router = useRouter()
// const route = useRoute()
 function backHome(){
  router.push('/customize')
 }   
</script>

<style lang='less' scoped>
</style>