<template>
    <div class="bg-red">
        浩汀页面
    </div>
    <img src="/public/HaoTing.jpg" alt="">
</template>

<script setup lang="ts">


</script>

<style scoped lang="less">

</style>