import { createRouter,createWebHistory } from 'vue-router';
import vRoutes from 'virtual:generated-pages';
import root from './roots';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
import { getToken } from '/@/utils/auth';
const routes = root.concat(vRoutes);

//导入生成的路由数据
const router = createRouter({
  history: createWebHistory(),
  routes,
});
const whiteList = []; // no redirect whitelist(不重定向名单,例如注册找回密码什么的 不需要重定向页面)
router.beforeEach(async (_to, _from, next) => {
  NProgress.start();
  // 需要登录的页面配置路由元信息
  if (_to.meta.requireAuth) {
    if (getToken()) {
      next();
    } else {
      // 说明当前路径在白名单里面
      if (whiteList.findIndex((v) => v == _to.path) !== -1) {
        next({ path: '/login' });
      } else {
        next({ path: '/login', query: { redirect: _to.fullPath } });
      }
    }
    NProgress.done();
  } else {
    if (getToken()) {
      if (_to.path === '/login') {
        next({ path: '/customize' })
      } else {
        next()
      }
    }else{
      next()
    }
    NProgress.done();
  }
});

router.afterEach((_to) => {
  // NProgress.done();
});

export default router;
