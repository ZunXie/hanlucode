export default [
  {
    path: "/",
    component: () => import('/@/HaoTing/views/index.vue'),
  },
  { path: '/404', component: () => import('/@/HaoTing/views/errorPage/404.vue') },
  //匹配所有路径 vue3不再使用*而是得用正则匹配。
  { path: '/:pathMatch(.*)', redirect: '/404' },
]