import { defineStore } from 'pinia';
import piniaStore from '/@/HaoTing/store/index';


export const useAppStore = defineStore(
  // 唯一ID
  'app',
  {
    state: () => ({
      token: '',
    }),
    getters: {},
    actions: {
     
    },
    persist: {
      key: 'HaoTing_TOKEN',
      // storage: typeof window?.localStorage?localStorage:undefined,
      paths: ['token'],
    },
  },
);

export function useAppOutsideStore() {
  return useAppStore(piniaStore);
}
