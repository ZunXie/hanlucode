// vite-plugin-pages动态路由的补充

export default [
  {
    path: '/',
    component: () => import('/@/KeYi/views/index.vue'),
  },
  {
    path: '/companyDevelop',
    component: () => import('/@/KeYi/views/companyDevelop/index.vue'),
  },
  {
    path: '/companyInfo',
    component: () => import('/@/KeYi/views/companyInfo/index.vue'),
  },
  {
    path: '/product',
    component: () => import('/@/KeYi/views/product/index.vue'),
  },
  {
    path: '/customize',
    component: () => import('/@/KeYi/views/index.vue'),
  },
  { path: '/404', component: () => import('/@/KeYi/views/errorPage/404.vue') },
  //匹配所有路径 vue3不再使用*而是得用正则匹配。
  { path: '/:pathMatch(.*)', redirect: '/404' },
];
