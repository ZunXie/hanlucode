<template>
  <div ref="fullPageRef" class="h-full">
    <Header @isFixed="isFixedFn" @loginPop="dialogVisible = true" v-if="!isLoginPage" :headFilter="headFilter" :isFixed="isFixed" />
    <router-view :key="route.fullPath" />
    <Footer v-if="!isLoginPage" />
  </div>
</template>

<script setup lang="ts">
  import useMouse from '/@/KeYi/hooks/homeMouse';
  import { useEventListener } from '@vueuse/core';
  import useAgent from '/@/KeYi/hooks/useAgent';

  // 判断手机端还是PC端
  const { isMobile } = useAgent();
  // 登录弹窗
  const dialogVisible = ref(false);

  let isfixed = ref<boolean>(false);
  //  const { proxy }: any = getCurrentInstance();
  const router = useRouter();
  const route = useRoute();
  let isLoginPage = ref<boolean>(false);
  let headFilter = ref<boolean>(false);
  let isFixed = ref<boolean>(true);

  const isFixedFn = (e: boolean) => {
    isfixed.value = e;
  };

  // 监听鼠标滑动逻辑处理
  const fullPageRef = ref();
  const { mouseWheelHandle } = useMouse(fullPageRef);
  const mousewheelJudge = (e: Event) => {
    if (router.currentRoute.value.path !== '/followUs' || isMobile()) return;
    mouseWheelHandle(e);
  };
  const load = () => {
    window.scrollTo(0, 0);
  };
  window.addEventListener('beforeunload', load);
  const wheelEvent =
    'onwheel' in document.createElement('div')
      ? 'wheel' //  各个厂商的高版本浏览器都支持wheel事件
      : (document as any).onmousewheel !== undefined
      ? 'mousewheel' // Webkit和IE一定支持mousewheel事件
      : 'DOMMouseScroll'; // 低版本firefox
  console.log(`**当前的浏览器支持的是==${wheelEvent}事件**`);
  useEventListener(fullPageRef, wheelEvent, mousewheelJudge, { passive: false });

  onMounted(() => {
    // if (!useStore.id) dialogVisible.value = true;
  });
</script>

<style lang="less" scoped></style>
