<template>
  <header :class="['w-full', 'h-164px', 'position-relative', isFixed && 'header_fixed', scrollFlag ? 'c-#000 bg-#fff headerAnima' : 'hd']">
    <div class="w-1200px h-full flex mtu-0 items-center">
      <div class="cursor-pointer flex items-center logo_box" @click="router.push('/')">
        <img
          :src="`https://static.test.jinzhuangli.com/staticFile/images/230909${scrollFlag ? 6 : 4}.png`"
          class="h-41px w-150px block"
          alt="科译logo"
        />
      </div>
      <div class="ml-auto h-full mw-0 flex items-center ftcom-14-400" v-if="!searchFlag">
        <div class="h-full flex items-center cursor-pointer position-relative ml-40px" v-for="item in navigationBar" :key="item.label">
          <div
            @click="routeClick(item)"
            :class="[
              'route_item',
              'w-120px',
              'ftcom-16-700',
              'select-none',
              'position-relative',
              route.path === item.path ? (scrollFlag ? 'activeClassToggle' : 'activeClass') : '',
            ]"
          >
            <div>{{ item.enLabel }}</div>
            <div>{{ item.label }}</div>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>
<script setup lang="ts">
  import useRoll from '../../hooks/sidebarScroll';
  import { headerList } from '/@/utils/publicData';

  let { scrollFlag } = useRoll();

  interface Emit {
    (e: 'isFixed', flag: boolean): void;
    (e: 'loginPop'): void;
  }
  const emit = defineEmits<Emit>();
  interface Props {
    headFilter: boolean;
    isFixed: boolean;
  }
  const navigationBar = ref<any>(headerList);

  const props = withDefaults(defineProps<Props>(), {
    headFilter: false,
  });
  const router = useRouter();
  const route = useRoute();

  // 检测浏览器系统主题
  // const darkThemeMq = window.matchMedia('(prefers-color-scheme: dark)')
  const searchFlag = ref<boolean>(false);
  watch(
    scrollFlag,
    (newHandler, oldHandler) => {
      emit('isFixed', newHandler);
    },
    { immediate: true },
  );
  // 无感刷新
  // const reloads = inject('reload') as any;
  const routeClick = async (e: any) => {
    // let { query, path: routePath } = route;
    const { path } = e;
    router.push({ path });
    await nextTick();
    if (path != '/') {
      window.scrollTo(0, window.innerHeight - 200);
    } else {
      window.scrollTo(0, 0);
    }
  };
  onMounted(() => {});
</script>
<style lang="less" scoped>
  .hd {
    color: #fff;
  }
  .route_item {
    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: -30px;
      width: 120px;
      height: 1.5px;
      background: #e0e0e0;
      border-radius: 10px 10px 10px 10px;
    }
    :nth-child(1) {
      padding-bottom: 8px !important;
    }
  }
  .logo_box {
    position: relative;
  }
  .logo_box::after {
    content: '';
    width: 200px;
    border-bottom: 1.5px solid #e0e0e0;
    position: absolute;
    bottom: -35px;
    left: 0;
  }
  .headerAnima {
    // animation: headerAnima 0.6s;
    // box-shadow: 0px 4px 12px 0px rgba(0, 0, 0, 0.08);
  }
  .header-first-screen {
    background: rgba(0, 0, 0, 0.3);
  }
  .header_fixed {
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    min-width: 1280px;
    z-index: 2000;
  }
  .download_app_container {
    position: absolute;
    left: calc(50% - 73px);
    bottom: 0;
    z-index: 1999;
    transform: translate(0, 100%);
  }
  .popover_scale {
    padding: 15px;
    width: 146px;
    box-shadow: 0 3px 9px rgba(0, 0, 0, 0.08);
    border-radius: 8px;
    box-sizing: border-box;
    height: 170px;
    background: #ffffff;
    transform-origin: 50% -8px;
  }
  .byted_popover_scale {
    transition: all 0.1s ease-in;
    opacity: 0;
  }
  .byted_popover_scale_show {
    opacity: 1;
    transition: all 0.1s ease-out;
  }
  .popover_scale_xy {
    transform: scale(0.8);
  }
  .popover_scale_xy_show {
    transform: scale(1);
  }

  .screening_condition {
    width: 783px;
    padding: 0 8px 20px 16px;
    background: #ffffff;
    box-shadow: 2px -2px 8px 0px rgba(0, 0, 0, 0.1), -2px 2px 8px 0px rgba(0, 0, 0, 0.1);
    position: absolute;
    left: 50%;
    z-index: 998;
    bottom: 0px;
    border-radius: 4px;
    transform: translate(-50%, 100%);
  }
  .search_history {
    box-shadow: 2px -2px 10px 0px rgba(0, 0, 0, 0.08), -2px 2px 10px 0px rgba(0, 0, 0, 0.08);
  }
  @keyframes headerAnima {
    0% {
      transform: translateY(-50px);
    }
    100% {
      transform: translateY(0px);
    }
  }
  .jey_words {
    &:hover {
      background: #f2f2f2ff;
    }
  }
  .activeClass {
    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: -30px;
      width: 120px;
      height: 1.5px;
      background: #ffffff;
      border-radius: 10px 10px 10px 10px;
    }
  }
  .activeClassToggle {
    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: -30px;
      width: 120px;
      height: 1.5px;
      background: #252525;
      border-radius: 10px 10px 10px 10px;
    }
  }
  .account_hover {
    &:hover {
      background: #fed201;
      flex-wrap: nowrap;
    }
  }
  .account_number {
    box-shadow: 2px -2px 8px 0px rgba(0, 0, 0, 0.1), -2px 2px 8px 0px rgba(0, 0, 0, 0.1);
  }
</style>
