<template>
  <div class="main">
    <div class="home_page">
      <img class="hp_img" src="https://static.test.jinzhuangli.com/staticFile/images/2309093.png" alt="" />
      <transition enter-active-class="animate__animated   animate__fadeInUp ">
        <div class="info" v-show="showInfo">
          <div>百年科译 全球誉名</div>
          <div>值得信赖的美好生活陪伴者</div>
          <div @click="viewDoc">查看更多</div>
        </div>
      </transition>
    </div>
  </div>
</template>

<script setup lang="ts">
  let showInfo = ref<Boolean>(false);

  function viewDoc() {
    window.open('https://view.officeapps.live.com/op/view.aspx?src=https://static.test.jinzhuangli.com/staticFile/doc/kyIntroduce.doc');
  }

  onMounted(() => {
    setTimeout(() => {
      showInfo.value = true;
    }, 200);
  });
</script>

<style lang="less" scoped>
  @keyframes bgAni {
    0% {
      width: 100%;
      height: 100%;
    }
    30% {
      width: 101%;
      height: 102%;
    }
    60% {
      width: 102%;
      height: 102%;
    }
    100% {
      width: 103%;
      height: 103%;
    }
  }
  img {
    width: 100%;
    height: 100%;
  }
  @-webkit-keyframes scaleUpDown {
    from {
      -webkit-transform: scale(1);
      transform: scale(1);
    }
    to {
      opacity: 1;
      -webkit-transform: scale(1.12);
      transform: scale(1.12);
    }
  }
  @keyframes scaleUpDown {
    from {
      -webkit-transform: scale(1);
      transform: scale(1);
    }
    to {
      opacity: 1;
      -webkit-transform: scale(1.12);
      transform: scale(1.12);
    }
  }
  .home_page {
    width: 100%;
    height: 100vh;
    overflow: hidden;
    // background-image: url(https://static.test.jinzhuangli.com/staticFile/images/2309093.png);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    font-family: Source Han Sans CN-Regular, Source Han Sans CN;

    position: relative;
    .hp_img {
      position: absolute;
      height: 100%;
      z-index: 1;
      object-fit: cover;
      // animation: 3s bgAni;
      -webkit-animation: scaleUpDown 6s forwards cubic-bezier(0.25, 0.46, 0.45, 0.94);
      animation: scaleUpDown 6s forwards cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }
    .info {
      position: relative;
      color: #fff;
      display: inline-block;
      margin-top: 430px;
      margin-left: 330px;
      z-index: 2;
      ::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 35px;
        height: 4px;
        background-color: #d42d2a;
        content: '';
      }

      :nth-child(1) {
        font-size: 90px;
        font-weight: bold;
      }
      :nth-child(2) {
        font-size: 32px;
        padding-bottom: 30px;
      }
      :nth-child(3) {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        width: 134px;
        height: 47px;
        border-radius: 2px 2px 2px 2px;
        opacity: 1;
        border: 2px solid #ffffff;
        cursor: pointer;
      }
    }
  }
</style>
