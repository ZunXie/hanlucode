// 公共的图片处理（页脚）
import wx from '/@/KeYi/assets/images/footer/wx.png'
import dy from '/@/KeYi/assets/images/footer/dy.png'
import tt from '/@/KeYi/assets/images/footer/tt.png'
import xhs from '/@/KeYi/assets/images/footer/xhs.png'
import wxPop from '/@/KeYi/assets/images/footer/wxPop.png'
import ttPop from '/@/KeYi/assets/images/footer/ttPop.png'
import dyPop from '/@/KeYi/assets/images/footer/dyPop.png'
import xhsPop from '/@/KeYi/assets/images/footer/xhsPop.png'
import wb from '/@/KeYi/assets/images/footer/wb.png'

export {
  wx,
  dy,
  tt,
  xhs,
  wxPop,
  ttPop,
  dyPop,
  xhsPop,
  wb
}
