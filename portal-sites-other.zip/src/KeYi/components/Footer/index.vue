<template>
  <footer class="w-full bg-#FFFFFF pd-16-0-39-0 footer-style">
    <div class="w-1200px mtu-0">
      <!-- <div class="flex w-full justify-center mt-34px position-relative">
        <div
          class="imgsrt-30-30 mr-28px relation-animal"
          v-for="info in relationList"
          :key="info.id"
        >
          <img
            :src="info.img"
            alt=""
            class="w-full h-full vertical-middle position-absolute left-0 top-0 z-2"
            @click="viewWb(info)"
          />
          <img
            :src="info.pop"
            alt=""
            class="h-165px vertical-middle pop-img"
            v-show="info.id !== 2"
            :style="{
              width: info.id === 0 ? '264px' : '130px',
              left: info.id === 0 ? '133%' : '89%',
            }"
          />
        </div>
      </div> -->
      <div class="flex w-full justify-center pt-35px c-#777777 ftcom-14-400">
        <!-- <div class="mr-50px">
          开发者：金装里（广州）科技有限公司&nbsp;&nbsp;|&nbsp;&nbsp;<a
            href="https://static.jinzhuangli.com/app/privacyPolicy/index.html"
            target="_blank"
            class="c-#777777"
            >隐私政策</a
          >
          &nbsp;&nbsp;|&nbsp;&nbsp;应用版本：1.8.30
        </div> -->
        公司地址：佛山市南海区里水镇胜利社区里广路138号5楼百编516室
        <!-- <div class="ml-50px"> 客服服务热线: 020-85828642 </div> -->
        <!-- <div class="ml-50px">客服服务热线: 19924642342</div> -->
      </div>
      <div class="flex w-full justify-center pt-30px c-#777777 ftcom-14-400">
        Copyright  2023 佛山市华好陶瓷有限公司 版权所有
        <!-- <a
          href="https://beian.miit.gov.cn/"
          target="_blank"
          class="c-#777777 ml-50px"
          >粤ICP备2021117485号</a
        > -->
        <!-- <div class="ml-50px">增值电信业务经营许可证 | B2-20230210</div> -->
      </div>
    </div>
  </footer>
</template>

<script setup lang="ts">
import {
  wx,
  dy,
  tt,
  xhs,
  wxPop,
  ttPop,
  dyPop,
  xhsPop,
  wb,
} from "./comImgHandle";
const list = ref<string[]>([
  "客服服务热线：15360595468",
  // '客服邮箱：jz17328346358@163.com',
  // '客服服务热线：周一到周六（9：00-18：00）',
  // '顾问手机号：18928763943（微信同号）',
  // '邮箱编码：511400',
  "公司地址：广东省广州市番禺区新造镇永兴路3号",
  "增值电信业务经营许可证 | 粤B2-20230210",
]);

// 联系方式
const relationList = [
  {
    id: 0,
    img: wx,
    pop: wxPop,
  },
  {
    id: 1,
    img: dy,
    pop: dyPop,
  },
  {
    id: 2,
    img: wb,
  },
  {
    id: 3,
    img: xhs,
    pop: xhsPop,
  },
  {
    id: 4,
    img: tt,
    pop: ttPop,
  },
];
const listV2 = ref([
  {
    key: "serverPhone",
    title: "客服服务热线: 020-85828642",
  },
  {
    key: "companyAddress",
    title: "公司地址：广东省广州市番禺区新造镇永兴路3号",
  },
  {
    key: "licence",
    title: "增值电信业务经营许可证 | 粤B2-20230210",
  },
]);

// 去到公司微博页面
const viewWb = (info: { [keyName: string]: unknown }) => {
  if (info.id !== 2) return;
  window.open("https://weibo.com/u/7861136929", "_blank");
};
</script>

<style lang="less" scoped>
.footer-style {
  border-top: 1px solid #d0d0d0;
  .relation-animal {
    position: relative;
    cursor: pointer;
    &:hover .pop-img {
      scale: 1.2;
      opacity: 1;
      visibility: visible;
    }
    .pop-img {
      position: absolute;
      top: -162px;
      transform: translateX(-50%);
      scale: 1;
      opacity: 0;
      visibility: hidden;
      z-index: 1;
      transition: all 0.3s ease-out;
    }
  }
}
</style>
