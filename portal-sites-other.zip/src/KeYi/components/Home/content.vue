<template>
  <div class="content">
    <div class="left">
      <img src="https://static.test.jinzhuangli.com/staticFile/images/2309116.png" alt="" />
    </div>

    <div class="right">
      <transition enter-active-class="animate__animated   animate__fadeInRight ">
        <p v-show="showContentRgiht">我们是谁</p>
      </transition>
      <transition enter-active-class="animate__animated   animate__fadeInRight ani_delay">
        <p v-show="showContentRgiht">
          <span>“能为消费者</span>
          <span>提供品质保障的陶瓷制造商。”</span>
        </p>
      </transition>
      <transition enter-active-class="animate__animated   animate__fadeInRight ani_delay_03">
        <p v-show="showContentRgiht">
          科译陶瓷隶属于佛山市华好陶瓷有限公司，总部位于中国陶瓷之都一一佛山市，是国内著名的建筑陶瓷制造商和销售商之一。
        </p>
      </transition>
      <transition enter-active-class="animate__animated   animate__fadeInRight ani_delay_04">
        <p v-show="showContentRgiht">
          <br />
          <!-- <br /> -->
          <br />科译陶瓷从事建筑陶瓷行业最早可追溯至1987年，自创办以来，始终专业生产及销售各类墙地砖、陶瓷岩板、石墨烯智控发热瓷砖等全品类产品，并以“百年科译，全球誉名”为品牌愿景，锐意创新，不断开发，引领行业消费潮流的产品，至今全国已拥有3000多个销售网点，产品远销全球130多个国家和地区，覆盖意大利、法国、德国、西班牙、美国、澳洲等国家的重点城市，同时与众多地产开发企业、设计装修平台等形成战略合作，建立完善的终端销售服务与工程服务体系，为广大终端客户及消费者提供专业贴心的品质服务。
        </p>
      </transition>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { isMobile } from '../../../utils/comm';
  let showContentRgiht = ref<Boolean>(false);

  document.body.onscroll = function (e) {
    let top = document.documentElement.scrollTop || document.body.scrollTop;

    if (top >= 350 && !showContentRgiht.value) {
      showContentRgiht.value = true;
    }
  };

  onMounted(() => {
    setTimeout(() => {
      if (isMobile()) {
        showContentRgiht.value = true;
      }
    }, 200);
  });
</script>

<style lang="less" scoped>
  img {
    width: 100%;
    height: 100%;
  }
  .ani_delay {
    animation-delay: 0.2s !important;
  }
  .ani_delay_03 {
    animation-delay: 0.3s !important;
  }
  .ani_delay_04 {
    animation-delay: 0.4s !important;
  }
  @media only screen and (max-width: 500px) {
    .content .left {
      width: 325px !important;
      height: 225px !important;
    }
    .content .right {
      width: 240px !important;
      > :nth-child(1) {
        font-size: 24px;
        font-weight: bold;
      }
      > :nth-child(2) {
        font-size: 12px;
        font-weight: bold;
        padding: 10px 0 12px 0;
        :last-child {
          color: #d42d2a;
        }
      }
      > :nth-child(3),
      > :nth-child(4) {
        color: #888888;
        font-size: 8px;
        letter-spacing: 2px;
      }
    }
  }
  .content {
    display: flex;
    justify-content: space-between;
    width: 1260px;
    margin: 236px auto 230px auto;
  }
  .left {
    width: 650px;
    height: 450px;
  }
  .right {
    width: 480px;
    transform: translateY(-4px);
    > :nth-child(1) {
      font-size: 48px;
      line-height: 48px;
      font-weight: bold;
    }
    > :nth-child(2) {
      font-size: 24px;
      font-weight: bold;
      padding: 20px 0 25px 0;
      :last-child {
        color: #d42d2a;
      }
    }
    > :nth-child(3),
    > :nth-child(4) {
      color: #888888;
      font-size: 16px;
      letter-spacing: 4px;
    }
  }
</style>
