<template>
  <div class="main">
    <HomePage />

    <transition enter-active-class="animate__animated   animate__fadeInDown ">
      <div class="title" v-show="showTit">
        <p>Brand Culture</p>
        <p>品牌文化</p>
        <p>立足中国 面向全球</p>
      </div>
    </transition>

    <div class="card">
      <div class="card_item" v-for="(item, idx) in cardList" :key="idx">
        <img :src="`https://static.test.jinzhuangli.com/staticFile/images/${item.url}.png`" alt="" />
        <p>{{ item.name }}</p>
        <p>{{ item.desc }}</p>
      </div>
    </div>
    <div class="concept">
      <div class="c_tit">经营理念</div>
      <div class="c_list">
        <div
          :class="{ list_item: true, act_list_item: item.show }"
          v-for="(item, idx) in conceptList"
          :key="idx"
          @mouseenter="mouseenter(idx)"
          @mouseleave="mouseleave(idx)"
        >
          <span class="li_tit">{{ item.name }}</span>
          <transition enter-active-class="animate__animated   animate__fadeInRight animate__delay-0.4s">
            <p v-show="item.show">{{ item.desc }}</p>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  // import { isMobile } from '../../utils/comm';

  const showTit = ref<Boolean>(false);

  const cardList = ref<any>([
    {
      url: '2309111',
      name: '使命',
      desc: '以品质缔造人们美好生活',
    },
    {
      url: '2309112',
      name: '愿景',
      desc: '百年科译，全球誉名',
    },
    {
      url: '2309113',
      name: '核心价值观',
      desc: '品质、责任、创新、利他',
    },
  ]);

  const conceptList = reactive<any>([
    {
      name: '产品理念',
      show: false,
      desc: '做最好的陶瓷产品，做最好的解决方案',
    },
    {
      name: '服务理念',
      show: false,
      desc: '用户至上，绝不辜负客户的托付',
    },
    {
      name: '管理理念',
      show: false,
      desc: '目标导向、价值优先、执行有力、协同高效',
    },
    {
      name: '人才理念',
      show: false,

      desc: '知人善任，以德为先。让想干事的人有机会，让能干事的人有舞台让干成事的人有平台。',
    },
    {
      name: '质量理念',
      show: false,

      desc: '成为全球建筑陶瓷行业的质量标杆',
    },
    {
      name: '品牌理念',
      show: false,

      desc: '值得信赖的美好生活陪伴者',
    },
    {
      name: '社责理念',
      show: false,

      desc: '温暖客户、成就伙件、回报股东、善待坏境、造福社会。',
    },
  ]);
  // document.body.onscroll = function () {
  //   let top = document.documentElement.scrollTop || document.body.scrollTop;

  //   if (top >= 350 && !showTit.value) {
  //     showTit.value = true;
  //   }
  // };
  onMounted(() => {
    setTimeout(() => {
      showTit.value = true;
    }, 1);
  });
  function mouseenter(idx: number) {
    console.log('enver', idx, conceptList);

    for (let i = 0; i < conceptList.length; i++) {
      if (i === idx) {
        conceptList[i].show = true;
      } else {
        conceptList[i].show = false;
      }
    }
  }
  function mouseleave(idx: number) {
    console.log('leve', idx);
  }
</script>

<style lang="less" scoped>
  .main {
    background-color: #f9f9f9;
    margin: auto;
    overflow: hidden;
    .concept {
      padding: 0 330px;
      height: 1080px;
      background-image: url(https://static.test.jinzhuangli.com/staticFile/images/2909114.png);
      background-repeat: no-repeat;
      background-size: 100% 100%;
      .c_tit {
        padding: 130px 0 100px 0;
        color: #fff;
        font-size: 50px;
      }
      .c_list {
        display: flex;
        height: 100%;
        .act_list_item {
          width: 521px !important;
        }
        .list_item {
          cursor: pointer;
          overflow: hidden;
          box-sizing: border-box;
          width: 125px;
          color: #fff;
          border-right: 1px solid #fff;
          padding-left: 50px;
          transition: all 0.6s;
          .li_tit {
            writing-mode: tb-rl;
            font-size: 24px;
            letter-spacing: 10px;
          }
          p {
            padding-top: 530px;
            font-size: 20px;
            letter-spacing: 2px;
            // white-space: nowrap;
            padding-right: 16px;
            width: calc(521px - 52px);
          }
        }
      }
    }
  }
  .card {
    width: 1260px;
    margin: auto;
    display: flex;
    justify-content: space-between;
    padding-bottom: 180px;
    .card_item {
      width: 390px;
      height: 260px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      font-size: 14px;
      background-color: #fff;
      border-radius: 10px;
      img {
        width: 70px;
        height: 68px;
      }
      :nth-child(2) {
        color: #252525;
        font-size: 22px;
        padding: 26px 0 12px 0;
      }
      :nth-child(3) {
        color: #999999;
      }
    }
  }
  .title {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    color: #888888;
    font-size: 16px;
    padding-top: 90px;
    padding-bottom: 80px;
    min-height: 287px;
    width: 1260px;
    margin: auto;
    :nth-child(2) {
      padding: 10px 0;
      font-size: 42px;
      color: #252525;
      font-weight: bold;
    }
  }
</style>
