<template>
  <div>
    <HomePage />

    <transition enter-active-class="animate__animated   animate__fadeInDown ">
      <header v-show="showHead">
        <div class="title">
          <span>我们的</span>
          <span>发展战略</span>
        </div>
        <p> 立足中国，面向全球! </p>
      </header>
    </transition>
    <div class="content">
      <div class="info">
        <transition enter-active-class="animate__animated   animate__fadeInUp animate__delay-1s">
          <div class="left" v-show="showContent">
            <span class="c_tit">战略</span>
            <p>为广大设计师和消费者提供低碳、环保、高科技和极具个性化的瓷砖产品是科译的追求。</p>
          </div>
        </transition>
        <transition enter-active-class="animate__animated   animate__fadeInUp animate__delay-1s">
          <div class="right" v-show="showContent">
            <span class="c_tit">战略二</span>
            <p
              >在未来，科译将继续传承中国陶瓷文化，持续创新，树行业标杆，创国际品质，朝着“百年科译，全球誉名”的目标打造国际知名民族品牌，为世界建陶行业作出新的贡献，为中国智造赢得世界尊敬!</p
            >
          </div>
        </transition>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  // import { isMobile } from '../../utils/comm';

  const showHead = ref<Boolean>(false);
  const showContent = ref<Boolean>(false);
  // document.body.onscroll = function () {
  //   let top = document.documentElement.scrollTop || document.body.scrollTop;

  //   if (top >= 350 && !showHead.value) {
  //     showHead.value = true;
  //     showContent.value = true;
  //   }
  // };
  onMounted(() => {
    setTimeout(() => {
      showHead.value = true;
      showContent.value = true;
    }, 1);
  });
</script>

<style lang="less" scoped>
  header {
    width: 1260px;
    margin: auto;
    padding: 100px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    .title {
      font-size: 30px;
      font-weight: bold;
      :nth-child(2) {
        color: #d42d2a;
      }
    }
    p {
      padding-top: 25px;
      color: #666;
      font-size: 16px;
    }
  }
  .content {
    background-image: url(https://static.test.jinzhuangli.com/staticFile/images/2309115.png);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    height: 550px;
    color: #fff;
    position: relative;
    margin-bottom: 150px;
    .info {
      position: absolute;
      bottom: 30px;
      padding: 0 330px;
      display: flex;
      width: 100%;
      justify-content: space-between;
    }
    .c_tit {
      color: rgba(255, 255, 255, 0.8);
      font-size: 16px;
    }
    p {
      padding-top: 7px;
      font-size: 18px;
    }
    .left {
      width: 360px;
    }
    .right {
      width: 792px;
    }
  }
</style>
