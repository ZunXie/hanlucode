<template>
  <div>
    <HomePage />

    <div class="product">
      <transition enter-active-class="animate__animated   animate__fadeInDown ">
        <header v-show="showHead">
          <h3>我们的产品</h3>
          <p>
            科译陶瓷坚持技术创新和产品革新，目前产品涵盖亚光砖、抛光砖、抛釉砖、内墙瓷片、陶瓷岩板、岗岩等所有品类，能够为全空间领域提供高品质的装饰材料和完善的配套方案</p
          >
        </header>
      </transition>
      <div class="card" :style="{ 'padding-top': !showHead ? '251px' : '0' }">
        <div class="item" v-for="(item, idx) in cardList" :key="idx">
          <div class="title">{{ item.name }}</div>
          <p>{{ item.desc }}</p>
          <img class="img" :src="`https://static.test.jinzhuangli.com/staticFile/images/${item.url}.png`" alt="" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  // import { isMobile } from '../../utils/comm';

  const showHead = ref<Boolean>(false);
  const cardList = reactive<any>([
    {
      name: '亚光砖',
      desc: '介于黑与白之间的不同灰度，运用洁净哑光技术,兼具实用与美感，方寸之间彰显空间的高雅',
      url: '2309117',
    },
    {
      name: '抛光砖',
      desc: '细节变幻, 在虚无与现实之间，给人留下广阔的遐想空间，极富淡然空灵的禅意',
      url: '2309118',
    },
    {
      name: '抛釉砖',
      desc: '灰与白的交锋，达到了色彩与美学的完美平衡，让装饰空间呈现别样的静谧之美',
      url: '2309119',
    },
    {
      name: '内墙瓷片',
      desc: '颜色纹路清新自然,线条生动, 色泽柔润, 赋予内墙瓷片更加温暖的内涵',
      url: '23091110',
    },
    {
      name: '陶瓷岩板',
      desc: '极致东方美学理念，融合先进3D喷墨打印与布料技术，开创写意极美空间',
      url: '23091111',
    },
    {
      name: '岗岩',
      desc: '纳米防滑科技釉料，可刚可柔，在打磨之后表里始终如一，开启雅奢美学之旅',
      url: '23091112',
    },
  ]);
  // document.body.onscroll = function () {
  //   let top = document.documentElement.scrollTop || document.body.scrollTop;
  //   console.log('top', top);

  //   if (top >= 350 && !showHead.value) {
  //     showHead.value = true;
  //   }
  // };
  onMounted(() => {
    setTimeout(() => {
      showHead.value = true;
    }, 1);
  });
</script>

<style lang="less" scoped>
  .item:hover {
    background-color: #d42d2a !important;
  }
  .item:hover .title {
    color: #ffffff !important;
  }
  .item:hover p {
    color: rgba(255, 255, 255, 0.75) !important;
  }
  .item:hover img {
    width: 345px !important;
    height: 357px !important;
  }
  .product {
    width: 1260px;
    min-height: 100vh;
    margin: auto;
    background-color: #fff;
    .card {
      display: flex;
      flex-wrap: wrap;
      padding-bottom: 50px;
      :nth-child(3n).item {
        margin-right: 0 !important;
      }
      .item {
        position: relative;
        cursor: pointer;
        width: 380px;
        height: 550px;
        padding: 50px 0 20px 35px;
        background-color: #f5f5f5;
        border-radius: 20px;
        transition: all 0.2s;
        box-sizing: border-box;
        margin-bottom: 60px;
        margin-right: 60px;

        .title {
          font-size: 20px;
          font-weight: bold;
          padding-bottom: 15px;
          transition: all 0.2s;
        }
        p {
          color: #666666;
          font-size: 14px;
          line-height: 22px;
          padding-bottom: 50px;
          transition: all 0.2s;
          padding-right: 35px;
        }
        .img {
          width: 310px;
          height: 342px;
          border-radius: 20px 0 0 20px;
          float: right;
          transition: all 0.5s;
          position: absolute;
          bottom: 20px;
          right: 0;
        }
      }
    }
    header {
      padding: 60px 0 70px 0;
      text-align: center;
      h3 {
        font-size: 30px;
      }
      p {
        width: 800px;
        color: #666666;
        font-size: 16px;
        line-height: 28px;
        margin: 25px auto 0 auto;
      }
    }
  }
</style>
