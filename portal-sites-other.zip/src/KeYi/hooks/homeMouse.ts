import { useWindowScroll } from '@vueuse/core';
import { Tween } from '/@/utils/tween';
const { x, y } = useWindowScroll();
export default function useMouse(fullPage: any) {
  // 要移动的页面元素
  let scrollRef: any = ref(null);
  let fullpageData = reactive<scrollEvent>({
    moveFlag: true, //控制鼠标滚动的开关
    movePx: 0, //要移动的距离
    moveScroll: 0, //屏幕移动的尺寸
    moveEachThem: 0, //每滚动的一份尺寸
    moveClientHeight: 0, //要滑动的总共的高度
    moveScrollStart: 0, //屏幕初始移动的距离
    isMouse: false,
    timer: null,
  });
  let animaTime = 0;
  let time = 0;
  // 两次滑动的最小距离
  let slideDistance=100
  // 两次滑动的时间间隔
  let slideInterval=500
  watchEffect(() => {
    let scrollY = unref(y);
    fullpageData.moveScroll = Math.ceil(scrollY);
    // console.log(fullpageData.isMouse, fullpageData.moveScroll,fullpageData.movePx, '**滚动*');
    // 如果是点击右侧滚动条让其滚动打开开关
    if (fullpageData.moveScroll > 0 && fullpageData.movePx === 0 && !fullpageData.isMouse) {
      fullpageData.moveFlag = true;
      return;
    }
    if (fullpageData.movePx > fullpageData.moveScroll && !fullpageData.isMouse) {
      fullpageData.moveFlag = true;
    }
    // 如果是点击右侧滚动条让其滚动的往下滑
    if (!fullpageData.isMouse && fullpageData.moveScroll === 0) {
      fullpageData.moveFlag = true;
      fullpageData.movePx = 0;
      return;
    }
    // 如果屏幕滚动的距离和需要滚动目标距离相等的话
    if (fullpageData.moveScroll === fullpageData.movePx) {
      (fullpageData.timer as any) = setTimeout(() => {
        fullpageData.moveFlag = true;
      }, 160);
    } else if (
      fullpageData.moveScroll !== fullpageData.movePx &&
      fullpageData.movePx < fullpageData.moveClientHeight &&
      fullpageData.isMouse
    ) {
      fullpageData.moveFlag = false;
      if (fullpageData.timer) {
        clearTimeout(fullpageData.timer);
        fullpageData.timer = null;
      }
    }
  });

  // 判断是否滚动到底部
  const scrollBottom = () => {
    let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    let windowHeight = document.documentElement.clientHeight || document.body.clientHeight;
    let scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
    return scrollTop + windowHeight >= scrollHeight;
  };
  const scrollAnimationDown = () => {
    // 浏览器版本兼容
    frameCompatibility();
    let isBotton: boolean = scrollBottom();
    let topNow = Math.ceil(document.documentElement.scrollTop || document.body.scrollTop);
    if (topNow >= fullpageData.movePx || isBotton) {
      // 重置开关
      fullpageData.isMouse = false;
      fullpageData.movePx = 0;
      animaTime = 0;
      return;
    }
    let duration = 30;
    const { moveScrollStart, moveEachThem } = fullpageData;
    let value = Tween.Quad.easeInOut(animaTime, moveScrollStart, moveEachThem, duration);
    document.documentElement.scrollTop = Math.ceil(value);
    animaTime++;
    window.requestAnimationFrame(scrollAnimationDown);
  };
  const scrollAnimationUp = (newTimestamp: any) => {
    // 浏览器版本兼容
    frameCompatibility();
    let topNow = Math.ceil(document.documentElement.scrollTop || document.body.scrollTop);
    if (topNow <= fullpageData.movePx) {
      fullpageData.isMouse = false;
      fullpageData.movePx = 0;
      animaTime = 0;
      return;
    }
    // scroll移动动画
    let duration = 30;
    const { moveScrollStart, moveEachThem } = fullpageData;
    let value = Tween.Quad.easeInOut(animaTime, moveScrollStart, -moveEachThem, duration);
    document.documentElement.scrollTop = Math.ceil(value);
    animaTime++;
    window.requestAnimationFrame(scrollAnimationUp);
  };
  const frameCompatibility = () => {
    var vendors = ['webkit', 'moz', 'ms', 'o'];
    for (var i = 0; i < vendors.length && !window.requestAnimationFrame; ++i) {
      var vp = vendors[i];
      window.requestAnimationFrame = window[vp + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vp + 'CancelAnimationFrame'] || window[vp + 'CancelRequestAnimationFrame'];
    }
    // 如果还是没有的话就用定时器
    if (!window.requestAnimationFrame || !window.cancelAnimationFrame) {
      window.requestAnimationFrame = function (callback: any) {
        window.setTimeout(callback, 1000 / 60);
      } as any;
    }
  };
  const mouseWheelHandle = (event: Event) => {
    const evt = event;
    evt?.preventDefault();
    evt?.stopPropagation();
    let e = (event as any).originalEvent || event;
    let delta = e.deltaY || e.detail; // Firefox使用detail
    let nowTime = new Date().getTime();
    // 无效滑动
    if (Math.abs(delta) < slideDistance && nowTime - time < slideInterval && time > 0) {
      time = nowTime;
      return;
    }
    // console.log(fullpageData.moveFlag, fullpageData, '**开关**');
    if (!fullpageData.moveFlag) {
      time = nowTime;
      return false;
    }
    time = nowTime;
    if (delta > 0) {
      let addNum = 0;
      addNum = fullpageData.moveScroll - (fullpageData.moveScroll % fullpageData.moveEachThem) + fullpageData.moveEachThem;
      fullpageData.moveScrollStart = fullpageData.moveScroll;
      fullpageData.movePx = addNum;
      fullpageData.isMouse = true;
      window.requestAnimationFrame(scrollAnimationDown);
    } else if (delta < 0) {
      if (fullpageData.moveScroll === 0 && fullpageData.movePx === 0) return;
      let isReduce = fullpageData.moveScroll % fullpageData.moveEachThem;
      fullpageData.moveScrollStart = fullpageData.moveScroll;
      // 没有余数
      if (isReduce === 0) {
        fullpageData.movePx = fullpageData.moveScroll - fullpageData.moveEachThem;
      } else {
        fullpageData.movePx = fullpageData.moveScroll - (fullpageData.moveScroll % fullpageData.moveEachThem);
      }
      fullpageData.isMouse = true;
      window.requestAnimationFrame(scrollAnimationUp);
    }
  };
  provide('getHomeRef', (e: any) => {
    scrollRef.value = e;
    if (scrollRef.value) {
      let { children, clientHeight } = scrollRef.value;
      fullpageData.moveClientHeight = clientHeight;
      fullpageData.moveEachThem = Math.ceil(clientHeight / children.length);
    }
  });
  return {
    mouseWheelHandle,
  };
}
