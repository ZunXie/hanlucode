export default function useRoll() {
  let scrollFlag = ref<boolean>(false);
  let windowsScrollTop = ref<number>(0);
  // 获取页面滚动距离
  const handleScroll = () => {
    let scrollTop: number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    // console.log(scrollTop, '滚动距离');
    windowsScrollTop.value = scrollTop;
    if (scrollTop >= 200) {
      scrollFlag.value = true;
    } else {
      scrollFlag.value = false;
    }
  };
  const frameCompatibility = () => {
    var vendors = ['webkit', 'moz'];
    for (var i = 0; i < vendors.length && !window.requestAnimationFrame; ++i) {
      var vp = vendors[i];
      window.requestAnimationFrame = window[vp + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vp + 'CancelAnimationFrame'] || window[vp + 'CancelRequestAnimationFrame'];
    }
  };
  // 点击滚动图标回到顶部
  const scrollBackTop = () => {
    frameCompatibility();
    if (!window.requestAnimationFrame || !window.cancelAnimationFrame) {
      // //  设置一个定时器
      const upRoll: any = setInterval(() => {
        const top: number = document.documentElement.scrollTop; // 每次获取页面被卷去的部分
        const speed: number = Math.ceil(top / 10); // 每次滚动多少 （步长值）
        if (document.documentElement.scrollTop > 0) {
          document.documentElement.scrollTop -= speed; // 不在顶部 每次滚动到的位置
        } else {
          clearInterval(upRoll); // 回到顶部清除定时器
        }
      }, 20);
      return;
    }
    let top: any = document.documentElement.scrollTop; // 每次获取页面被卷去的部分
    if (top === 0) return;
    const cosParameter = top / 2;
    let scrollCount = 0;
    let oldTimestamp = null;
    function step(newTimestamp: any) {
      if (oldTimestamp !== null) {
        // if duration is 0 scrollCount will be Infinity
        scrollCount += (Math.PI * (newTimestamp - oldTimestamp)) / 500;
        if (scrollCount >= Math.PI) return (document.documentElement.scrollTop = 0);
        document.documentElement.scrollTop = cosParameter + cosParameter * Math.cos(scrollCount);
      }
      oldTimestamp = newTimestamp;
      window.requestAnimationFrame(step);
    }
    window.requestAnimationFrame(step);
  };
  onMounted(() => {
    window.addEventListener('scroll', handleScroll); // 监听页面滚动
  });
  onUnmounted(() => {
    window.removeEventListener('scroll', handleScroll);
  });

  return {
    scrollFlag,
    windowsScrollTop,
    scrollBackTop,
  };
}
