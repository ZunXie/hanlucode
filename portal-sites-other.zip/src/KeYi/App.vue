<template>
  <PublicComponent v-if="isRouterActive" />
</template>
 <script setup lang="ts">
const isRouterActive = ref<boolean>(true);
const reload = () => {
  isRouterActive.value = false;
  nextTick(() => {
    isRouterActive.value = true;
  });
};
// 无感刷新
provide("reload", reload);
</script>
 
 <style>
#app {
  font-family: PingFang SC-Regular, PingFang SC;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  min-width: 1260px;
  /* height: 100%; */
  background: #fff;
  color: #252525;
}
</style>
 