import { Reqconfig, petsGroup } from './types'
type IPets = Record<petsGroup, Reqconfig>
const api: IPets = {
    development: {
        VITE_APP_API_BASEURL: "https://api.test.jinzhuangli.com",
        VITE_APP_CAS_BASE_URL: "https://static.test.jinzhuangli.com"
    },
    production: {
        VITE_APP_API_BASEURL: "https://api.jinzhuangli.com",
        VITE_APP_CAS_BASE_URL: "https://static.jinzhuangli.com"
    },
    staging: {
        VITE_APP_API_BASEURL: "https://api.test.jinzhuangli.com",
        VITE_APP_CAS_BASE_URL: "https://static.test.jinzhuangli.com"
    }
}
export default (api as any)[import.meta.env.VITE_USER_NODE_ENV]