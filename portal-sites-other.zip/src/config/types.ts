export interface Reqconfig {
    VITE_APP_API_BASEURL: string;
    VITE_APP_CAS_BASE_URL: string
}
export type petsGroup = 'development' | 'production' | 'staging'