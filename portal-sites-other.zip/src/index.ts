// 浩汀
import HaoTing from './HaoTing/App.vue'
import routerHT from './HaoTing/router'
import createPinia from './HaoTing/store/index'
// 科译
import KeYi from './KeYi/App.vue'
import router from './KeYi/router'
import createPiniaKY from './KeYi/store/index'
// 翘匠
import QiaoJiang from './QiaoJiang/App.vue'
import routerQ from './QiaoJiang/router'
import createPiniaQ from './QiaoJiang/store/index'
// 十丽
import ShiLi from './Shili/App.vue'
import shiLiRouter from './Shili/router'


function insertLogo(item: { [keyName: string]: string }) {
  let link = document.createElement('link');
  link.rel = 'shortcut icon';
  link.href = `/${item.logo}`;
  document.head.appendChild(link);

  let title = document.createElement('title');
  title.textContent = item.name;
  document.head.appendChild(title);

}

function detectedSite() {
  let dict: any = {
    'keyitaoci.jinzhuangli.cn': { name: '科译', app: KeYi, logo: 'KeYi.jpg', router, pina: createPiniaKY },
    'keyitaoci.cn':{ name: '科译', app: KeYi, logo: 'KeYi.jpg', router, pina: createPiniaKY},
    'Haotingzhineng.jinzhuangli.cn': { name: '浩汀', app: HaoTing, logo: 'HaoTing.jpg', router: routerHT, pina: createPinia },
    'Haotingzhineng.com': { name: '浩汀', app: HaoTing, logo: 'HaoTing.jpg', router: routerHT, pina: createPinia },
    'qiaojiangmen.jinzhuangli.cn': { name: '翘匠', app: QiaoJiang, logo: 'QiaoJiang.jpg', router: routerQ, pina: createPiniaQ },
    'qiaojiangmen.com': { name: '翘匠', app: QiaoJiang, logo: 'QiaoJiang.jpg', router: routerQ, pina: createPiniaQ },
    'Shantangzhizao.jinzhuangli.cn': { name: '商汤智造' },
    'Shantangzhizao.com': { name: '商汤智造' },
    'Shiliqwdz.jinzhuangli.cn': { name: '十丽',app:ShiLi,router:shiLiRouter,logo:'ShiLi.jpg' },
    'Shiliqwdz.com': { name: '十丽',app:ShiLi,router:shiLiRouter,logo:'ShiLi.jpg'  },
    'Yuxunweiyu.jinzhuangli.cn': { name: '誉迅' },
    'Yuxunweiyu.com': { name: '誉迅' },
  }
  let env = import.meta.env.VITE_USER_NODE_ENV
  let itemSite = {}

  if (env === 'development' || env === 'staging') {
    itemSite = dict['Shiliqwdz.com'];
    // itemSite = dict['keyitaoci.jinzhuangli.cn'];
    
    // itemSite = dict['qiaojiangmen.jinzhuangli.com'];
  } else {
    // 不区分大小写查找
    for (let key in dict) {
      let host = window.location.hostname
      if (host.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
        itemSite = dict[key];
        break;
      }
    }
  }
  insertLogo(itemSite)
  return itemSite;
}


export {
  detectedSite
}