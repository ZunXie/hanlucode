<template>
    <header>
        <h1>
            <a href="/" alt="qiaoJiang Logo" title="翘匠">翘匠</a>
        </h1>
        <div class="menus">
            <div class="menu_item" v-for="(item,idx) in menus" :key="item.id" @click="viewMenu(item.id,idx)">
                {{ item.name }}
                <div class="child" v-if="item.children">
                    <div class="child_item" v-for="(child, cIdx) in item.children" :key="cIdx"
                        @click.stop="viewChild(item.id, cIdx)">
                        {{ child.name }}
                        <span class="ci_line"></span>
                    </div>
                </div>
            </div>
        </div>
    </header>
</template>

<script setup lang="ts">
const menus = reactive<any>([
    {
        id: "x0",
        name: "十丽·产品",
        path: "/",
        children: []
    },
    {
        id: "x1",
        name: "十丽·故事",
        path: "/story",
        children: []
    },
    {
        id: "x2",
        name: "十丽·优势",
        path: "/advantage",
        children: []
    },
    {
        id: "x3",
        name: "十丽·探索",
        path: "/explore",
        children: [
            {
                name: "关于十丽",
                type: 0,
                className: 'about'
            },
            {
                name: "品牌符号",
                type: 0,
                className: 'symbol'
            },
            {
                name: "企业文化",
                type: 0,
                className: 'e_foot'
            },
        ]
    },
])
const cxt = getCurrentInstance(); //相当于Vue2中的this
const bus = cxt?.appContext.config.globalProperties.$bus;
const router = useRouter();
const route = useRoute();

function viewMenu(id:string,idx:number) {
    const { path } = menus.find(v => v.id == id);
    router.push({ path });
    window.scrollTo(0,0)
    bus.$emit("viewMenu", idx);

}

// 点击子级
async function viewChild(id: string, idx: number) {
    let item = menus.find(v => v.id == id);
    let { type, className } = item.children[idx];
    // 0表示做瞄点的
    if (type == 0) {
        // 是否在点击的页面
        if (route.path != item.path) {
            router.push({ path: item.path });
        }
        await nextTick()
        setTimeout(() => {
            bus.$emit("viewPoint", className);
        }, 200)
    }
}
</script>

<style lang="less" scoped>
.menus {
    display: flex;
    font-size: 16px;
    font-weight: bold;
    padding-left: 60px;

    .menu_item:hover .child {
        max-height: 200px;


    }

    .menu_item {
        padding-right: 40px;
        line-height: 82px;
        cursor: pointer;
        position: relative;

        .child {
            position: absolute;
            width: 124px;
            background-color: #fff;
            text-align: center;
            left: -22px;
            overflow: hidden;
            max-height: 0;
            -webkit-transition: max-height 0.4s;
            transition: max-height 0.4s;
            z-index: 7;

            .child_item:hover .ci_line {
                width: 40px;
            }

            .child_item {
                height: 54px;
                line-height: 54px;
                font-size: 16px;
                font-weight: bold;
                position: relative;

                .ci_line {
                    position: absolute;
                    top: 0;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 0;
                    height: 5px;
                    background-color: #009C75;
                    transition: all 0.5s;
                }
            }
        }
    }
}

header {
    height: 82px;
    padding-left: 400px;
    display: flex;
    align-items: center;
    position: sticky;
    top: 0;
    z-index: 99;
    background-color: #fff;

    h1 {
        margin: 0;
    }

    h1 a {
        display: inline-block;
        width: 55px;
        height: 35px;
        background: url(https://static.jinzhuangli.com/staticFile/images/2309191.png) no-repeat left top/55px 35px;
        text-indent: -9999px;
        overflow: hidden;
    }
}</style>