<template>
    <header>
       ---------头部--------
    </header>
   </template>
   
   <script setup lang="ts">
   
   
   </script>
   
   <style lang="less" scoped>
   header{
       height: 82px;
       text-align: center;
   }
   </style>