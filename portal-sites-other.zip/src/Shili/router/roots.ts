
export default [
    {
      path: "/",
      component: () => import('/@/Shili/views/index.vue'),
      children:[
        {
          path:'/',
          name:'product',
          component: () => import('/@/Shili/views/product/index.vue'),
        },
        {
          path: "/story",
          component: () => import('/@/Shili/views/story/index.vue'),
        },
        {
          path: "/advantage",
          component: () => import('/@/Shili/views/advantage/index.vue'),
        },
        {
          path: "/explore",
          component: () => import('/@/Shili/views/explore/index.vue'),
        },
      ]
    },
    
    
    { path: '/404', component: () => import('/@/Shili/views/errorPage/404.vue') },
    //匹配所有路径 vue3不再使用*而是得用正则匹配。
    { path: '/:pathMatch(.*)', redirect: '/404' },
  ]