
<template>
    <sHeader></sHeader>

    <router-view/>
  </template>
  
  <script setup lang="ts">
import sHeader from "./components/SHeader/index.vue";


  </script>
  
  <style scoped lang="less">
  @font-face {
      font-family: "hs";        //自定义字体名称
      src:url("https://static.jinzhuangli.com/staticFile/font/HanSansCN_Normal.otf");       //字体包路径
      font-weight: normal;
      font-style: normal;
  }
  @font-face {
      font-family: "pht";        //自定义字体名称
      src:url("https://static.jinzhuangli.com/staticFile/font/Alibaba_PuHuiTi_Light.ttf");       //字体包路径
      font-weight: normal;
      font-style: normal;
  }
  img{width: 100%;height: 100%;}
  p,span{margin: 0;padding: 0;}
  body{
    user-select:none;
    background-color: #fff;
  }
  </style>
  