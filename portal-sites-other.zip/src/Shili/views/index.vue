<template>
  <div class="main">
    <!-- <img src="/public/QiaoJiang.jpg" alt=""> -->
    <div class="swiperbox">
      <!-- :autoplay="{ delay: 2500, disableOnInteraction: false}" -->
      <!-- :autoplay="{ delay: 3000, disableOnInteraction: false}" -->
      <swiper :slidesPerView="1" :spaceBetween="0" :loop="false" :modules="modules" @swiper="onSwiper"
        @slideChange="onSlideChange">
        <swiper-slide v-for="(item, idx) in swpList" :key="idx">
          <img :src="item.uri" alt="" />

          <!-- 产品、故事 内容 -->
          <div class="head_info" v-if="[0, 1,3].includes(idx)&&[0,1,3].includes(curIdx)">
            <p data-aos="fade-up" data-aos-duration="600">我们的品牌</p>
            <p data-aos="fade-up" data-aos-duration="600" data-aos-delay="50">立志，行业领导者</p>
            <p data-aos="fade-up" data-aos-duration="600" data-aos-delay="100">自1992 年以来备受信赖</p>
            <p data-aos="fade-up" data-aos-duration="600" data-aos-delay="150">
              查看更多
              <img src="https://static.jinzhuangli.com/staticFile/images/2309193.webp" alt="" />
            </p>
          </div>
          <!--优势 内容 -->
          <transition enter-active-class="animate__animated   animate__fadeInUp ">
            <div class="adv_info flex  flex-items-center w-980px " v-if="idx == 2 && curIdx == 2">
              <img class="w-70px h-44px mb-10px" src="https://static.jinzhuangli.com/staticFile/images/2309205.webp"
                alt="">
              <span class="ftcom-120-700 color-#F3F3F3 pb-10px">十丽·优势</span>
              <p>
                十丽一直被行业称赞为极具产品特色的品牌,涵盖六大空间产品和八大设计风格,包括客厅餐厅、门厅、卧房、书房、衣帽间，现代简约、法式、美式、中式、田园、简欧、北欧、新古典多种风格。同时致力于打造中国极具实力的全屋定制品牌，秉持“品质源于细节、服务创造价值”的理念，每一款产品都秉承“精韧净美”四大优点。
              </p>
            </div>
          </transition>
        </swiper-slide>


      </swiper>





      <div class="dot">
        <div :class="['dot_item', idx == curIdx ? 'dot_act_item' : '']" v-for="(item, idx) in swpList" :key="idx"></div>
      </div>
    </div>

    <RouterView></RouterView>

  </div>
</template>
  
<script setup lang="ts">

import { Navigation, Autoplay, Virtual } from 'swiper';
const modules = [Navigation, Autoplay, Virtual]
let swp: any = null;
const curIdx = ref<number>(0);

const swpList = reactive<any>([
  {
    path: '/',
    name: "产品",
    uri: "https://static.jinzhuangli.com/staticFile/images/2309192.webp",
  },
  {
    name: "故事",
    uri: "https://static.jinzhuangli.com/staticFile/images/2309201.webp",
    path: '/story',
  },
  {
    name: "优势",
    uri: "https://static.jinzhuangli.com/staticFile/images/2309202.webp",
    path: '/advantage',
  },
  {
    name: "探索",
    uri: "https://static.jinzhuangli.com/staticFile/images/2309203.webp",
    path: '/explore',
  },
])
const router = useRouter();
const route = useRoute();
const cxt = getCurrentInstance(); //相当于Vue2中的this
const bus = cxt?.appContext.config.globalProperties.$bus;
const onSwiper = (swiper) => {
  swp = swiper;
};
const onSlideChange = (e) => {
  curIdx.value = e.activeIndex;
  const { path } = swpList[curIdx.value];
  router.push({ path });


};

onMounted(()=>{
  bus.$on('viewMenu',(idx)=>{
    swp.slideTo(idx,500)
  })
})
onBeforeUnmount(()=>{
  bus.$off('viewMenu')
})
function testFn() {
  // console.log('swp', swp)
  // swp.slideNext()
  swp.slideTo(3,500)
}
</script>
  
<style scoped lang="less">
@media only screen and (max-width: 500px) {
  .swiperbox {
    height: 998px !important;
  }
}
:deep(.swiper){
  height: 100%;
}
// /deep/ .swiper{height: 100%;}
p {
  margin: 0;
}

img {
  height: 100%;
  width: 100%;
}


.swiperbox {
  width: 100%;
  height: calc(100vh - 82px);
  overflow: hidden;
  position: relative;

  .adv_info {
    flex-direction: column;
    position: absolute;
    top: 150px;
    left: calc(50% - 440px);
    // left: 50%;
    // transform: translateX(-50%);
    z-index: 77;

    img {
      width: 70px;
      height: 44px;
    }

    p {
      color: #FFFFFF;
      font-size: 20px;
      line-height: 34px;
    }
  }

  .head_info {
    position: absolute;
    top: 48px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 77;
    left: 50%;
    transform: translateX(-50%);

    >:nth-child(1) {
      font-size: 14px;
      color: #222;
      font-weight: 700;
    }

    >:nth-child(2) {
      font-size: 42px;
      color: #000000;
      padding-bottom: 10px;
    }

    >:nth-child(3) {
      color: #777777;
      font-size: 20px;
      padding-bottom: 15px;
    }

    >:nth-child(4) {
      color: #444;

      img {
        width: 12px;
        height: 13px;
        vertical-align: middle;
      }
    }
  }
}

.dot {
  display: flex;
  position: absolute;
  left: 354px;
  bottom: 35px;
  z-index: 77;

  .dot_act_item {
    background-color: #fff !important;
  }

  .dot_item {
    background-color: rgba(0, 0, 0, 0.35);
    width: 20px;
    height: 5px;
    margin-right: 4px;
  }
}
</style>