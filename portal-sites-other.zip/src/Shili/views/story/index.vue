<template>
    <div class="story">
        <img data-aos="fade-up" data-aos-duration="1200" src="https://static.jinzhuangli.com/staticFile/images/2309204.webp" alt="" />
    </div>
</template>

<script setup lang="ts">


</script>

<style lang="less" scoped>

.story{
    padding-top: 180px;
    padding-bottom: 180px;
    height: 569px;
    display: flex;
    justify-content: center;
    img{
        width: 1260px;
    }
}
.s_tit{
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>