<template>
<div class="wapper wapper_c">
      <div class="wapper_h_info">
        <p data-aos="fade-up" data-aos-duration="900">十丽品牌产品涵盖</p>
        <p data-aos="fade-up" data-aos-duration="900">衣柜、橱柜、木门、护墙、配套家品、家电;板材环保等级达到国标 EO 级，甚至更高的新国标 ENF
          级，为客户提供一站式、个性化的“整家定制”解决方案。
        </p>

        <p data-aos="fade-up" data-aos-duration="900">
          十丽品牌合作伙伴分布于全国近千个城市，覆盖了包括西藏、新疆在内的三十多个省级行政区域，每年为我国数以万计的家庭，提供家居整体解决方案，创新引领人类健康生活。</p>
      </div>

      <div class="wapper_count">
        <div class="wc_item" v-for="(item, idx) in countList" :key="idx">
          <countComm :top="top" :val="item.count" suffix="" />

          <p data-aos="fade-up" data-aos-once="true" data-aos-duration="500" :data-aos-delay="100 * idx">{{ item.name }}</p>

        </div>

      </div>
    </div>

    <div class="wapper_a">
      <div class="wapper_a_left">
        归返生活本真的健康住宅”
      </div>
      <div class="wapper_a_right">
        <div style="overflow: hidden;">
          <img src="https://static.jinzhuangli.com/staticFile/images/2309195.webp" alt="" />
        </div>
      </div>
    </div>

    <div class="wapper wapper_b">
      <div class="wb_txt" data-aos="fade-up" data-aos-duration="900">
        从心出发的怡居，方是恒久不息的憧憬”
      </div>
    </div>

    <div class="wapper_a">
      <div class="wapper_a_right">
        <div style="overflow: hidden;">
          <img src="https://static.jinzhuangli.com/staticFile/images/2309197.webp" alt="" />
        </div>
      </div>
      <div class="wapper_a_left">
        让每一寸身心，回归悦然生活”
      </div>
    </div>

    <div class="wapper wapper_d">
      <div class="wd_txt">
        <p data-aos="fade-up" data-aos-duration="800" >最好的建筑就是这样的</p>
        <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="150">我们居住其中</p>
        <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">却感觉不到自然在哪里终了</p>
        <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="450">艺术从哪里开始”</p>

        <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="600">一林语堂</p>
      </div>
    </div>
</template>

<script setup lang="ts">
import countComm from "../../components/CountFlop/index.vue";
const countList = reactive<any>([
  {
    count: 5,
    name: "大基材"
  },
  {
    count: 6,
    name: "大品类"
  },
  {
    count: 7,
    name: "大风格"
  },
  {
    count: 8,
    name: "大空间"
  },
])
const top=ref<number>(0);
document.body.onscroll = function () {
    top.value = document.documentElement.scrollTop || document.body.scrollTop;
    
  };
</script>

<style scoped lang="less">
p {
  margin: 0;
}

img {
  height: 100%;
  width: 100%;
}

.wapper_a {
  display: flex;
  justify-content: space-between;
  height: 570px;

  .wapper_a_left {
    width: 50%;
    background-color: #fff;
    text-align: center;
    line-height: 570px;
    letter-spacing: 6px;
    font-size: 21px;
  }

  .wapper_a_right:hover {
    img {
      transform: scale(1.05);
    }
  }

  .wapper_a_right {
    padding: 25px 0;
    width: 50%;
    cursor: pointer;

    img {
      transition: all 0.5s;
      height: 520px;
    }
  }
}

.wapper_d {
  background-image: url(https://static.jinzhuangli.com/staticFile/images/2309198.webp);
  .wd_txt{
    text-align: right;
    letter-spacing: 12px;
    color: #fff;
    padding-top: 730px;
    line-height: 50px;
    padding-right: 120px;
    >:last-child{
      padding-top: 30px;
    }
  }
}

.wapper_b {
  background-image: url(https://static.jinzhuangli.com/staticFile/images/2309196.webp);

  .wb_txt {
    color: #fff;
    padding-top: 966px;
    width: 100%;
    text-align: right;
    padding-right: 120px;
    letter-spacing: 13px;
    font-size: 30px;
  }
}

.wapper_c {
  background-image: url(https://static.jinzhuangli.com/staticFile/images/2309194.webp);
}

.wapper {

  background-repeat: no-repeat;
  background-size: 100% 100%;
  width: 100%;
  height: 1080px;
  position: relative;
  overflow: hidden;

  .wapper_count {
    position: absolute;
    bottom: 0;
    height: 400px;
    width: 1260px;
    left: 50%;
    transform: translateX(-50%);
    border-left: 1px solid #fff;

    .wc_item {
      width: 310px;
      display: inline-block;
      text-align: center;
      border-right: 1px solid #fff;
      height: 100%;
      color: #fff;
      font-size: 42px;
    }
  }

  .wapper_h_info {

    width: 620px;
    color: #fff;
    padding-top: 100px;
    padding-left: 330px;

    :nth-child(1) {
      font-size: 40px;
      padding-bottom: 30px;
    }

    :nth-child(2) {
      padding-bottom: 20px;
    }

    :nth-child(2),
    :nth-child(3) {
      color: rgba(255, 255, 255, 0.70);
      font-size: 16px;
    }
  }
}
</style>