<template>
    <div class="advantage">
        <div class="adv_img">
            <img src="https://static.jinzhuangli.com/staticFile/images/2309206.webp" alt="">
            <div class="adv_txt" data-aos="fade-up" data-aos-duration="800">
                <p >与自然共生</p>
                <p>畅写自在生活意境”</p>
            </div>
        </div>
        <div class="adv_info">
            <img data-aos="fade-up" data-aos-duration="800" class="adv_tit_img" src="https://static.jinzhuangli.com/staticFile/images/2309207.webp" alt="">
            <span data-aos="fade-up" data-aos-duration="800" >精”</span>
            <p data-aos="fade-up" data-aos-duration="800">体现在选材精、生产精、工艺精、管理精。精选 E1级环保基材，独立研发的专用饰面，多样化的表面处理工艺，信息化的精确控制与定点分析，保证产品的精良品质。</p>
            <span data-aos="fade-up" data-aos-duration="800" data-aos-delay="100">韧”</span>
            <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="200">体现在型材韧、板材韧、配件韧、技术韧。100%自主研发1.2mm 厚度、韦氏硬度高达16的铝钻合金型材，全进口高温热熔胶强韧封边，耐磨耐热贴面，高达60万次推拉使用寿命的专利滑轮配件，确保衣柜更韧更美，经久耐用。</p>
            <span data-aos="fade-up" data-aos-duration="800" data-aos-delay="300">净”</span>
            <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="400">体现在空气净、空间净、车间净、产品净。优质环保板材，四围封边处理，让家居空气清新自然，可即装修即入住。个性化分区设计，高于成品家居30%的空间利用率，让家居空间变得更大。生产配备国际先进的中央吸尘除尘系统，3道清洗清洁工序，无尘出厂处理，保证产品干净。</p>
            <span data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">净”</span>
            <p data-aos="fade-up" data-aos-duration="800" data-aos-delay="500">体现在个性美、造型美、自然美、贴心美。十丽20多种独特、时尚、经典体系，覆盖深色、浅色、中性色，满足各种个性空间的颜色配套。独创150度弧形面板、不对称式弧形中框、第四代组合家具等创新产品，打破行业传统的造型设计，让家居环境自然融入浑然一体。</p>
        </div>
    </div>
</template>

<script setup lang="ts">


</script>

<style lang="less" scoped>
img {
    width: 100%;
    height: 100%;
}
p,span{margin: 0;padding: 0;}
.advantage {
    display: flex;
    height: 1080px;

    .adv_img {
        width: 50%;
        height: 100%;
        position: relative;
        img {
            object-fit: cover;
        }
        .adv_txt{
            font-family: pht;
            position: absolute;
            bottom: 40px;
            right: 40px;
            line-height: 65px;
            font-size: 40px;
            color: #FFFFFF;
            text-align: right;
            :nth-child(1){
                padding-right: 20px;
            }
        }
    }

    .adv_info {
        width: 50%;
        padding-left: 145px;
        padding-top: 115px;
        box-sizing: border-box;
        .adv_tit_img {
            width: 361px;
            height: 114px;
            margin-bottom: 20px;
        }
        span{
            display: block;
            padding-top: 30px;
            font-size: 24px;
            padding-bottom: 10px;
        }
        p{
            color: #666666;
            font-size: 16px;
            width: 485px;
            line-height: 28px;
        }
    }
}</style>