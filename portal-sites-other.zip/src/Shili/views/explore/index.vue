<template>
    <div class="explore">
        <div class="about comm_w" data-aos="fade-up" data-aos-duration="800">
            <img src="https://static.jinzhuangli.com/staticFile/images/2309208.webp" alt="关于十丽" />
        </div>
        <div class="card comm_w" data-aos="fade-up" data-aos-duration="800">
            <img src="https://static.jinzhuangli.com/staticFile/images/2309209.webp" alt="" />
        </div>
        <div class="symbol comm_w" data-aos="fade-up" data-aos-duration="800">
            <img src="https://static.jinzhuangli.com/staticFile/images/23092010.webp" alt="" />
        </div>
        <div class="brand comm_w" data-aos="fade-up" data-aos-duration="800">
            <img src="https://static.jinzhuangli.com/staticFile/images/23092011.webp" alt="" />

        </div>
        <div class="e_txt ">
            <img data-aos="fade-up" data-aos-duration="800"
                src="https://static.jinzhuangli.com/staticFile/images/23092014.webp" alt="" />
        </div>

        <div class="comm_w e_foot">
            <div class="ef_tit" data-aos="fade-up" data-aos-duration="800">
                <img src="https://static.jinzhuangli.com/staticFile/images/23092013.webp" alt="">
            </div>
            <div class="ef_card">
                <div :class="['ef_card_item',item.show?'ef_act_card':'']" v-for="(item, idx) in footCard" :key="idx" @mouseenter="mouseenter(idx)" @mouseleave="mouseleave">
                    <p>{{ item.title }}</p>
                    <p>{{ item.enTit }}</p>
                    <span></span>
                    <p :class="[item.show?'ec_act_p':'']">{{ item.desc }}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
const footCard = reactive<any>([
    {
        title: "我们的使命",
        enTit: "OurMission",
        show:false,
        desc: "做人类健康生活的\n创造者、革新者和引领者"
    },
    {
        title: "我们的愿景",
        show:false,
        enTit: "EnterpriseVision",
        desc: "让更多的家庭因十丽而无限美好"
    },
    {
        title: "核心价值观",
        show:false,
        enTit: "Core values",
        desc: "品质源于细节、服务创造价值"
    },
])
const cxt = getCurrentInstance(); //相当于Vue2中的this
const bus = cxt?.appContext.config.globalProperties.$bus;
function mouseenter(idx:number){
    for(let i=0;i<footCard.length;i++){
        footCard[i].show=idx==i?true:false;
    }
}
function mouseleave(){
    for(let i=0;i<footCard.length;i++){
        footCard[i].show=false;
    }
}

onMounted(()=>{
    bus.$on('viewPoint',(className)=>{
        let ele= <HTMLImageElement>document.querySelector(`.${className}`);
       window.scrollTo({
        top:ele.offsetTop-200,
        behavior:"smooth"
       });

    })
})
onBeforeUnmount(()=>{
  bus.$off('viewPoint')
})
</script>

<style lang="less" scoped>
img {
    width: 100%;
    height: 100%;
}

p {
    margin: 0;
}

.comm_w {
    width: 1260px;
    margin: auto;
}

.explore {
    padding-top: 250px;

    .e_foot {
        padding-top: 180px;
        padding-bottom: 150px;
        .ef_tit {
            width: 299px;
            height: 58px;
            margin: 0 auto 120px auto;
        }

        .ef_card {
            display: flex;
            justify-content: space-between;
            .ef_act_card{
                box-shadow: 0px 0px 15px 5px rgba(0,0,0,0.05);
                transform: translateY(-20px);
                padding-top: 110px !important;
            }
            .ef_card_item {
                width: 400px;
                height: 500px;
                box-sizing: border-box;
                border: 2px solid rgba(0, 0, 0, 0.05);
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: flex-start;
                padding-top: 194px;
                flex-direction: column;
                color: #555;
                transition: all 0.5s;
                cursor: pointer;
                :nth-child(1) {
                    font-size: 26px;
                }

                :nth-child(2) {
                    font-size: 20px;
                    color: #666;
                    padding: 3px 0 0 0;
                }

                :nth-child(3) {
                    width: 36px;
                    height: 5px;
                    background-color: #009C75;
                    margin: 40px 0;
                }

                :nth-child(4) {
                    font-size: 22px;
                    // width: 242px;
                    text-align: center;
                    white-space: pre-line;
                    line-height: 35px;
                    transform: translateY(150px);
                    opacity: 0;
                    transition: all 0.5s;
                }
                .ec_act_p{
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        }
    }

    .about {
        height: 234px;
        margin-bottom: 120px;
    }

    .card {
        height: 520px;
        margin-bottom: 250px;
    }

    .symbol {
        height: 122px;
        margin-bottom: 100px;
    }

    .brand {
        height: 600px;
        margin-bottom: 200px;
    }

    .e_txt {
        width: 100%;
        background-image: url(https://static.jinzhuangli.com/staticFile/images/23092012.webp);
        background-repeat: no-repeat;
        background-size: 100% 100%;
        height: 400px;
        display: flex;
        flex-direction: row-reverse;
        padding-right: 330px;
        padding-top: 121px;
        box-sizing: border-box;

        img {
            width: 430px;
            height: 259px;
        }
    }
}</style>