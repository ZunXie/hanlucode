
// 首页整屋局部软装单空间数据表
const schemeImgList = [
  {
    imgUrl: 'https://jinzhuangli.oss-cn-guangzhou.aliyuncs.com/upload/20220926/83ee81246e6847ff328972baf7c10e5a_1664184799040.png',
    title: '整装方案',
    top: 133,
    left: 51,
    path: '/monolithic',
    id: 'full',
    right: undefined,
    filedName: 'productStyle',
    screeningCondition: [
      {
        name: '全部',
        val: '',
        sele: true,
      },
      {
        name: '现代',
        val: '现代简约风格#',
        sele: false,
      },
      {
        name: '简约',
        val: '简约风格#',
        sele: false,
      },
      {
        name: '北欧',
        val: '北欧风格#',
        sele: false,
      },
      {
        name: '欧式',
        val: '欧式风格#',
        sele: false,
      },
      {
        name: '中式',
        val: '中式风格#',
        sele: false,
      },
      {
        name: '新中式',
        val: '新中式风格#',
        sele: false,
      },
      {
        name: '轻奢',
        val: '轻奢风格#',
        sele: false,
      },
      {
        name: '美式',
        val: '美式风格#',
        sele: false,
      },
      {
        name: '其他',
        sele: false,
        val: '其他',
      },
    ],
  },
  {
    imgUrl: 'https://jinzhuangli.oss-cn-guangzhou.aliyuncs.com/upload/20220929/388a403314fd7988d0a0ae4ba549ab7f_1664433517553.png',
    title: '局装方案',
    top: 180,
    path: '/monolithic',
    id: 'part',
    left: undefined,
    right: 30,
    filedName: 'spaceName',
    screeningCondition: [
      {
        name: '全部',
        sele: true,
      },
      {
        name: '客餐厅',
        sele: false,
      },
      {
        name: '卧室',
        sele: false,
      },
      {
        name: '厨房',
        sele: false,
      },
      {
        name: '卫生间',
        sele: false,
      },
      {
        name: '阳台',
        sele: false,
      },
      {
        name: '书房',
        sele: false,
      },
      {
        name: '衣帽间',
        sele: false,
      },
      {
        name: '车库',
        sele: false,
      },
      {
        name: '多功能室',
        sele: false,
        isCustomsWidth: true,
      },
      {
        name: '入户花园',
        sele: false,
        isCustomsWidth: true,
        left: 'auto',
      },
    ],
  },
  {
    imgUrl: 'https://jinzhuangli.oss-cn-guangzhou.aliyuncs.com/upload/20220929/8dd32ca282e9216d9f04fb878b264213_1664433716367.png',
    title: '定制方案',
    top: 148,
    left: 51,
    path: '/monolithic',
    id: 'customization',
    filedName: 'categoriesIds',
    right: undefined,
    screeningCondition: [
      {
        name: '全部',
        sele: true,
      },
      {
        name: '橱柜',
        val: '1552865725793292290',
        sele: false,
      },
      {
        name: '衣柜',
        val: '1552865749741137921',
        sele: false,
      },
      {
        name: '隔断柜',
        val: '1552938720969687041',
        sele: false,
      },
      {
        name: '鞋柜',
        val: '1552938752502464513',
        sele: false,
      },
      {
        name: '酒柜',
        val: '1552938776622911489',
        sele: false,
      },
      {
        name: '书柜',
        val: '1552938897193369602',
        sele: false,
      },
      {
        name: '榻榻米',
        val: '1552939056065216513',
        sele: false,
      },
      {
        name: '电视柜',
        val: '1552939083361746946',
        sele: false,
      },
      {
        name: '床',
        val: '1552939226931777538',
        sele: false,
      },
      {
        name: '其他',
        val: '1552939281827823617',
        sele: false,
      },
    ],
  },
  {
    imgUrl: 'https://jinzhuangli.oss-cn-guangzhou.aliyuncs.com/upload/20220929/c76313c6a1b561779b116c5842f54a3d_1664433853507.png',
    title: '软装方案',
    top: 180,
    left: undefined,
    right: 30,
    path: '/monolithic',
    id: 'soft',
    filedName: 'productStyle',
    screeningCondition: [
      {
        name: '全部',
        val: '',
        sele: true,
      },
      {
        name: '现代',
        val: '现代简约风格#',
        sele: false,
      },
      {
        name: '简约',
        val: '简约风格#',
        sele: false,
      },
      {
        name: '北欧',
        val: '北欧风格#',
        sele: false,
      },
      {
        name: '欧式',
        val: '欧式风格#',
        sele: false,
      },
      {
        name: '中式',
        val: '中式风格#',
        sele: false,
      },
      {
        name: '新中式',
        val: '新中式风格#',
        sele: false,
      },
      {
        name: '轻奢',
        val: '轻奢风格#',
        sele: false,
      },
      {
        name: '美式',
        val: '美式风格#',
        sele: false,
      },
      {
        name: '其他',
        sele: false,
        val: '其他',
      },
    ],
  },
];

// 导航栏
const headerList = [
  {
    label: '首页',
    enLabel: 'Home',
    path: '/',
  },
  {
    label: '产品',
    enLabel: 'Product',
    path: '/product',
  },
  {
    label: '关于我们',
    enLabel: 'About',
    path: '/companyInfo',
  },
  {
    label: '发展',
    enLabel: 'Develop',
    path: '/companyDevelop',
  },
  // {
  //   label: '整装',
  //   path: '/monolithic',
  //   id: 'full',
  // },
  // {
  //   label: '局部',
  //   path: '/monolithic',
  //   id: 'part',
  // },
  // {
  //   label: '定制',
  //   path: '/monolithic',
  //   id: 'customization',
  // },
  // {
  //   label: '软装',
  //   path: '/monolithic',
  //   id: 'soft',
  // },
  // {
  //   label: '材料商场',
  //   path: '/mallManagement',
  //   id: 'mall',
  // },
  // {
  // label: '装修攻略',
  // path: '/',
  // },
  // {
  //   label: '工地直播',
  //   // path: '/',
  // },
  // {
  //   label: '关于我们',
  //   path: '/companyProfile',
  //   id: 'hereto',
  // },
];

// 导航栏筛选条件
const screeningCondition = [
  {
    filedName: 'roomNum',
    name: '户型',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
      {
        label: '一居室',
        val: '1-1',
        sele: false,
      },
      {
        label: '二居室',
        val: '2-2',
        sele: false,
      },
      {
        label: '三居室',
        val: '3-3',
        sele: false,
      },
      {
        label: '四居室',
        val: '4-4',
        sele: false,
      },
    ],
  },
  {
    filedName: 'spaceName',
    name: '空间',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
      {
        label: '客餐厅',
        val: '客餐厅',
        sele: false,
      },
      {
        label: '卧室',
        val: '卧室',
        sele: false,
      },
      {
        label: '厨房',
        val: '厨房',
        sele: false,
      },
      {
        label: '卫生间',
        val: '卫生间',
        sele: false,
      },
      {
        label: '阳台',
        val: '阳台',
        sele: false,
      },
      {
        label: '书房',
        val: '书房',
        sele: false,
      },
      {
        label: '衣帽间',
        val: '衣帽间',
        sele: false,
      },
      {
        label: '多功能室',
        val: '多功能室',
        sele: false,
      },
      {
        label: '入户花园',
        val: '入户花园',
        sele: false,
      },
      {
        label: '车库',
        val: '车库',
        sele: false,
      },
    ],
  },
  {
    filedName: 'categoriesIds',
    name: '柜体',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
      {
        label: '橱柜',
        val: '1552865725793292290',
        sele: false,
      },
      {
        label: '衣柜',
        val: '1552865749741137921',
        sele: false,
      },
      {
        label: '鞋柜',
        val: '1552938752502464513',
        sele: false,
      },
      {
        label: '书柜',
        val: '1552938897193369602',
        sele: false,
      },
      {
        label: '电视柜',
        val: '1552939083361746946',
        sele: false,
      },
      {
        label: '床',
        val: '1552939226931777538',
        sele: false,
      },
      {
        label: '其他',
        val: '1552939281827823617',
        sele: false,
      },
    ],
  },
  {
    filedName: 'areaNum',
    name: '面积',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
      {
        label: '60m²以下',
        val: '-59.9999',
        sele: false,
      },
      {
        label: '60-80m²',
        val: '60-80',
        sele: false,
      },
      {
        label: '80-100m²',
        val: '80-100',
        sele: false,
      },
      {
        label: '100-120m²',
        val: '100-120',
        sele: false,
      },
      {
        label: '120m²以上',
        val: '120.0001-',
        sele: false,
      },
    ],
  },
  {
    filedName: 'productStyle',
    name: '风格',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
    ],
  },
  {
    filedName: 'price',
    name: '价格',
    fileds: [
      {
        label: '全部',
        sele: true,
      },
      {
        label: '10万以下',
        val: '-99999.999',
        sele: false,
      },
      {
        label: '10-20万',
        val: '100000-200000',
        sele: false,
      },
      {
        label: '20万以上',
        val: '200000.0001-',
        sele: false,
      },
    ],
  },
];

// 首页服务流程
const serviceProcess = [
  {
    title: '选购方案',
    subTitle: '提交信息',
  },
  {
    title: '设计顾问',
    subTitle: '完善方案',
  },
  {
    title: '生成图纸',
    subTitle: '工程报价',
  },
  {
    title: '敲定细节',
    subTitle: '签订合同',
  },
  {
    title: '施工准备',
    subTitle: '管家服务',
  },
  // {
  //   title: '施工过程',
  //   subTitle: '直播监工',
  // },
  {
    title: '验收支付',
    subTitle: '售后服务',
  },
];


const SVG = `<svg viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg" data-v-029747aa=""><path fill="currentColor" d="M512 64a32 32 0 0 1 32 32v192a32 32 0 0 1-64 0V96a32 32 0 0 1 32-32zm0 640a32 32 0 0 1 32 32v192a32 32 0 1 1-64 0V736a32 32 0 0 1 32-32zm448-192a32 32 0 0 1-32 32H736a32 32 0 1 1 0-64h192a32 32 0 0 1 32 32zm-640 0a32 32 0 0 1-32 32H96a32 32 0 0 1 0-64h192a32 32 0 0 1 32 32zM195.2 195.2a32 32 0 0 1 45.248 0L376.32 331.008a32 32 0 0 1-45.248 45.248L195.2 240.448a32 32 0 0 1 0-45.248zm452.544 452.544a32 32 0 0 1 45.248 0L828.8 783.552a32 32 0 0 1-45.248 45.248L647.744 692.992a32 32 0 0 1 0-45.248zM828.8 195.264a32 32 0 0 1 0 45.184L692.992 376.32a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0zm-452.544 452.48a32 32 0 0 1 0 45.248L240.448 828.8a32 32 0 0 1-45.248-45.248l135.808-135.808a32 32 0 0 1 45.248 0z"></path></svg>`;

export { schemeImgList, screeningCondition, serviceProcess, headerList, SVG };
