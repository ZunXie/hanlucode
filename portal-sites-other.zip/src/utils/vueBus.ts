import mitt from "mitt";
const initMitt = mitt()
const emitter:any = {
  _events:{},
  $emit:initMitt.emit,
  $on:function(t:any,e:any){
    this._events[t] = true
    initMitt.on(t,e)
  },
  $off:function(t:any,e:any){
    delete this._events[t]
    initMitt.off(t,e)
  }
}
export default emitter
