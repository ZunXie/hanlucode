import { detectedSite } from './index'
// 事件总线 用来跨组件通信 
import emitter from "./utils/vueBus";
import AOS from 'aos'

import 'uno.css'//引入unocss
// 引入swiper组件
import { Swiper, SwiperSlide } from 'swiper/vue'; // swiper所需组件
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'animate.css';
import 'aos/dist/aos.css'
const siteInfo: any = detectedSite()
const app = createApp(siteInfo.app);
app.config.globalProperties.$bus = emitter
AOS.init();
app.use(siteInfo.router);
app.use(siteInfo.pina);
// 设置全局组件
app.component('Swiper', Swiper);
app.component('SwiperSlide', SwiperSlide);
app.mount('#app');
