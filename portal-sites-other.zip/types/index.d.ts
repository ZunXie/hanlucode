// 给全局window添加属性
declare interface Window {
  __INITIAL_STATE__: string
}


