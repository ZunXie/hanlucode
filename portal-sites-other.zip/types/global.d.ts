// 定义全局的接口类型
declare interface scrollEvent{
  moveFlag:boolean,
  movePx:number,
  moveScroll:number,
  moveEachThem:number,
  moveClientHeight:number,
  moveScrollStart:number,
  isMouse:boolean,
  timer:null|number
}