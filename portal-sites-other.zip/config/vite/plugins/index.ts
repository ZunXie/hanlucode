/**
 * @name createVitePlugins
 * @description 封装plugins数组统一调用
 */
import { PluginOption } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import { AutoImportDeps } from './autoImport';
import { ConfigCompressPlugin } from './compress';
import { ConfigRestartPlugin } from './restart';
import { ConfigProgressPlugin } from './progress';
import { AutoRegistryComponents } from './component';
import Inspect from 'vite-plugin-inspect';
import { ConfigUnocssPlugin } from './unocss';
import { ConfigPagesPlugin } from './pages';

export function createVitePlugins(isBuild: boolean) {
  const vitePlugins: (PluginOption | PluginOption[])[] = [
    // vue支持
    vue(),
    // JSX支持
    vueJsx(),
  ];

  // 自动按需引入依赖
  vitePlugins.push(AutoImportDeps());

  // 自动按需引入组件
  vitePlugins.push(AutoRegistryComponents());

  // 开启.gz压缩  rollup-plugin-gzip
  vitePlugins.push(ConfigCompressPlugin());

  // unocss
  vitePlugins.push(ConfigUnocssPlugin());

  // 自动生成路由
  vitePlugins.push(ConfigPagesPlugin());

  vitePlugins.push(ConfigRestartPlugin());

  vitePlugins.push(ConfigProgressPlugin());

  vitePlugins.push(Inspect());

  return vitePlugins;
}
