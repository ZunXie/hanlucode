/**
 * @name ConfigPagesPlugin
 * @description 动态生成路由
 */
import Pages from 'vite-plugin-pages';

export const ConfigPagesPlugin = () => {
  return Pages({
    // pagesDir: [{ dir: 'src/KeYi/views', baseRoute: '' },{ dir: 'src/HaoTing/views', baseRoute: '' },{ dir: 'src/QiaoJiang/views', baseRoute: '' }],
    extensions: ['vue', 'md'],
    exclude: ['**/components/*.vue'],
    nuxtStyle: true,
    extendRoute(route, parent) {
      if (route.path.startsWith('/auth')) {
        return {
          ...route,
          path: route.path.replace('/auth', ''),
          meta: { requireAuth: true },
        };
      }

      return route;
    },
  });
};
